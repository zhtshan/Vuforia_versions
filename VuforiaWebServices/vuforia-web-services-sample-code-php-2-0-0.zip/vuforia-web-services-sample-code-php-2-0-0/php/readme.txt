PHP VWS Samples using HTTP_Request2

Requires :

(PHP 5 >= 5.2.0, PECL json >= 1.2.0) for JSON support.
http://php.net/manual/en/book.json.php

HTTP_Request2
http://pear.php.net/package/HTTP_Request2/


Installation:

JSON encoding and decoding are supported natively for PHP versions 5.2+ 
Prior PHP versions can use the JSON extension here - http://pecl.php.net/package/json

HTTP_Request2 is a PEAR package that can be installed from a command line. 

pear install HTTP_Request2

Pyrus Install

php pyrus.phar install pear/HTTP_Request2

Usage:

You will need to add our Cloud Database access and secret key to each sample, along with a target id for those queries requiring one. 
After the keys have been added, you can execute the sample classes from the SampleSelector.php page, by loading this page in a browser. 
The samples and SampleSelector pages should be hosted on a web server that is configured to handle PHP requests. The CheckPHPEnvironment 
page can be used to review your PHP installation along with its available extensions. 


