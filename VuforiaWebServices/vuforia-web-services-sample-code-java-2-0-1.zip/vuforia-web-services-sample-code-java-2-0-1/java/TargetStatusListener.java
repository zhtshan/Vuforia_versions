package com.ptc.vuforia.CloudRecognition.samples;

public interface TargetStatusListener {

	public void OnTargetStatusUpdate(TargetState targetState);
}
