Vuforia Engine Augmented Reality SDK
==============================================
To print a 3D model of the Model Target, go to https://library.vuforia.com/content/vuforia-library/en/articles/Solution/printing-assembling-the-viking-lander.html

/*============================================================================
            Copyright (c) 2020 PTC Inc.
            All Rights Reserved.
            Confidential and Proprietary - PTC Inc.
  ============================================================================*/