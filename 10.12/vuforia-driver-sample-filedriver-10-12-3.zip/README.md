# FileDriver

Implements a Vuforia Driver compatible library for playing back recordings made with the Vuforia Session Recorder.

## Prerequisites
* A working development environment for your chosen platform 
* Python 3.7+
* CMake 3.9+

## Building
1. Extract the File Driver package and the Vuforia SDK package.
2. Run the appropriate build command:

    Note: The `-vh`  or `-vf` command line options may be omitted if the driver is put in the SDK's samples directory.

    * **Android**
        ```
        python build.py android -vh [path to Vuforia SDK]/build/include
        ```
    * **UWP**
        ```
        python build.py uwp -vh [path to Vuforia SDK]/build/include
        ```
    * **IOS**
        ```
        python build.py ios -vf [path to Vuforia SDK]/build
        ```
        Set the `-vf` option to the folder containing the VuforiaEngine.framework

3. Output files should be placed in the `build/bin` directory by default: 
    * `Android/Release/[architecture]/libFileDriver.so` for Android
    * `WindowsStore/Release/[architecture]/FileDriver.dll` for UWP
    * `Release-iphoneos/FileDriver.framework` for iOS


## Recording format

### MP4 format
The MP4 recording format combines all required data into one MP4 file with multiple tracks. The camera images are
stored as H.264 encoded video.

### Legacy XML format
**This format is deprecated. Support for it will be removed in a future release.**

Each recording is stored in a folder called `VuforiaSession-[DATE]-[TIME]`, where `[DATE]` and `[TIME]` are
human-readable date-time strings, respectively in the `YYYYMMDD` and `hhmmss` formats, such as `20201023` and `231059`.

This folder contains a `FileDriverRecording.xml` file and a `Camera` folder.
The `FileDriverRecording.xml` file contains the saved data values, as well as pointers to data that is external to the
file, such as names of the recorded camera image files.
The recorded camera image files are stored in the `Camera` folder.
Sample recordings with this format are provided in the [`data`][data] directory.
Additionally, the included XSD files ([v2.0][xml-spec-v2.0] and [v2.1][xml-spec-v2.1]) formally describe the
`FileDriverRecording.xml` file format
(please note that there is a separate XSD file for each format version).
This file is written in the [XML Schema Definition (XSD)][xsd] language.

The File Driver can be instructed to replay a recording a pre-defined number of times.
This is done by setting the `loop` attribute of the `CameraCapture` section in the `FileDriverRecording.xml` file.
Please note that this attribute is optional and the Session Recorder doesn't write it.

[data]: data
[xml-spec-v2.0]: docs/FileDriverRecording-v2.0.xsd
[xml-spec-v2.1]: docs/FileDriverRecording-v2.1.xsd
[xsd]: https://www.w3.org/TR/xmlschema11-1/


# Usage
## Android
1. Add `libFileDriver.so` for each required architecture from `build/bin` to your Android app project by modifying either Android.mk or CMakeLists.txt or build.gradle. Select the option that best fits your project (please note that you need to substitute `[path-in-your-filesystem]` with the correct path on your machine):

    * **Using Android.mk**:

        Add libFileDriver-prebuilt definition to your Android.mk:
        ```
        include $(CLEAR_VARS)
        LOCAL_MODULE := libFileDriver-prebuilt
        LOCAL_SRC_FILES = [path-in-your-filesystem]/FileDriver/build/bin/Android/$(TARGET_ARCH_ABI)/libFileDriver.so
        include $(PREBUILT_SHARED_LIBRARY)
        ```
        When defining your local module in the same Android.mk add libFileDriver-prebuilt as a dependency to your  `LOCAL_SHARED_LIBRARIES`:
        ```
        LOCAL_SHARED_LIBRARIES := Vuforia-prebuilt libFileDriver-prebuilt
        ```

    * **Using CMakeLists.txt**

        Add `libFileDriver` prebuilt definition to your `CMakeLists.txt` file:
        ```
        add_library(VUFORIA_FILEDRIVER_LIBRARY SHARED IMPORTED)
        set_property(TARGET VUFORIA_FILEDRIVER_LIBRARY PROPERTY IMPORTED_LOCATION
        [path-in-your-filesystem]/FileDriver/build/bin/Android/Release/${ANDROID_ABI}/libFileDriver.so)
        ```

        When linking libraries in CMake, link `libFileDriver` library in the same `CMakeLists.txt`:
        ```
        target_link_libraries(
            VuforiaSample
            ${ANDROID_LIBRARY}
            ${LOG_LIBRARY}
            ${GLES3_LIBRARY}
            VUFORIA_LIBRARY
            VUFORIA_FILEDRIVER_LIBRARY
        )
        ```

    * **Using Gradle**

        **NOTE:** Only required if you are using Android Plugin version 3.x and below.

        If using either `Android.mk` or `CMakeLists.txt` you will also need to update your `build.gradle` to include the library in the APK. Use the following code in your `app/build.gradle`:
        ```
        android {
            sourceSets.main {
                jniLibs.srcDirs += '[path-in-your-filesystem]/FileDriver/build/bin/Android/'
            }
        }
        ```

2. Add `FileDriver.jar` from `build/bin` into your Android-app project.

    Use the following code in your `app/build.gradle`:
    ```
    dependencies {
        implementation files("[path-in-your-filesystem]/FileDriver/build/bin/Android/FileDriver.jar")
    }
    ```

3. Add the sample recording from the `data` directory into your Android-app project. 

    Use the following code in your `app/build.gradle`:
    ```
    android {
        sourceSets.main {
            assets.srcDirs += '[path-in-your-filesystem]/FileDriver/data/stones'
        }
    }
    ```

4. Add your configuration for the driver before creating a new Engine instance with `vuEngineCreate()`:

    ```
    VuDriverConfig driverConfig = vuDriverConfigDefault();
    driverConfig.driverName = "libFileDriver.so";
    driverConfig.userData = nullptr;
    vuEngineConfigSetAddDriverConfig(configSet, &driverConfig);
    ```

## UWP
1. Add `FileDriver.dll` from `build/bin/uwp` into your Visual Studio UWP-app project.
    * Import the `FileDriver.dll` to the root of your project. Remember to use a dll that matches your architecture (x86/x64) and build type (Debug/Release) configurations.
    * Click `FileDriver.dll` from the project file list and set property **Content** to **True**.

2. Add a sample sequence from the data directory into your Visual Studio UWP app project. For example, to use the “stones” sequence:
    * Import `FileDriver/data/stones/FileDriverRecording.mp4` into your project.
    * Select the file and set the property **Content** to **True**.

3. Add the following call before calling vuEngineCreate();
   
    ```
    VuDriverConfig driverConfig = vuDriverConfigDefault();
    driverConfig.driverName = "FileDriver.dll";
    driverConfig.userData = nullptr;
    vuEngineConfigSetAddDriverConfig(configSet, &driverConfig);
    ```

## iOS
1. In your Xcode project, open the build settings screen and select the **General** tab. 
2. In the **Embedded Binaries** section, click the **+** icon to add a new binary. 
3. From the file selection menu, locate the iOS File Driver Framework in `bin/Release-iphoneos/FileDriver.framework`
4. In the **Linked Frameworks and Libraries** section, remove the FileDriver entry. The entry should not be listed in this section and the application should not try to link against it.
5. Drag the FileDriverRecording.mp4 file into the left-hand project pane.
6. Add the following call before calling vuEngineCreate();
   
    ```
    VuDriverConfig driverConfig = vuDriverConfigDefault();
    driverConfig.driverName = "FileDriver.framework";
    driverConfig.userData = nullptr;
    vuEngineConfigSetAddDriverConfig(configSet, &driverConfig);
    ```

# Playback Controls
FileDriver exposes a playback control API that can be used to configure its playback behavior.

Supported controls:
* Playback start time
* Playback end time
* Looping playback
* Changing playback mode

For details, see [FileDriverPlaybackController.h](include/FileDriverPlaybackController.h)

## Usage
After successfully creating the engine with FileDriver, a native platform handle to the loaded library can be retrieved by using `vuPlatformControllerGetDriverLibraryHandle()`.
This handle can be used to load the FileDriver playback controller functions using the native symbol loading mechanism of the current platform (`GetProcAddress()` on Windows/UWP, `dlsym()` on POSIX systems)
The retrieved function pointers can then be used to configure playback at any time until the engine is destroyed and thus the library unloaded. Note that some playback control functions require that the engine is stopped and restarted to apply the change.
