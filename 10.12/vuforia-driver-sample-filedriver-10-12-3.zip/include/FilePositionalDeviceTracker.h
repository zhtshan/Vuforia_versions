/*===============================================================================
Copyright (c) 2021 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/
#ifndef _FILE_POSITIONAL_DEVICE_TRACKER_H_
#define _FILE_POSITIONAL_DEVICE_TRACKER_H_

#include "FileDriverUserData.h"
#include <VuforiaEngine/Driver/Driver.h>

class Player;

/// FilePositionalDeviceTracker that implements the VuforiaDriver::ExternalPositionalDeviceTracker base class.
/**
 * The documentation of the overridden public methods can be found in VuforiaEngine/Driver/Driver.h header.
 */
class FilePositionalDeviceTracker final : public VuforiaDriver::ExternalPositionalDeviceTracker
{
public:
    FilePositionalDeviceTracker(Player* player);

    bool VUFORIA_DRIVER_CALLING_CONVENTION open() override;
    bool VUFORIA_DRIVER_CALLING_CONVENTION close() override;
    bool VUFORIA_DRIVER_CALLING_CONVENTION start(VuforiaDriver::PoseCallback* cb, VuforiaDriver::AnchorCallback* acb = nullptr) override;
    bool VUFORIA_DRIVER_CALLING_CONVENTION stop() override;
    bool VUFORIA_DRIVER_CALLING_CONVENTION resetTracking() override;

private:
    /// Call back for incoming poses.
    /**
     * /param poseInfo A pose that has been populated and ready to be passed into Vuforia.
     */
    void posesPlayerCallback(VuforiaDriver::Pose* poseInfo);

    Player*                      mPlayer{nullptr};
    VuforiaDriver::PoseCallback* mCallback{};
};

#endif // _FILE_POSITIONAL_DEVICE_TRACKER_H_
