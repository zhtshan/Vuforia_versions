/*===============================================================================
Copyright (c) 2021 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/
#ifndef _PLAYER_H_
#define _PLAYER_H_

#include "FileDriverPlaybackController.h"

#include <VuforiaEngine/Driver/Driver.h>

#include <functional>

struct FileDriverUserData;

/// Details about a recording
struct RecordingProperties
{
    uint32_t                           numberOfImages{};
    VuforiaDriver::CameraMode          cameraMode;
    VuforiaDriver::CameraIntrinsics    cameraIntrinsics;
    bool                               hasDevicePoses{false};
    uint32_t                           recDevOrientInDegrees{0};
    uint32_t                           recCamOrientInDegrees{0};
    bool                               supportsCameraOrientation{false};
    uint64_t                           lastCameraTimestamp{0};
    uint64_t                           lastPoseTimestamp{0};
    uint64_t                           firstCameraTimestamp{0};
    uint64_t                           firstPoseTimestamp{0};
    FileDriverPlaybackMode             playbackMode{FILEDRIVER_PLAYBACK_MODE_RESPECT};
};

using CameraFrameCallback = std::function<void(VuforiaDriver::CameraFrame* inFrame)>;
using DevicePoseCallback = std::function<void(VuforiaDriver::Pose* poseInfo)>;

enum class PlaybackState
{
    Stopped,         // Playback is stopped. Playback thread is not running.
    StopRequested,   // Playback should be stopped asap. Playback thread will set the current state to "Stopped" and exit.
    Paused,          // Playback is paused. Playback thread is waiting to be resumed.
    PauseRequested,  // Playback should be paused asap. Playback thread will set the current state to "Paused" when completed.
    Running,         // Playback is currently running
};

/// Player interface
/**
 * A player reads and plays back a recording. Properties are provided via getRecordingProperties().
 * After the player is started, frames are delivered to the camera frame callback and poses (if available) to the device pose callback.
 */
class Player
{
public:
    virtual ~Player() = default;
    
    /// Initialize the player
    virtual bool init(VuforiaDriver::PlatformData* platformData, FileDriverUserData* userData) = 0;

    /// Open the camera.
    /**
     * Prepares the camera feed for playback.
     * 
     * \returns false if the player could not be configured for playing back camera frames
     */
    virtual bool open(CameraFrameCallback cameraCallback) = 0;

    /// Open the external pose provider.
    /**
     * Prepare poses for playback.
     * 
     * \returns false if the player could not be configured for playing back device poses
     */
    virtual bool open(DevicePoseCallback poseCallback) = 0;

    /// Start the camera/pose feed.
    /**
     * Playback always starts from the beginning of the sequence.
     * 
     * \returns false if the starting fails
     */
    virtual bool start() = 0;

    /// Stop the camera/pose feed.
    /**
     * The feed stops and will rewind the playback to the beginning of the recording.
     * 
     * \returns false if the stopping fails or the playback could not be reset to the beginning of the recording.
     */
    virtual bool stop() = 0;

    /// Close the camera/ external pose provider.
    /**
     * stop() must be called before close().
     */
    virtual void close() = 0;
    
    /// Return the properties used for playback.
    virtual const RecordingProperties& getRecordingProperties() const = 0;
    
    // Sets the playback start position in the currently loaded sequence
    /**
     * \note When this method is called, the playback will be restarted at the specified position on next engine start.
     * \note Playback will start with the video frame whose timestamp is closest to the provided timestamp.
     *
     * \param timestamp The timestamp at which playback should start. This is the time in nanoseconds
     *                  relative to the start of the sequence.
     *
     * \returns false if an invalid timestamp was provided.
     */
    virtual bool setPlaybackStartTime(uint64_t timestamp) = 0;
    
    /// Sets the playback end position in the currently loaded sequence
    /**
     * \note Playback will end with the first video frame whose timestamp is >= the provided timestamp.
     *
     * \param timestamp The timestamp at which playback should end. This is the time in nanoseconds
     *                  relative to the start of the sequence.
     * 
     * \returns false if an invalid timestamp was provided.
     */
    virtual bool setPlaybackEndTime(uint64_t timestamp) = 0;
    
    /// Returns the timestamp of the current playback position (time in nanoseconds relative to the start of the sequence)
    virtual uint64_t getPlaybackPosition() = 0;
    
    /// Configures looping playback
    /**
     * \param loopCount Setting this to zero enables infinite looping. Any other values indicates 
     *                  that the sequence should be played a limited number of times.
     */
    virtual void setPlaybackLoop(uint32_t loopCount) = 0;
    
    /// Configures the playback behavior of the driver
    /**
     * \note The default playback mode is FILEDRIVER_PLAYBACK_MODE_RESPECT.
     */
    virtual void setPlaybackMode(FileDriverPlaybackMode mode) = 0;
};

#endif // _PLAYER_H_
