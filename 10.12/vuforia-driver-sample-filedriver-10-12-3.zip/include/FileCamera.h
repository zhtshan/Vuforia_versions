/*===============================================================================
Copyright (c) 2021 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/
#ifndef _FILECAMERA_H_
#define _FILECAMERA_H_

#include "FileDriverUserData.h"

#include <VuforiaEngine/Driver/Driver.h>

#include <string>

class Player;

/// FileCamera that implements the VuforiaDriver::ExternalCamera base class.
/**
 * The documentation of the overridden public methods can be found in VuforiaEngine/Driver/Driver.h header.
 */
class FileCamera final : public VuforiaDriver::ExternalCamera
{
public:
    FileCamera(Player* player);

    bool VUFORIA_DRIVER_CALLING_CONVENTION open() override;
    bool VUFORIA_DRIVER_CALLING_CONVENTION close() override;
    bool VUFORIA_DRIVER_CALLING_CONVENTION start(VuforiaDriver::CameraMode cameraMode, VuforiaDriver::CameraCallback* cb) override;
    bool VUFORIA_DRIVER_CALLING_CONVENTION stop() override;

    uint32_t VUFORIA_DRIVER_CALLING_CONVENTION getNumSupportedCameraModes() override;
    bool VUFORIA_DRIVER_CALLING_CONVENTION getSupportedCameraMode(uint32_t index, VuforiaDriver::CameraMode* out) override;

    bool VUFORIA_DRIVER_CALLING_CONVENTION supportsExposureMode(VuforiaDriver::ExposureMode parameter) override;
    VuforiaDriver::ExposureMode VUFORIA_DRIVER_CALLING_CONVENTION getExposureMode() override;
    bool VUFORIA_DRIVER_CALLING_CONVENTION setExposureMode(VuforiaDriver::ExposureMode mode) override;

    bool VUFORIA_DRIVER_CALLING_CONVENTION supportsExposureValue() override;
    uint64_t VUFORIA_DRIVER_CALLING_CONVENTION getExposureValueMin() override;
    uint64_t VUFORIA_DRIVER_CALLING_CONVENTION getExposureValueMax() override;
    uint64_t VUFORIA_DRIVER_CALLING_CONVENTION getExposureValue() override;
    bool VUFORIA_DRIVER_CALLING_CONVENTION setExposureValue(uint64_t exposureTime) override;

    bool VUFORIA_DRIVER_CALLING_CONVENTION supportsFocusMode(VuforiaDriver::FocusMode parameter) override;
    VuforiaDriver::FocusMode VUFORIA_DRIVER_CALLING_CONVENTION getFocusMode() override;
    bool VUFORIA_DRIVER_CALLING_CONVENTION setFocusMode(VuforiaDriver::FocusMode mode) override;

    bool VUFORIA_DRIVER_CALLING_CONVENTION supportsFocusValue() override;
    float VUFORIA_DRIVER_CALLING_CONVENTION getFocusValueMin() override;
    float VUFORIA_DRIVER_CALLING_CONVENTION getFocusValueMax() override;
    float VUFORIA_DRIVER_CALLING_CONVENTION getFocusValue() override;
    bool VUFORIA_DRIVER_CALLING_CONVENTION setFocusValue(float value) override;
    
    bool VUFORIA_DRIVER_CALLING_CONVENTION processFramesOnThread() override;

private:
    /// Call back for incoming frames.
    /**
     * /param inFrame Single frame that has been populated and ready to be passed
     *        into Vuforia.
     */
    void framesPlayerCallback(VuforiaDriver::CameraFrame* inFrame);

    Player*                                       mPlayer;
    VuforiaDriver::CameraCallback*                mCallback{};
};

#endif // _FILECAMERA_H_
