/*===============================================================================
Copyright (c) 2021 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/
#ifndef _RGBAPIXELCONVERTER_H_
#define _RGBAPIXELCONVERTER_H_

#include <VuforiaEngine/Driver/Driver.h>

#include <vector>

/// A class to convert RGBA values to different output formats.
class RGBAPixelConverter
{
public:
    /// The order or color channels within one pixel.
    enum class ChannelOrder
    {
        RGBA,
        BGRA
    };

    /// Convert a RGBA pixel buffer into a different format.
    /**
     * \param dstPixelFormat Target pixel format.
     * \param srcPixelBuffer Source pixel buffer containing RGBA-data.
     *        Order of the color channels is specified with srcChannelOrder
     *        parameter.
     * \param srcWidth Width of the source buffer in pixels.
     * \param srcHeight Height of the source buffer in pixels.
     * \param srcChannelOrder Color channel order in the source buffer.
     * \param dstPixelBuffer Output value. Buffer, that gets automatically resized
     *        to exactly fit the output values.
     * \param dstStride Output value. Stride (bytes per row) in
     *        the destination buffer.
     *
     * \return True if the conversion succeeded, otherwise false.
     */
    static bool convert(VuforiaDriver::PixelFormat dstPixelFormat,
        const uint8_t* srcPixelBuffer,
        int srcWidth,
        int srcHeight,
        ChannelOrder srcChannelOrder,
        std::vector<uint8_t>& dstPixelBuffer,
        uint32_t& dstStride);

private:
    static bool convertToYUYV(const uint8_t* srcPixelBuffer,
        int srcWidth,
        int srcHeight,
        ChannelOrder srcChannelOrder,
        std::vector<uint8_t>& dstPixelBuffer,
        uint32_t& dstStride);

    static bool convertToYUV420(const uint8_t* srcPixelBuffer,
        int srcWidth,
        int srcHeight,
        ChannelOrder srcChannelOrder,
        VuforiaDriver::PixelFormat dstPixelFormat,
        std::vector<uint8_t>& dstPixelBuffer,
        uint32_t& dstStride);
};

#endif // _RGBAPIXELCONVERTER_H_
