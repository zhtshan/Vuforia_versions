/*===============================================================================
Copyright (c) 2021 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/
#ifndef _XMLPLAYER_H_
#define _XMLPLAYER_H_

#include "Player.h"
#include "NonCopyable.h"

#include <functional>
#include <mutex>
#include <thread>
#include <vector>

namespace Platform
{
class FileReader;
}

/// Class to playback camera images/poses from the disk.
/**
 * This class will read an XML recording and deliver frames/poses via the callbacks.
 */
class XMLPlayer final : public Player, public NonCopyable
{
public:
    XMLPlayer() = default;
    
    ~XMLPlayer() override;
    
    bool init(VuforiaDriver::PlatformData* platformData, FileDriverUserData* userData) override;

    bool open(CameraFrameCallback cameraCallback) override;

    bool open(DevicePoseCallback poseCallback) override;

    bool start() override;

    bool stop() override;

    void close() override;
    
    const RecordingProperties& getRecordingProperties() const override;
    
    bool setPlaybackStartTime(uint64_t timestamp) override;
   
    bool setPlaybackEndTime(uint64_t timestamp) override;
    
    uint64_t getPlaybackPosition() override;
   
    void setPlaybackLoop(uint32_t loopCount) override;
    
    void setPlaybackMode(FileDriverPlaybackMode mode) override;
    
private:
    bool readRecordingProperties();
    void checkRecordingHasDevicePoses();
    bool getCameraFrame(VuforiaDriver::CameraFrame&, std::vector<uint8_t>&);
    bool getPose(VuforiaDriver::Pose&);
    void threadFunction();
    
    RecordingProperties                           mRecordingProperties;
    std::unique_ptr<Platform::FileReader>         mFileReader{};
    std::atomic<PlaybackState>                    mPlaybackState{ PlaybackState::Stopped };
    uint32_t                                      mCurrentFrameIndex{ 0 };
    std::thread                                   mPlayingThread;
    std::mutex                                    mPlaybackMutex;
    std::condition_variable                       mPlaybackCv;
    CameraFrameCallback                           mCameraFrameCallback;
    DevicePoseCallback                            mDevicePoseCallback;
    
    std::atomic<uint32_t> mLoopCount{0};
    std::atomic<uint64_t> mPlaybackPosition{0};
    std::atomic<uint64_t> mEndPlaybackTimestamp{std::numeric_limits<uint64_t>::max()};
    std::atomic<uint64_t> mStartPlaybackTimestamp{0};
    std::atomic<bool> mStartPositionChanged{false};
};

#endif // _XMLPLAYER_H_
