/*===============================================================================
Copyright (c) 2021 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

#ifndef _MP4PLAYER_H_
#define _MP4PLAYER_H_

#include "NonCopyable.h"
#include "Player.h"
#include "Platform/FileReader.h"
#include "Platform/MP4Reader.h"

#include <memory>
#include <mutex>
#include <optional>

static constexpr auto MP4_ASSET_NAME = "FileDriverRecording.mp4";

namespace Platform
{
class MP4Reader;
}

/// Class to playback camera images/poses from an MP4 file.
/**
 * This class will read an MP4 recording and deliver frames/poses vie the callbacks.
 */
class MP4Player final : public Player, public NonCopyable
{
public:
    MP4Player() = default;
    
    ~MP4Player() override;
    
    bool init(VuforiaDriver::PlatformData* platformData, FileDriverUserData* userData) override;

    bool open(CameraFrameCallback cameraCallback) override;

    bool open(DevicePoseCallback poseCallback) override;

    bool start() override;

    bool stop() override;

    void close() override;
    
    const RecordingProperties& getRecordingProperties() const override;
    
    bool setPlaybackStartTime(uint64_t timestamp) override;
   
    bool setPlaybackEndTime(uint64_t timestamp) override;
    
    uint64_t getPlaybackPosition() override;
   
    void setPlaybackLoop(uint32_t loopCount) override;
    
    void setPlaybackMode(FileDriverPlaybackMode mode) override;

private:
    // Perform basic sanity-checking if the file can be played back
    bool isCompatibleMP4Recording() const;
    
    void readRecordingProperties();

    // Resets all tracks on the MP4 reader to the configured start position.
    // Ensure that this in called in a thread-safe context.
    bool resetPlaybackToStart();

    bool initializeTracksForPlayback();
    
    void playbackThread();
    
    std::optional<VuforiaDriver::CameraFrame> readNextCameraFrame();
        
    std::optional<VuforiaDriver::Pose> readNextDevicePose();

    VuforiaDriver::PlatformData* mPlatformData{nullptr};
    RecordingProperties mRecordingProperties;
    
    std::unique_ptr<Platform::FileReader> mFileReader;
    std::unique_ptr<Platform::MP4Reader> mMP4Reader;
    
    std::optional<Platform::MP4Reader::TrackInfo> mDevicePoseTrack;
    std::optional<Platform::MP4Reader::TrackInfo> mVideoTrack;
    std::optional<Platform::MP4Reader::TrackInfo> mCameraMetadataTrack;
    
    uint32_t mNumFramesRead{0};
    uint32_t mNumDevicePosesRead{0};
    
    std::atomic<uint32_t> mLoopCount{1};
    std::atomic<uint64_t> mPlaybackPosition{0};
    std::atomic<uint64_t> mEndPlaybackTimestamp{std::numeric_limits<uint64_t>::max()};
    std::atomic<uint64_t> mStartPlaybackTimestamp{0};
    std::atomic<bool> mStartPositionChanged{false};
        
    CameraFrameCallback mCameraFrameCallback;
    DevicePoseCallback mDevicePoseCallback;
    std::vector<uint8_t> mSampleReadBuffer;
    std::vector<uint8_t> mFrameReadBuffer;
    
    std::mutex mPlaybackMutex;
    std::condition_variable mPlaybackCv;
    std::atomic<PlaybackState> mPlaybackState{ PlaybackState::Stopped };
    std::thread mPlaybackThread;
    
};

#endif // _MP4PLAYER_H_
