/*===============================================================================
Copyright (c) 2021 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/
#ifndef _PLATFORM_H_
#define _PLATFORM_H_

#include "FileReader.h"

#include <memory>
#include <string>

/// Platform specific functionality.
namespace Platform
{
/// Output a log message.
/**
 * \param message message.
 */
void log(const std::string& message);

/// Create a FileReader to open files from the application bundle.
/**
 * \return Platform specific instance of FileReader. The caller is
 *         responsible for the object lifetime.
 */
std::unique_ptr<FileReader> createFileReader();

} // namespace Platform

#endif // _PLATFORM_H_
