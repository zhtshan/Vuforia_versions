/*===============================================================================
Copyright (c) 2021 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/
#ifndef _ANDROIDFILEREADER_H_
#define _ANDROIDFILEREADER_H_

#include "Platform/FileReader.h"

#include <VuforiaEngine/Driver/Driver.h>

#include <jni.h>
#include <string>
#include <android/asset_manager.h>
#include <android/asset_manager_jni.h>

// Forward Declaration
struct FileDriver_UserData;

namespace Platform
{
namespace Android
{
/// Android specific implementation of FileReader.
class AndroidFileReader : public FileReader
{
public:
    bool init(VuforiaDriver::PlatformData* platformData, FileDriverUserData* userData) override;
    bool deInit() override;
    bool readImage(const std::string& filename, VuforiaDriver::CameraMode cameraMode, std::vector<uint8_t>& outBytes, uint32_t& outStride) override;
    XMLFileReader::ElementInfo readRecording(const std::string& filename) override;
    void setCapability(VuforiaDriver::Capability) override;

    bool assetExists(const std::string& name) const override;

    AAssetManager* getAssetManager();
private:
    VuforiaDriver::PlatformData*    mPlatformData{ nullptr };
    bool                            mReadFilesFromBundle{ false };
    std::string                     mAbsolutePath;
    jclass                          mFileReaderClass{ nullptr };
    jmethodID*                      mFileReaderClass_methodIDs { nullptr };
    jobject                         mFileReaderClass_obj { nullptr };
    uint32_t mCapability{0};
    AAssetManager*                  mAssetManagerNative { nullptr };
    const void*                     mAssetDatabuffer { nullptr };
    AAsset*                         mXMLAsset{ nullptr };

    static const std::string JAVA_FILE_READER_CLASS;
};

} // Android
} // Platform

#endif // _ANDROIDFILEREADER_H_
