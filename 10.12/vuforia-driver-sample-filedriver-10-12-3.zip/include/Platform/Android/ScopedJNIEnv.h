/*===============================================================================
Copyright (c) 2021 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

#ifndef _SCOPEDJNIENV_H_
#define _SCOPEDJNIENV_H_

#include <jni.h>

namespace Platform
{
namespace Android
{
// Wrapper that gets the JNIEnv pointer from JVM and attaches it to the current
// thread if necessary. In case the thread was attached, it will be released
// in the destructor.
class ScopedJNIEnv
{
public:
    ScopedJNIEnv(JavaVM* javaVM, jint jniVersion)
        : mJavaVM(javaVM)
    {
        if (mJavaVM->GetEnv((void**) &mJNIEnv, jniVersion) == JNI_EDETACHED)
        {
            mJavaVM->AttachCurrentThread(&mJNIEnv, nullptr);
            mThreadAttached = true;
        }
    }

    ~ScopedJNIEnv()
    {
        if (mThreadAttached)
        {
            mJavaVM->DetachCurrentThread();
        }
    }

    bool
    operator==(JNIEnv* rhv) const
    {
        return mJNIEnv == rhv;
    }

    JNIEnv* operator->() const
    {
        return mJNIEnv;
    }

private:
    bool mThreadAttached = false;
    JNIEnv* mJNIEnv = nullptr;
    JavaVM* mJavaVM = nullptr;
};

} // Android
} // Platform

#endif // _SCOPEDJNIENV_H_
