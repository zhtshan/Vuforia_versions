/*===============================================================================
Copyright (c) 2021 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/
#ifndef _FILE_DRIVER_ANDROID_JNI_UTILS_H
#define _FILE_DRIVER_ANDROID_JNI_UTILS_H

#include "Platform/Platform.h"
#include "Platform/Android/ScopedJNIEnv.h"
#include "Platform/Platform.h"

#define INFINITE -1

#define _JNI_JAVAMETHODS_FINISHED_ { 0, 0 }
#define _JNI_NATIVEMETHODS_FINISHED_ { 0, 0, 0 }

typedef struct
{
    const char* name;
    const char* signature;
} JNIJavaMethod;

int getNumJavaMethods(const JNIJavaMethod*);
bool getJavaFunctions(JNIEnv*, jclass, jmethodID*&, const JNIJavaMethod*, bool, int);

#endif//_FILE_DRIVER_ANDROID_JNI_UTILS_H
