/*===============================================================================
Copyright (c) 2021 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/
#ifndef _VIDEODECODER_H_
#define _VIDEODECODER_H_

#include "NonCopyable.h"

#include <VuforiaEngine/Driver/Driver.h>

#include <functional>
#include <memory>
#include <optional>
#include <unordered_map>
#include <vector>

namespace VuforiaDriver
{
struct PlatformData;
}

namespace Platform
{

// Supported video codec types
enum class VideoCodec
{
    // H.264 decoder
    /**
     * This codec expects SPS and PPS
     * data as NALUs without any header as part of the codec configuration data.
     *
     * The NALUs for all other samples are in AVCC format with 4 byte header.
     */
    H264_AVCC,
};

// Additional video codec configuration data
enum class VideoCodecConfigurationDataType
{
    H264_SPS,   // H.264 sequence parameter sets
    H264_PPS    // H.264 picture parameter sets
};

using VideoCodecConfigurationData = std::unordered_map<VideoCodecConfigurationDataType, std::vector<uint8_t>>;

/// Base class for platform-specific video decoding.
class VideoDecoder : public NonCopyable
{
public:
    /// Frame output callback. Will be called once for every decoded frame.
    /**
     * \note The output callback will be called from the platform video decoder thread.
     *
     * \note The provided image is owned by the decoder and the buffer is only valid
     *       until the callback returns.
     */
    using OutputCallback = std::function<void(
        const uint8_t* imageBuffer,         // Pointer to the NV12 output image
        uint32_t bufferSize,                // Total size of the image buffer
        uint32_t stride,                    // Output image stride for Y and UV plane
        uint64_t presentationTimestampUs    // Timestamp of the decoded frame in microseconds
    )>;

    /// Creates a new video decoder instance for the given codec type
    /**
     * \returns nullptr if the provided codec type is not supported on the current device or if the platform is currently
     * unable to create a new instance (e.g. too many concurrent instances were created)
     */
    static std::unique_ptr<VideoDecoder> create(VideoCodec codecType, VuforiaDriver::PlatformData* platformData);

    virtual ~VideoDecoder() = default;

    /// Configure and start the decoder
    /**
     * \param width Width of the encoded video.
     * \param height Height of the encoded video.
     * \param codecConfigurationData Additional codec configuration data
     * \param outputCallback Output callback which gets called for every encoded frame
     *
     * \return false if starting failed. This can occur if the provided arguments are not supported or if the platform is currently
     * unable to configure the decoder with the provided arguments (e.g. too many concurrent instances are active)
     * 
     * \returns an empty optional if starting failed. This can occur if the provided arguments are not supported or if the platform is currently
     * unable to configure the decoder with the provided arguments (e.g. too many concurrent instances are active). On success, the pixel format 
     * in which the decoded frames will be provided is returned.
     * 
     * On Android the output format will be NV12 or YUV420P, on all other platforms it will be NV12.
     */
    virtual std::optional<VuforiaDriver::PixelFormat> start(uint16_t width, uint16_t height, const VideoCodecConfigurationData& codecConfigurationData, OutputCallback outputCallback) = 0;

    /// Submit a new sample for decoding
    /**
     * \note To ensure all submitted samples were decoded stop() has to be called before destroying the instance.
     *
     * \param sample Encoded sample data
     * \param presentationTimestampUs Timestamp of this frame in microseconds
     * \param endOfStream Flag to indicate that this is the last sample of the stream.
     *                    On platforms where the input is processed in batches, the last sample of a stream might
     *                    no complete a full batch. Use this flag to signal that the final, partial batch should
     *                    be processed anyway. After submitting a sample with endOfStream set to true, the decoder
     *                    has to be restarted to be usable again.
     * \param timeoutUs Maximum time in microseconds to wait for a free decoder input buffer. If the time is exceeded, the method will return false. (0 = no wait, <0 = infinite wait)
     *
     * \returns true if the sample was successfully queued for decoding
     */
    virtual bool decodeSample(const std::vector<uint8_t>& sample, uint64_t presentationTimestampUs, bool endOfStream, int32_t timeoutUs) = 0;

    /// Returns true if the decoder is able to accept a new sample for decoding without waiting.
    virtual bool canAcceptNewSample() = 0;

    /// Stops the decoding process and waits that all frames that were submitted so far have been completely decoded
    virtual void stop() = 0;
   
    /// \brief Discards all pending data in the input & output queues of the codec.
    /**
     * \returns false if flushing failed
     */
    virtual bool flush() = 0;
    
protected:
    static constexpr uint32_t NALU_ID_SPS = 0x07;
    static constexpr uint32_t NALU_ID_PPS = 0x08;
    static constexpr uint32_t NALU_ID_I_FRAME = 0x05;
    static constexpr uint8_t NALU_HEADER[]{ 0x00, 0x00, 0x00, 0x01 };
    static constexpr uint32_t NALU_HEADER_SIZE = sizeof(NALU_HEADER);

    /// Returns true if the image dimensions are supported for decoding.
    static bool isSupportedResolution(uint16_t width, uint16_t height);

    /// Converts a buffer containing H264 NALUs in AVCC format to Annex B
    /**
     * \returns false on failure
     */
    static bool convertAvccToAnnexB(uint8_t* buffer, size_t bufferSize);

    /// Returns true if the provided buffer contains at least one I-frame NALU.
    /// The input is expected to be in AVCC format.
    static bool containsIFrame(const uint8_t* buffer, size_t bufferSize);

    /// Concatenates the provided codec configuration data into a single buffer containing NALUs in Annex B format
    static std::vector<uint8_t> convertCodecConfigDataToAnnexB(const VideoCodecConfigurationData& codecConfigData);

    /// Prepends an Annex B header to the given buffer
    static void prependAnnexBHeader(std::vector<uint8_t>& naluWithoutHeader);
    
    /// Attempts to determine the vertical stride (in lines, not bytes) of an YUV image based on the size of the buffer
    /**
     * \note this method assumes a YUV 420 based image format (NV12, NV21, YV12, YUV420P). 
     * 
     * \returns the assumed vertical stride. If no appropriate vertical stride was found, the original image height is returned.
     */
    static uint32_t guessVerticalStride(uint32_t horizontalStride, uint32_t imageHeight, size_t bufferSize);

    /// Removes any additional image lines added due to vertical stride (in-place implementation)
    /**
     * \note this method supports YUV 420 based image formats (NV12, NV21, YV12, YUV420P). 
     * 
     * \returns the new buffer size, or 0 if trimming could not be performed.
     */
    static size_t trimVerticalStride(uint8_t* buffer, size_t bufferSize, uint32_t horizontalStride, uint32_t verticalStride, uint32_t imageHeight, VuforiaDriver::PixelFormat imageFormat);
};

} // namespace Platform

#endif // _VIDEODECODER_H_
