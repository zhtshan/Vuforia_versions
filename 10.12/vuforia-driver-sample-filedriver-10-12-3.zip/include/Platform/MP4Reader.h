/*===============================================================================
Copyright (c) 2021 PTC Inc., Its Subsidiary Companies, and /or its Partners.
All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

#ifndef __MP4READER__
#define __MP4READER__

#include "NonCopyable.h"

#include <VuforiaEngine/Driver/Driver.h>

#include <condition_variable>
#include <memory>
#include <mutex>
#include <optional>
#include <thread>
#include <unordered_map>
#include <vector>

namespace VuforiaDriver
{
struct PlatformData;
}

namespace Platform
{

class FileReader;
class VideoDecoder;


/// Predefined MP4 track types (four-character code according to ISO/IEC 14496‐12:2015)
constexpr auto MP4_TRACK_TYPE_VIDEO = "vide";

/// The MP4Reader provides the capability to extract samples sequentially from an MP4 file.
class MP4Reader final : public NonCopyable
{
public:
    using TrackId = uint32_t;
    struct TrackInfo
    {
        TrackId mId{};             // Track ID
        std::string mType{};       // FourCC track type code
        std::string mName{};       // Track name
        uint32_t mNumSamples{};    // Number of samples in the track
        uint32_t mMaxSampleSize{}; // Size in bytes of the largest sample in the track
        uint64_t mDuration{};      // Playback duration of the track in microseconds
        uint16_t mVideoWidth{};    // Video width, if this is a video track
        uint16_t mVideoHeight{};   // Video height, if this is a video track
    };

    struct SampleInfo
    {
        uint64_t mPresentationTimestamp{};    // Timestamp of the read sample as "microseconds since start of the track"
                                              // (excluding any track offset)
        uint64_t mDuration{};                 // Time until the next sample in the track in microseconds
        uint32_t mImageStride{};              // Image stride for video stamples
    };
    
    /// Open a media file
    /**
     * \returns nullptr if the filetype is not supported or the file could not be opened for reading
     */
    static std::unique_ptr<MP4Reader> open(const std::string& file, VuforiaDriver::PlatformData* platformData);
    
    /// Open a media file from app asset storage
    /**
     * \returns nullptr if the filetype is not supported or the file could not be opened for reading
     */
    static std::unique_ptr<MP4Reader> openAsset(const std::string& file, const std::unique_ptr<FileReader>& fileReader, VuforiaDriver::PlatformData* platformData);
    
    ~MP4Reader();
    
    /// Retrieve information about all tracks in the file
    std::vector<TrackInfo> getTracks() const;
    
    /// Retrieve information about all tracks of a specific type in the file
    std::vector<TrackInfo> getTracks(const std::string& type) const;
    
    /*
     * Before starting to read data, it is necessary to select which tracks of the file will
     * be read from using the selectTrack() method. This will ensure that reading the track
     * is actually supported on the current platform and that everything is initialized to
     * start reading from the track.
     * If the select method returns false for a track, it will not be possible to read from it.
     *
     * After a track has been successfully selected for playback, the samples/frames can be
     * read sequentially using readNextSample()/readNextFrame().
     *
     * Reading from multiple tracks at the same time is supported as long as the
     * selectTrack() call returned true.
     */
    
    /// Select a track for playback
    /**
     * \note It is mandatory to call this before starting to read the track using readNextSample/Frame().
     *
     * \returns true on success. If false is returned the track cannot be played back.
     */
    bool selectTrack(TrackId trackId);
        
    /// Reads the next sample from the specified data track.
    /**
     * \param trackId Track from which to read
     * \param sampleOut Sample data output. The vector will be resized to fit the sample.
     *
     * \return An empty optional if reading failed or the end of the track was reached.
     */
    std::optional<SampleInfo> readNextSample(TrackId trackId, std::vector<uint8_t>& sampleOut);

    /// Reads a sample from the specified track.
    /**
     * \param trackId Track from which to read
     * \param sampleIndex Index of the sample that should be read
     * \param sampleOut Sample data output. The vector will be resized to fit the sample.
     *
     * \returns An empty optional if reading failed or the end of the track was reached.
     */
    std::optional<SampleInfo> readSample(TrackId trackId, uint32_t sampleIndex, std::vector<uint8_t>& sampleOut);
    
    /// Reads the next decoded frame from the specified video track.
    /**
     * \param trackId Track from which to read
     * \param frameOut NV12 frame output. The vector will be resized to fit the data.
     *
     * \returns An empty optional if reading failed or the end of the track was reached.
     */
    std::optional<SampleInfo> readNextFrame(TrackId trackId, std::vector<uint8_t>& frameOut);

    /// \brief Changes the playback location for a track
    /**
     * \note The next call to readNextSample()/readNextFrame() will return the sample with the
     * index that was provided when calling the method.
     *
     * \returns true on success
     */
    bool setPlaybackLocation(TrackId trackId, uint32_t sampleIndex);
    
    /// Reads the next decoded frame from the specified video track.
    /**
     * \param trackId Track from which to read
     * \param timestamp Timestamp in microseconds from the start of the track
     *
     * \returns An empty optional if reading failed or the end of the track was reached.
     */
    std::optional<uint32_t> getSampleIndexForTimestamp(TrackId trackId, uint64_t timestamp);

    /// Get the file title
    std::string getTitle() const;
    
    /// Check if the file contains a metadata tag identified by the given key
    bool hasTag(const std::string& key) const;
    
    /// Retrieve the string value of a metadata tag.
    /**
     * \returns Empty optional, if the key doesn't exist or the value is of a different type.
     */
    std::optional<std::string> getStringTag(const std::string& key) const;
    
    /// Retrieve the int32 value of a metadata tag.
    /**
     * \returns Empty optional, if the key doesn't exist or the value is of a different type.
     */
    std::optional<int32_t> getInt32Tag(const std::string& key) const;
    
    /// Retrieve the int64 value of a metadata tag.
    /**
     * \returns Empty optional, if the key doesn't exist or the value is of a different type.
     */
    std::optional<int64_t> getInt64Tag(const std::string& key) const;
    
    /// Retrieve the byte array value of a metadata tag.
    /**
     * \returns Empty optional, if the key doesn't exist or the value is of a different type.
     */
    std::optional<std::vector<uint8_t>> getByteArrayTag(const std::string& key) const;
        
    /// Resets playback for all tracks.
    /**
     * \note This restarts reading from the beginning of the file. Tracks need to be selected again.
     */
    void reset();
    
    /// Resets playback and closes the file.
    void close();

    /// \brief Pauses playback
    /**
     * \note Reading from tracks will fail while playback is paused.
     * \note During pause, all platform decoder instances are stopped.
     */
    void pause();
    
    /// \brief Resumes playback
    bool resume();

    // Returns native color output format from the underlying decoder
    VuforiaDriver::PixelFormat getVideoColorOutputFormat() { return mVideoColorOutputFormat; }

private:
    struct TrackReaderData
    {
        // This is the 1-based mp4v2 SampleID and not an index
        uint32_t mReadLocation{};
        uint32_t mNumSamples{};
        std::unique_ptr<VideoDecoder> mDecoder;
    };
        
    struct FrameOutputData
    {
        std::condition_variable mNextFrameOutputReady;
        uint64_t mElapsedTrackTime{0};
        uint32_t mNumFramesDecoded{};
        uint32_t mNumFramesInTrack{};
        uint32_t mSeekToFrame{};       

        std::vector<uint8_t>* mFrameOutput{nullptr};
        SampleInfo mFrameInfo{};

        // Flag to indicate if decoded frames should be processed (false = drain queue, discard data)
        bool mProcessFrameOutput{true};
    };
    
    MP4Reader(void* fileHandle, VuforiaDriver::PlatformData* platformData);
    
    void onFrameDecoded(TrackId trackId, const uint8_t* image, uint32_t bufferSize, uint32_t stride, uint64_t duration);
    
    bool queueMoreSamplesForDecoding(TrackId trackId);

    bool seekVideoTrackTo(TrackId trackId, uint32_t seekTargetIndex);
    
    std::optional<VuforiaDriver::PixelFormat> startVideoDecoder(TrackId trackId, const std::unique_ptr<VideoDecoder>& decoder);

    VuforiaDriver::PlatformData* mPlatformData{nullptr};
        
    mutable std::mutex mFileMutex;
    void* mFileHandle{};
    std::unordered_map<TrackId, TrackReaderData> mTracks;
    std::vector<uint8_t> mDecoderSampleBuffer;
    
    std::atomic<bool> mIsPaused{ false };
    
    std::mutex mFrameOutputMutex;
    std::unordered_map<TrackId, FrameOutputData> mFrameOutputs;
    VuforiaDriver::PixelFormat mVideoColorOutputFormat { VuforiaDriver::PixelFormat::UNKNOWN };
};

} // namespace Platform

#endif // __MP4READER__
