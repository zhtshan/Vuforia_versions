/*===============================================================================
Copyright (c) 2021 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/
#ifndef _FILEREADER_H_
#define _FILEREADER_H_

#include "FileDriverUserData.h"
#include "NonCopyable.h"

#include "XMLFileReader.h"
#include <VuforiaEngine/Driver/Driver.h>

#include <optional>

static constexpr char DOT_XPGM[] = ".xpgm";

namespace Platform
{
/// Main class for reading image file and driving XMLFileReader.
class FileReader : public NonCopyable
{
public:
    virtual ~FileReader() = default;

    /// Initialize FileReader.
    /**
     * \param platformData Platform specific initialization data provided from Vuforia.
     * \param userData FileDriver specific additional parameters.
     *
     * \return True if initialization succeeded, false otherwise.
     */
    virtual bool init(VuforiaDriver::PlatformData* platformData, FileDriverUserData* userData) = 0;

    /// Deinitializes FileReader.
    /**
     *
     * \return True if deinitialization succeeded, false otherwise.
     */
    virtual bool deInit() = 0;

    /// Read an image file.
    /**
     * \param filename File name to read.
     * \param cameraMode Specifies in which format (pixel format, width and height) should the resulting image be saved in outBytes.
     * \param outBytes Output buffer that will contain the image. The vector is internally resized to the exact size of the output buffer.
     * \param outStride Stride of the output buffer.
     *
     * \return True if file could be read, false otherwise.
     */
    virtual bool readImage(const std::string& filename, VuforiaDriver::CameraMode cameraMode, std::vector<uint8_t>& outBytes, uint32_t& outStride) = 0;

    /// Read an XPGM image file.
    /**
     * \param data pointer to a buffer containing the XPGM file data
     * \param dataLen the length of the data buffer
     * \param cameraMode Specifies in which format (pixel format, width and height) should the resulting image be saved in outBytes.
     * \param outBytes Output buffer that will contain the image. The vector is internally resized to the exact size of the output buffer.
     * \param outStride Stride of the output buffer.
     *
     * \return True if file could be read, false otherwise.
     */
    virtual bool readXPGMImage(const char* data, const size_t dataLen, VuforiaDriver::CameraMode cameraMode, std::vector<uint8_t>& outBytes, uint32_t& outStride) final;

    /// Return true if the file extension is .xpgm
    virtual bool isXPGMFile(const std::string& filename) const final;

    /// Sets up the XML reader to output either camera or pose from the XML recording file.
    /**
     * \param Capability Specify if xml reader should output camera or pose from the XML recording file.
     *
     */
    virtual void setCapability(VuforiaDriver::Capability /*capability*/) {}

    /// Parses XML recording file.
    /**
     * \param filename XML File to parse.
     *
     * \return ElementInfo which contains parsed XML element/tag name and map of all attributes.( <key,value>)
     */
    virtual XMLFileReader::ElementInfo readRecording(const std::string& /*filename*/) = 0;

    /// rewind the recording (camera and pose) so that it can restart from the frame/pose closest to the given timestamp upon subsequent driver start.
    virtual bool rewindRecording(uint64_t timestamp) final { return mXMLReader.rewindRecording(timestamp); }
    
    /// Get the loop count configured in XML
    uint32_t getLoopCount() const { return mXMLReader.getLoopCount(); };
    
    /// Returns the default application asset storage location
    virtual std::string getAppAssetDirectory() const;

    /// Returns true, if an asset with the specified name exists
    virtual bool assetExists(const std::string& name) const;

    /// Returns true, if the provided path points to a regular file
    bool fileExists(const std::string& path) const;

    /// Returns true if the provided path is an asset:// URI
    bool isAssetUri(const std::string& uri) const;

    /// Strips asset:// from an asset URI
    std::string getAssetPathFromAssetUri(const std::string& uri) const;

protected:
    //Internal helper class to manage/parse driver XML file.
    XMLFileReader mXMLReader;
};

} // namespace Platform

#endif // _FILEREADER_H_
