/*===============================================================================
Copyright (c) 2021 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

#ifndef __SAMPLE_PROVIDER_MEDIA_SOURCE__
#define __SAMPLE_PROVIDER_MEDIA_SOURCE__

#include "MediaEventGenerator.h"
#include "ScopedComPtr.h"

#include <atomic>
#include <functional>
#include <mfapi.h>
#include <mfidl.h>
#include <mutex>


namespace Platform::Windows
{

class SampleProviderStreamSource;

/// A MediaSource implementation with a single fixed stream that can provide raw samples 
/// to a MediaSourceReader
class SampleProviderMediaSource : public MediaEventGenerator<IMFMediaSource>
{
public:
    SampleProviderMediaSource(IMFMediaType* inputFormat, size_t maxSampleQueueSize);
    ~SampleProviderMediaSource();

    // IUnknown
    STDMETHODIMP_(ULONG) AddRef() override;
    STDMETHODIMP_(ULONG) Release() override;
    STDMETHODIMP QueryInterface(REFIID iid, void** ppv) override;

    // IMFMediaSource methods
    STDMETHODIMP CreatePresentationDescriptor(IMFPresentationDescriptor **ppPresentationDescriptor) override;
    STDMETHODIMP GetCharacteristics(DWORD *pdwCharacteristics) override;
    STDMETHODIMP Pause() override;
    STDMETHODIMP Start(IMFPresentationDescriptor *pPresentationDescriptor, const GUID *pguidTimeFormat, const PROPVARIANT *pvarStartPosition) override;
    STDMETHODIMP Stop() override;
    STDMETHODIMP Shutdown() override;

    SampleProviderStreamSource* getStreamSource();

    /// The stream ID of the one stream on the sink
    static constexpr DWORD STREAM_ID{ 0 };

private:
    HRESULT initializeStream(size_t maxSampleQueueSize);

    bool mIsStarted{ false };
    std::atomic<ULONG> mRefCount{ 0 };
    std::mutex mInstanceMutex;

    ScopedComPtr<IMFMediaType> mInputFormat;
    ScopedComPtr<IMFPresentationDescriptor> mPresentationDescriptor;
    ScopedComPtr<SampleProviderStreamSource> mStream;

};

} // namespace Platform::Windows

#endif // __SAMPLE_PROVIDER_MEDIA_SOURCE__
