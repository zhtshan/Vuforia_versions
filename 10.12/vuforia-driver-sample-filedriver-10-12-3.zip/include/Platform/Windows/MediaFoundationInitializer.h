/*===============================================================================
Copyright (c) 2022 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

#ifndef __MEDIAFOUNDATIONINITIALIZER__
#define __MEDIAFOUNDATIONINITIALIZER__

namespace Platform::Windows
{

/// RAII helper class to initialize COM, Windows Runtime (on UWP) and Media Foundation
class MediaFoundationInitializer 
{
public:
    MediaFoundationInitializer();
    ~MediaFoundationInitializer();

    bool isRuntimeInitialized() const { return mRuntimeInitializeSuccess; }
    bool isMediaFoundationInitialized() const { return mMfInitializeSuccess; }

private:
    bool mRuntimeInitializeSuccess{ false };
    bool mMfInitializeSuccess{ false };
};

}  // namespace Platform::Windows

#endif // __MEDIAFOUNDATIONINITIALIZER__
