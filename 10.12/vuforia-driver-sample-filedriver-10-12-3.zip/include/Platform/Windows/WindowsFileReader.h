/*===============================================================================
Copyright (c) 2021 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/
#ifndef _WINDOWSFILEREADER_H_
#define _WINDOWSFILEREADER_H_

#include "Platform/FileReader.h"

#include <VuforiaEngine/Driver/Driver.h>

#include <xmllite.h>

namespace Platform
{
namespace Windows
{
/// Windows specific implementation of FileReader.
class WindowsFileReader : public FileReader
{
public:
    bool init(VuforiaDriver::PlatformData* platformData, FileDriverUserData* userData) override;
    bool deInit() override;
    bool readImage(const std::string& filename, VuforiaDriver::CameraMode cameraMode, std::vector<uint8_t>& outBytes, uint32_t& outStride) override;
    XMLFileReader::ElementInfo readRecording(const std::string& filename) override;
    void setCapability(VuforiaDriver::Capability) override;

private:
    uint32_t mCapability{ 0 };
    std::string mRecordingDirectoryAbsolutePath;
    bool mCoInitialized{ false };
};

} // Windows
} // Platform

#endif // _WINDOWSFILEREADER_H_
