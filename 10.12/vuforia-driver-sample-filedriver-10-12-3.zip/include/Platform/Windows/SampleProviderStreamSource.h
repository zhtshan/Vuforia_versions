/*===============================================================================
Copyright (c) 2021 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

#ifndef __SAMPLE_PROVIDER_STREAM_SOURCE__
#define __SAMPLE_PROVIDER_STREAM_SOURCE__

#include "MediaEventGenerator.h"
#include "ScopedComPtr.h"

#include <atomic>
#include <condition_variable>
#include <functional>
#include <list>
#include <mfapi.h>
#include <mfidl.h>
#include <mutex>

namespace Platform::Windows
{

/// Implementation of an IMFMediaStream that allows queueing of custom 
/// sample buffers for decoding by an IMFSourceReader.
class SampleProviderStreamSource : public MediaEventGenerator<IMFMediaStream>
{
public:
    SampleProviderStreamSource(IMFMediaSource* mediaSource, IMFStreamDescriptor* streamDescriptor, size_t maxSampleQueueSize);
    ~SampleProviderStreamSource();

    // IUnknown
    STDMETHODIMP_(ULONG) AddRef() override;
    STDMETHODIMP_(ULONG) Release() override;
    STDMETHODIMP QueryInterface(REFIID iid, void** ppv) override;

    // IMFMediaStream methods
    STDMETHODIMP GetMediaSource(IMFMediaSource **ppMediaSource) override;
    STDMETHODIMP GetStreamDescriptor(IMFStreamDescriptor **ppStreamDescriptor) override;
    STDMETHODIMP RequestSample(IUnknown *pToken) override;

    bool enqueueSample(IMFSample* sample, int32_t timeoutUs);
    bool canEnqueueWithoutWait();
    void notifyEndOfStream();
    void waitForEmptySampleQueue();

private:
    HRESULT sendEndOfStreamEvents();

    std::atomic<ULONG> mRefCount{ 0 };
    std::mutex mInstanceMutex;
    
    ScopedComPtr<IMFMediaSource> mMediaSource;
    ScopedComPtr<IMFStreamDescriptor> mStreamDescriptor;

    std::mutex mSampleQueueMutex;
    std::condition_variable mSampleQueueCv;
    const size_t mMaxQueueSize;
    bool mEndOfStream{ false };
    std::list<ScopedComPtr<IMFSample>> mSampleQueue;
};

} // namespace Platform::Windows

#endif // __SAMPLE_PROVIDER_STREAM_SOURCE__
