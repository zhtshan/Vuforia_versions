/*===============================================================================
Copyright (c) 2021 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

#ifndef __SOURCE_READER_CALLBACK__
#define __SOURCE_READER_CALLBACK__

#include <atomic>
#include <functional>
#include <mfidl.h>
#include <mfreadwrite.h>
#include <mutex>

namespace Platform::Windows
{

/// Implementation of an IMFSourceReaderCallback that the IMFSourceReader
/// will call when a frame completed decoding.
class SourceReaderCallback : public IMFSourceReaderCallback
{
public:
    using SampleCallback = std::function<void(HRESULT hrStatus, IMFSample* pSample, LONGLONG llTimestamp, DWORD dwStreamFlags)>;

    SourceReaderCallback(SampleCallback sampleCallback);
    ~SourceReaderCallback();

    // IUnknown
    STDMETHODIMP_(ULONG) AddRef() override;
    STDMETHODIMP_(ULONG) Release() override;
    STDMETHODIMP QueryInterface(REFIID iid, void** ppv) override;

    // IMFSourceReaderCallback methods
    STDMETHODIMP OnEvent(DWORD dwStreamIndex, IMFMediaEvent* pEvent) override;
    STDMETHODIMP OnFlush(DWORD dwStreamIndex) override;
    STDMETHODIMP OnReadSample(HRESULT hrStatus, DWORD dwStreamIndex, DWORD dwStreamFlags, LONGLONG llTimestamp, IMFSample* pSample) override;

private:
    std::atomic<ULONG> mRefCount{ 0 };

    std::mutex mInstanceMutex;
    SampleCallback mCallback;
};

} // namespace Platform::Windows

#endif // __SOURCE_READER_CALLBACK__
