/*===============================================================================
Copyright (c) 2022 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/
#ifndef _FILEDRIVERPLAYBACKCONTROLLER_H_
#define _FILEDRIVERPLAYBACKCONTROLLER_H_

#include <VuforiaEngine/Driver/Driver.h>

/// This defines an API that can be used to control the playback behavior of FileDriver.
/**
 * \note These functions can only be called after the driver has been initialized
 * by the engine.
 */
#ifdef __cplusplus
extern "C"
{
#endif

/// The playback mode determines how FileDriver plays the sequence
typedef uint32_t FileDriverPlaybackMode;
enum
{
    FILEDRIVER_PLAYBACK_MODE_RESPECT  = 0, ///< Respect the timestamps of the recording and play it in real time.
                                           ///< If the engine cannot keep up, frames will be dropped.
    FILEDRIVER_PLAYBACK_MODE_WAIT = 1      ///< Play the recording as fast as possible while waiting for
                                           ///< the engine to complete processing of every frame.
};

/// Sets the playback start position in the currently loaded sequence
/**
 * \note When this method is called, the playback will be restarted at the specified position on next engine start.
 * \note Playback will start with the video frame whose timestamp is closest to the provided timestamp.
 *
 * \param timestamp The timestamp at which playback should start. This is the time in milliseconds
 *                  relative to the start of the sequence.
 *
 * \returns false if the operation failed or the driver is not initialized.
 */
VUFORIA_DRIVER_API_EXPORT bool VUFORIA_DRIVER_CALLING_CONVENTION fileDriverSetPlaybackStartTime(uint64_t timestamp);

/// Sets the playback end position in the currently loaded sequence
/**
 * \note Playback will end with the first video frame whose timestamp is >= the provided timestamp.
 *
 * \param timestamp The timestamp at which playback should end. This is the time in milliseconds
 *                  relative to the start of the sequence.
 *
 * \returns false if the operation failed or the driver is not initialized.
 */
VUFORIA_DRIVER_API_EXPORT bool VUFORIA_DRIVER_CALLING_CONVENTION fileDriverSetPlaybackEndTime(uint64_t timestamp);

/// Configures looping of sequence playback
/**
 * \param loopCount Setting this to zero enables infinite looping. Any other values indicates 
 *                  that the sequence should be played a limited number of times.
 *
 * \returns false if the operation failed or the driver is not initialized.
 */
VUFORIA_DRIVER_API_EXPORT bool VUFORIA_DRIVER_CALLING_CONVENTION fileDriverSetPlaybackLoop(uint32_t loopCount);

/// Configures the playback behavior of the driver
/**
 * \note The default playback mode is FILEDRIVER_PLAYBACK_MODE_RESPECT.
 *
 * \returns false if the operation failed or the driver is not initialized.
 */
VUFORIA_DRIVER_API_EXPORT bool VUFORIA_DRIVER_CALLING_CONVENTION fileDriverSetPlaybackMode(FileDriverPlaybackMode mode);

/// Get the duration of the currently loaded sequence in milliseconds
/**
 * \returns the duration in milliseconds or 0 if no sequence is currently loaded. 
 */
VUFORIA_DRIVER_API_EXPORT uint64_t VUFORIA_DRIVER_CALLING_CONVENTION fileDriverGetSequenceDuration();

/// Get the current playback position in milliseconds (relative to the start of the sequence)
VUFORIA_DRIVER_API_EXPORT uint64_t VUFORIA_DRIVER_CALLING_CONVENTION fileDriverGetPlaybackPosition();

#ifdef __cplusplus
}
#endif

#endif // _FILEDRIVERPLAYBACKCONTROLLER_H_
