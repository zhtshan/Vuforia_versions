/*===============================================================================
Copyright (c) 2021 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/
#ifndef _XML_FILEREADER_H_
#define _XML_FILEREADER_H_

#include "NonCopyable.h"

#include "pugixml.hpp"
#include <VuforiaEngine/Driver/Driver.h>

#include <string>
#include <vector>
#include <unordered_map>

/// XML file containing camera and pose recording.
static constexpr char DRIVER_SEQ_FILE[]  = "FileDriverRecording.xml";

constexpr static int NUMBER_OF_ROTN_VALUES                = 9;
constexpr static int NUMBER_OF_RAD_DIST_VALUES            = 8;
constexpr static int NUMBER_OF_CAM_TO_DEV_EXTRN_VALUES    = 12;

/// class for reading driver XML file
class XMLFileReader final: public NonCopyable
{
public:

    /// forward declaration for parameter use.
    class Version;

    /// structure to store parsed XML element name along with map of all attributes(<key,value>).
    struct ElementInfo
    {
        std::string elementName{""};
        std::unordered_map<std::string, std::string> attributeMap;
    };

    /// structure to store the entire recording information.
    struct RecordingInfo
    {
        std::vector<ElementInfo> metaDataVector;
        std::vector<ElementInfo> cameraVector;
        std::vector<ElementInfo> poseVector;
        uint32_t                 metaDataIndex{};
        uint32_t                 cameraFrameIndex{};
        uint32_t                 poseIndex{};
        int                      loopCounter{};
    };

    /// loads the data from XML file and stores it into vectors containing camera frame and pose information.
    virtual bool load(const char* filename) final;
    /// loads the data from a buffer and stores it into vectors containing camera frame and pose information.
    virtual bool load(const void* buffer = nullptr, int size = 0) final;

    /// returns next Element (Frame or Pose depending on capability passed in) from parsed XML file.
    virtual XMLFileReader::ElementInfo getNextElement(uint32_t) final;

    /// rewind the recording (camera and pose) so that it can restart from the frame/pose closest to the given timestamp upon subsequent driver start.
    bool rewindRecording(uint64_t timestamp);
    
    /// clear all the vectors and reset parsing state.
    virtual void clear() final
    {
        mRecordingInfo.metaDataVector.clear();
        mRecordingInfo.cameraVector.clear();
        mRecordingInfo.poseVector.clear();
        mRecordingInfo.metaDataIndex = 0;
        mRecordingInfo.cameraFrameIndex = 0;
        mRecordingInfo.poseIndex = 0;
        mRecordingInfo.loopCounter = 0;
        mParsingDone = false;
    }
    
    /// Get the loop count configured in XML
    uint32_t getLoopCount() const;

    /// check if recording format version is supported.
    static bool isFormatVersionSupported(Version version);

    /// get a list of supported file format versions for logging purposes.
    static std::string listSupportedFormatVersions();

    /// a wrapper for managing and comparing version numbers.
    class Version
    {
    public:

        /// construct an instance to be initialized using the = operator.
        Version() = default;

        /// initialize by parsing the passed version string to a major and a minor version number.
        /**
         * \param versionStr should have an major.minor form, e.g. 2.1 - otherwise the version number will be set to 0.0
         */
        Version(const char* versionStr);

        ~Version() = default;

        /// initialize by parsing the passed version string to a major and a minor version number.
        /**
         * \param versionStr assumed to have a major.minor form, e.g. 2.1 - no sanity checking is performed.
         */
        void operator=(std::string versionStr);

        // Note: a limited set of binary comparison operators is provided. It's the caller's responsibility
        // to ensure that no operator other than the available ones is called.

        bool operator>(double version) const;

        bool operator==(double version) const;

        bool operator==(const Version& other) const;

        bool operator>=(double version) const;

        /// get a string representation, e.g. for logging purposes.
        std::string toString() const;

    private:

        /// reset the major and minor version numbers, as well as the float representation to 0's.
        void resetNumbers();

    private:

        uint32_t mMajor{ 0 };

        uint32_t mMinor{ 0 };

        /// a decimal representation for comparisons.
        /**
         * this is updated whenever the assignment operator is called. It serves as a cache that prevents
         * conversion on every comparison.
         */
        double mCachedCopy{ 0.0 };

        static constexpr auto DOT = ".";

    };

private:
    bool           mParsingDone{false};
    bool           mStartedParsingFrame {false};

    std::string    mElementTS; //Timestamp for currently parsed Element in nano seconds
    std::string    mElementPresTS;//Presentation timestamp for currently parsed Element in nano seconds
    pugi::xml_node mXmlRoot;

    //structure to store the recording information
    XMLFileReader::RecordingInfo mRecordingInfo;
    XMLFileReader::ElementInfo getNodeInfo(pugi::xml_node, bool&);

    void populateFramesAndPosesVector();
    static const std::vector<Version> SUPPORTED_FORMAT_VERSIONS;

    /// stores the version parsed from the recording file.
    Version mFormatVersion;
};

#endif // _XML_FILEREADER_H_
