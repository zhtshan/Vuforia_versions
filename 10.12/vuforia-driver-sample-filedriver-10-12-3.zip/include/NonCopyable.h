/*===============================================================================
Copyright (c) 2021 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/
#ifndef _NONCOPYABLE_H_
#define _NONCOPYABLE_H_

/// Class to disable copy and assignment constructors and therefore prevent copies.
class NonCopyable
{
public:
    NonCopyable() = default;

private:
    NonCopyable(const NonCopyable&) = delete;
    NonCopyable& operator=(const NonCopyable&) = delete;
};

#endif // _NONCOPYABLE_H_
