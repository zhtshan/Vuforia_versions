/*===============================================================================
Copyright (c) 2021 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/
#include "RGBAPixelConverter.h"
#include "Platform/Platform.h"

#include <algorithm>

// Well known values for converting RGB to Y, U and V in integer format.
#define YFromRGB(R, G, B) ( (  66 * R + 129 * G +  25 * B) >> 8) + 16;
#define UFromRGB(R, G, B) ( ( -38 * R -  74 * G + 112 * B) >> 8) + 128;
#define VFromRGB(R, G, B) ( ( 112 * R -  94 * G -  18 * B) >> 8) + 128;

namespace
{
struct RGBAOffsets
{
    unsigned int r;
    unsigned int g;
    unsigned int b;
    unsigned int a;
};

// Returns the offset to each color channel withing a single pixel
// represented in unsigned char pixel[4].
RGBAOffsets
getChannelOffsets(RGBAPixelConverter::ChannelOrder order)
{
    switch (order)
    {
        case RGBAPixelConverter::ChannelOrder::RGBA:
            return { 0, 1, 2, 3 };
        case RGBAPixelConverter::ChannelOrder::BGRA:
            return { 2, 1, 0, 3 };
        default:
            Platform::log("Error fetching RGBA offsets.");
    }
    return { 0, 0, 0, 0 };
}

uint8_t
clamp0_255(int val)
{
    return static_cast<uint8_t> (std::max(0, std::min(255, val)));
}
}

bool
RGBAPixelConverter::convert(VuforiaDriver::PixelFormat dstPixelFormat,
    const uint8_t* srcPixelBuffer,
    int srcWidth, int srcHeight,
    ChannelOrder srcChannelOrder,
    std::vector<uint8_t>& dstPixelBuffer,
    uint32_t& dstStride)
{
    switch (dstPixelFormat)
    {
        case VuforiaDriver::PixelFormat::YUYV:
            return convertToYUYV(srcPixelBuffer, srcWidth, srcHeight, srcChannelOrder, dstPixelBuffer, dstStride);
        case VuforiaDriver::PixelFormat::NV21:
            return convertToYUV420(srcPixelBuffer, srcWidth, srcHeight, srcChannelOrder, dstPixelFormat, dstPixelBuffer, dstStride);
        case VuforiaDriver::PixelFormat::NV12:
            return convertToYUV420(srcPixelBuffer, srcWidth, srcHeight, srcChannelOrder, dstPixelFormat, dstPixelBuffer, dstStride);
        case VuforiaDriver::PixelFormat::UNKNOWN:
        default:
            Platform::log("Unsupported conversion");
            break;
    }
    return false;
}

bool
RGBAPixelConverter::convertToYUYV(const uint8_t* srcPixelBuffer,
    int srcWidth,
    int srcHeight,
    ChannelOrder srcChannelOrder,
    std::vector<uint8_t>& dstPixelBuffer,
    uint32_t& dstStride)
{
    if (srcWidth % 2 != 0 || srcHeight % 2 != 0)
    {
        Platform::log("Error: YUYV resolution not divisible by 2.");
        return false;
    }

    // Calculate how many bytes are needed for the destination buffer
    // and resize it to correct size.
    const int ySize = srcWidth * srcHeight;
    const int uSize = (ySize) / 2;
    const int vSize = (ySize) / 2;
    const size_t yuyvByteSize = ySize + uSize + vSize;
    if (dstPixelBuffer.size() != yuyvByteSize)
    {
        dstPixelBuffer.resize(yuyvByteSize);
    }

    // YUYV has the following order of elements, where each element is a 8bit uint:
    // [ Y0 | U0 | Y1 | V0 ]
    // The following strides tell how many bytes are in between two values.
    const int YStride = 2;
    const int UStride = 4;
    const int VStride = 4;

    const int rgbaStride = 4;

    // Get offsets that correspond to the provided rgba channel ordering.
    const auto offsets = getChannelOffsets(srcChannelOrder);

    // Introduce temporary variables, so they don't need to be created on every loop.
    int R0 = 0;
    int G0 = 0;
    int B0 = 0;
    int R1 = 0;
    int G1 = 0;
    int B1 = 0;
    int R_avg = 0;
    int G_avg = 0;
    int B_avg = 0;
    int Y = 0;
    int U = 0;
    int V = 0;

    // srcIndex is used to iterate the source buffer.
    unsigned int srcIndex = 0;

    // Introduce index variables that are used as pointers to the destination buffer.
    // Initialize the values to point to the first element of each channel.
    unsigned int yIndex = 0;
    unsigned int uIndex = 1;
    unsigned int vIndex = 3;

    // The loop processes two input RGBA pixels and outputs corresponding two Y-values,
    // one U-value and one V-value.
    for (int y = 0; y < srcHeight; y++)
    {
        for (int x = 0; x < srcWidth / 2; x++)
        {
            // Extract the first rgba value and add a corresponding Y into the destination buffer.
            R0 = srcPixelBuffer[srcIndex + offsets.r];
            G0 = srcPixelBuffer[srcIndex + offsets.g];
            B0 = srcPixelBuffer[srcIndex + offsets.b];
            Y = YFromRGB(R0, G0, B0);
            dstPixelBuffer[yIndex] = clamp0_255(Y);
            yIndex += YStride;
            srcIndex += rgbaStride;

            // Extract the second rgba and add the Y.
            R1 = srcPixelBuffer[srcIndex + offsets.r];
            G1 = srcPixelBuffer[srcIndex + offsets.g];
            B1 = srcPixelBuffer[srcIndex + offsets.b];
            Y = YFromRGB(R1, G1, B1);
            dstPixelBuffer[yIndex] = clamp0_255(Y);
            yIndex += YStride;
            srcIndex += rgbaStride;

            // Create aggregate RGB values as a single UV-pair correspond to two RGB pixel.
            R_avg = (R0 + R1) / 2;
            G_avg = (G0 + G1) / 2;
            B_avg = (B0 + B1) / 2;

            // Place U and V into the output buffer.
            U = UFromRGB(R_avg, G_avg, B_avg);
            V = VFromRGB(R_avg, G_avg, B_avg);
            dstPixelBuffer[uIndex] = clamp0_255(U);
            uIndex += UStride;
            dstPixelBuffer[vIndex] = clamp0_255(V);
            vIndex += VStride;
        }
    }
    dstStride = srcWidth * 2;
    return true;
}

bool
RGBAPixelConverter::convertToYUV420(const uint8_t* srcPixelBuffer,
    int srcWidth,
    int srcHeight,
    ChannelOrder srcChannelOrder,
    VuforiaDriver::PixelFormat dstPixelFormat,
    std::vector<uint8_t>& dstPixelBuffer,
    uint32_t& dstStride)
{
    if (srcWidth % 4 != 0 || srcHeight % 4 != 0)
    {
        Platform::log("Error: YUV420 resolution not divisible by 4.");
        return false;
    }

    // Calculate how many bytes are needed for the destination buffer
    // and resize it to correct size.
    const int ySize = srcWidth * srcHeight;
    const int uSize = srcWidth * srcHeight / 4;
    const int vSize = srcWidth * srcHeight / 4;
    const size_t yuvByteSize = ySize + vSize + uSize;
    if (dstPixelBuffer.size() != yuvByteSize)
    {
        dstPixelBuffer.resize(yuvByteSize);
    }

    // Strides of the source buffer. rgbaStride is basically just telling
    // that there are 4 bytes between each rgba-tuple.
    const int rgbaStride = 4;
    const int srcStride = srcWidth * rgbaStride;
    const int destYStride = srcWidth;

    // Get offsets that correspond to the provided rgba channel ordering.
    const auto offsets = getChannelOffsets(srcChannelOrder);

    // Introduce temporary variables, so they don't need to be created on every loop.
    int R_row0 = 0;
    int G_row0 = 0;
    int B_row0 = 0;
    int R_row1 = 0;
    int G_row1 = 0;
    int B_row1 = 0;
    int R_aggr = 0;
    int G_aggr = 0;
    int B_aggr = 0;
    int Y = 0;
    int U = 0;
    int V = 0;

    // srcIndex is used to iterate the source buffer.
    unsigned int srcIndex = 0;

    // Introduce index variables that are used as pointers to the destination buffer.
    // Initialize the values to point to the first element of each channel.
    // UV-plane starts when Y-ends.
    unsigned int uvIndex = ySize;
    unsigned int yIndex = 0;

    // This processes a 2x2 window in one loop and outputs four Y-values, one U-value and one V-value.
    // This is due the fact that a single U and V value corresponds to 2x2 pixel window in the original image.
    for (int y = 0; y < srcHeight / 2; y++)
    {
        for (int x = 0; x < srcWidth / 2; x++)
        {
            R_aggr = 0;
            G_aggr = 0;
            B_aggr = 0;

            // Each iteration of this loop processes two input rgba pixels with the same x-value
            // ie. two rows at once.
            for (int i = 0; i < 2; ++i)
            {
                // RGB values from the first row.
                R_row0 = srcPixelBuffer[srcIndex + offsets.r];
                G_row0 = srcPixelBuffer[srcIndex + offsets.g];
                B_row0 = srcPixelBuffer[srcIndex + offsets.b];
                Y = YFromRGB(R_row0, G_row0, B_row0);
                dstPixelBuffer[yIndex] = clamp0_255(Y);

                // RGB values from the second row.
                R_row1 = srcPixelBuffer[srcStride + srcIndex + offsets.r];
                G_row1 = srcPixelBuffer[srcStride + srcIndex + offsets.g];
                B_row1 = srcPixelBuffer[srcStride + srcIndex + offsets.b];
                Y = YFromRGB(R_row1, G_row1, B_row1);
                dstPixelBuffer[destYStride + yIndex] = clamp0_255(Y);

                // Add to aggregates which will be used to form U and V.
                R_aggr += (R_row0 + R_row1);
                G_aggr += (G_row0 + G_row1);
                B_aggr += (B_row0 + B_row1);

                // Advance to the next input pixel horizontally. Skips alpha (index 3) as it is not needed.
                srcIndex += rgbaStride;

                // Advance to the next output pixel horizontally.
                yIndex++;
            }

            // U and V are written for every other row for two columns.
            // ie. 1 U+V correspond to 4 Y values.
            R_aggr /= 4;
            G_aggr /= 4;
            B_aggr /= 4;
            U = UFromRGB(R_aggr, G_aggr, B_aggr);
            V = VFromRGB(R_aggr, G_aggr, B_aggr);

            // The only difference between NV21 and NV12 is the UV-order.
            // NV12: order is UV
            // NV21: order is VU
            if (dstPixelFormat == VuforiaDriver::PixelFormat::NV12)
            {
                dstPixelBuffer[uvIndex++] = clamp0_255(U);
                dstPixelBuffer[uvIndex++] = clamp0_255(V);
            }
            else if (dstPixelFormat == VuforiaDriver::PixelFormat::NV21)
            {
                dstPixelBuffer[uvIndex++] = clamp0_255(V);
                dstPixelBuffer[uvIndex++] = clamp0_255(U);
            }
        }

        // Skip a horizontal line as we go 2 lines per loop
        srcIndex += srcStride;
        yIndex += srcWidth;
    }

    dstStride = srcWidth;
    return true;
}
