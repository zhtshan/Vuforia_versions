/*===============================================================================
Copyright (c) 2021 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

#include "Platform/FileReader.h"

#include "Platform/Platform.h"

#include <algorithm>
#include <cassert>
#include <istream>
#include <string>
#include <string_view>
#include <sstream>
#include <sys/stat.h>

namespace
{

static constexpr std::string_view ASSET_URI_PREFIX = "asset://";

/// Class implementing a stream over a memory buffer
class MemoryStreamBuf : public std::streambuf
{
public:
    MemoryStreamBuf(const char* begin, const char* end)
    {
        this->setg(const_cast<char*>(begin), const_cast<char*>(begin), const_cast<char*>(end));
    }

    pos_type seekoff(off_type off, std::ios_base::seekdir dir, std::ios_base::openmode which = std::ios_base::in) override
    {
        (void)which; // avoid unused parameter warning
        assert(which == std::ios_base::in);
        if (dir == std::ios_base::cur)
            gbump(int(off));
        else if (dir == std::ios_base::end)
            setg(eback(), egptr() + off, egptr());
        else if (dir == std::ios_base::beg)
            setg(eback(), eback() + off, egptr());
        return gptr() - eback();
    }

    pos_type seekpos(pos_type sp, std::ios_base::openmode which) override
    {
        return seekoff(sp - pos_type(off_type(0)), std::ios_base::beg, which);
    }
};

} // namespace


namespace Platform
{
bool
FileReader::readXPGMImage(const char* data, const size_t dataLen, VuforiaDriver::CameraMode cameraMode, std::vector<uint8_t>& outBytes, uint32_t& outStride)
{
    std::stringstream logmsg;
    std::string line;

    bool isNV21 = false;
    uint32_t w = 0, h = 0;
    int maxval = 0;

    MemoryStreamBuf dataBuffer(data, data + dataLen);
    std::istream in(&dataBuffer);
    auto start = in.tellg();

    // Read magic number
    std::getline(in, line);
    if (line != "P5")
    {
        Platform::log("Error: Failed to read magic number from XPGM header");
        return false;
    }

    // Read comments, look for NV21 flag
    while ((in >> std::ws).peek() == '#')
    {
        std::getline(in, line);
        if (line == "# NV21")
        {
            isNV21 = true;
        }
    }

    // Read image dimensions
    if (!(in >> w >> h))
    {
        Platform::log("Error: Failed to read dimensions from XPGM header");
        return false;
    }
    if (w != cameraMode.width || h != cameraMode.height)
    {
        Platform::log("Error: Image dimensions in XPGM header don't match camera mode");
        return false;
    }

    // Read pixel maxval
    if (!(in >> maxval) || maxval != 255)
    {
        Platform::log("Error: Unexpected value for maxval in XPGM header");
        return false;
    }

    // There should be exactly 1 byte ('\n') between maxval and the start of pixels
    char b;
    in.read(&b, 1);

    size_t startOfPixels = size_t(in.tellg() - start);

    size_t numBytes = isNV21 ? ( (w * h) + (w * (h / 2)) ) : (w * h);
    if (numBytes > dataLen - startOfPixels)
    {
        Platform::log("Error: Not enough pixel data for image dimensions");
        return false;
    }

    // Resize the output array if needed
    if (outBytes.size() != numBytes)
    {
        outBytes.resize(numBytes);
    }

    // Copy values to output
    outStride = w;
    in.read(reinterpret_cast<char*>(outBytes.data()), numBytes);

    return true;
}


bool
FileReader::isXPGMFile(const std::string& filename) const
{
    const std::string dotxpgm(DOT_XPGM);
    if (filename.compare(filename.length() - dotxpgm.length(), dotxpgm.length(), dotxpgm) == 0)
    {
        return true;
    }
    return false;
}


std::string 
FileReader::getAppAssetDirectory() const
{ 
    return {}; 
}


bool 
FileReader::assetExists(const std::string& name) const
{
    return fileExists(getAppAssetDirectory() + name);
}


bool 
FileReader::fileExists(const std::string& path) const
{
    struct stat fileInfo;
    return stat(path.c_str(), &fileInfo) == 0 && (fileInfo.st_mode & S_IFMT) == S_IFREG;    
}


bool 
FileReader::isAssetUri(const std::string& uri) const
{
    return uri.rfind(ASSET_URI_PREFIX, 0) == 0 && uri.length() > ASSET_URI_PREFIX.length();
}


std::string 
FileReader::getAssetPathFromAssetUri(const std::string& uri) const
{
    return uri.substr(ASSET_URI_PREFIX.length());
}

} // namespace Platform
