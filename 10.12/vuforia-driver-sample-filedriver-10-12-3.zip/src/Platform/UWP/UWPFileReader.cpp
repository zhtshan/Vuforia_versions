/*===============================================================================
Copyright (c) 2021 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/
#include "Platform/UWP/UWPFileReader.h"

#include "FileDriverUserData.h"
#include "Platform/Platform.h"
#include "RGBAPixelConverter.h"

#include <MemoryBuffer.h>
#include <ppltasks.h>
#include <shcore.h>

#include <cassert>
#include <string>
#include <vector>

using namespace Microsoft::WRL;
using namespace Windows::Storage;
using namespace Windows::Storage::Streams;

using namespace concurrency;
using namespace Windows::Foundation;
using namespace Windows::Graphics::Imaging;

std::string wStrToStdString(PCWSTR param)
{
    assert(param != nullptr);

    int paramLength = int(std::wcslen(param));
    if (paramLength > 0)
    {
        int length = ::WideCharToMultiByte(CP_ACP, 0, param, paramLength, NULL, 0, NULL, NULL);
        if (length == 0)
        {
            return std::string();
        }

        std::vector<char> buffer(length);
        ::WideCharToMultiByte(CP_ACP, 0, param, paramLength, &buffer[0], length, NULL, NULL);

        return std::string(buffer.begin(), buffer.end());
    }
    else
    {
        return std::string();
    }
}

namespace Platform
{
namespace UWP
{
bool
UWPFileReader::init(VuforiaDriver::PlatformData* /* platformData */, FileDriverUserData* userData)
{
    std::string sequenceDirectoryAbsolutePath;
    if (userData != nullptr)
    {
        sequenceDirectoryAbsolutePath = userData->sequenceDirectoryAbsolutePath;
    }

    // Use the absolute path, if the user has provided one. Otherwise default to appx-package root.
    if (!sequenceDirectoryAbsolutePath.empty())
    {
        mRecordingFolderPath = getHString(sequenceDirectoryAbsolutePath);
    }
    else
    {
        mRecordingFolderPath = Windows::ApplicationModel::Package::Current->InstalledLocation->Path;
    }

    return true;
}

bool UWPFileReader::deInit()
{
    mXMLReader.clear();
    return true;
}
bool
UWPFileReader::readImage(const std::string& filename, VuforiaDriver::CameraMode cameraMode, std::vector<uint8_t>& outBytes, uint32_t& outStride)
{
    if (mRecordingFolder == nullptr && !openFolder())
    {
        Platform::log("Failed to open recording directory");
        return false;
    }

    try
    {
        StorageFile^ file;
        //replace forward slash with backward slash as former one will cause exception while creating the task. 
        std::string updatedFileName = filename;
        std::replace(updatedFileName.begin(), updatedFileName.end(), '/', '\\');
        String ^ strFileName = getHString(updatedFileName);
        file = create_task(mRecordingFolder->GetFileAsync(strFileName)).get();

        if (isXPGMFile(filename))
        {
            auto fileBuffer = create_task(FileIO::ReadBufferAsync(file)).get();

            auto byteArray = ref new Platform::Array<BYTE>(fileBuffer->Length);
            Streams::DataReader::FromBuffer(fileBuffer)->ReadBytes(byteArray);

            return readXPGMImage(reinterpret_cast<char*>(byteArray->Data), byteArray->Length, cameraMode, outBytes, outStride);
        }
        else
        {
            uint8_t* pixelBuffer;
            UINT32 pixelBufferSize;
            auto stream        = create_task(file->OpenReadAsync()).get();
            auto bitmapDecoder = create_task(BitmapDecoder::CreateAsync(stream)).get();
            auto bitmap        = create_task(bitmapDecoder->GetSoftwareBitmapAsync(Windows::Graphics::Imaging::BitmapPixelFormat::Bgra8, Windows::Graphics::Imaging::BitmapAlphaMode::Ignore)).get();
            auto bitmapBuffer  = bitmap->LockBuffer(BitmapBufferAccessMode::ReadWrite);

            IMemoryBufferReference^ reference = bitmapBuffer->CreateReference();

            Microsoft::WRL::ComPtr<IMemoryBufferByteAccess> pBufferByteAccess;
            if ((reinterpret_cast<IInspectable*>(reference)->QueryInterface(IID_PPV_ARGS(&pBufferByteAccess))) != S_OK)
            {
                return false;
            }

            if (pBufferByteAccess->GetBuffer(&pixelBuffer, &pixelBufferSize) != S_OK)
            {
                return false;
            };

            return RGBAPixelConverter::convert(cameraMode.format,
                                        pixelBuffer,
                                        cameraMode.width, cameraMode.height,
                                        RGBAPixelConverter::ChannelOrder::BGRA,
                                        outBytes, outStride);
        }
    }
    catch (Platform::Exception^ e)
    {
        Platform::log("File open failed:");
        std::string msg = getStdString(e->Message);
        Platform::log(msg);
    }

    return false;
}

XMLFileReader::ElementInfo UWPFileReader::readRecording(const std::string& filename)
{
    XMLFileReader::ElementInfo retSeqInfo;

    if (mRecordingFolder == nullptr && !openFolder())
    {
        Platform::log("Failed to open recording directory");
        return retSeqInfo;
    }
    
    std::string fullpath = getStdString(mRecordingFolderPath) + "\\" + filename;
    if(mXMLReader.load((const char*)fullpath.c_str()))
    {
        retSeqInfo = mXMLReader.getNextElement(mCapability);
    }
    return retSeqInfo;
}


void UWPFileReader::setCapability(VuforiaDriver::Capability capability)
{
    //reader will send out data based on capability.
    if( ((capability & VuforiaDriver::Capability::CAMERA_POSE)  != VuforiaDriver::Capability::CAMERA_POSE) &&
        ((capability & VuforiaDriver::Capability::CAMERA_IMAGE) != VuforiaDriver::Capability::CAMERA_IMAGE) )
    {
        Platform::log("Invalid capability "+std::to_string(capability)+". Expected "+
                      std::to_string(VuforiaDriver::Capability::CAMERA_IMAGE)+" or "+std::to_string(VuforiaDriver::Capability::CAMERA_POSE));
    }
    else
    {
        mCapability = capability;
    }

}

Platform::String^
UWPFileReader::getHString(const std::string& str)
{
    wchar_t* wstr = new wchar_t[str.length()];
    int hStrCount = ::MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, str.c_str(), static_cast<int>(str.length()), wstr, static_cast<int>(str.length()));
    String^ hStr = ref new String(wstr, hStrCount);
    delete wstr;

    return hStr;
}

std::string
UWPFileReader::getStdString(Platform::String^ str) const
{
    return wStrToStdString(str->Data());
}


std::string 
UWPFileReader::getAppAssetDirectory() const
{
    return getStdString(Windows::ApplicationModel::Package::Current->InstalledLocation->Path) + "\\";
}

bool 
UWPFileReader::openFolder()
{
    try
    {
        // Try absolute path
        mRecordingFolder = create_task(StorageFolder::GetFolderFromPathAsync(mRecordingFolderPath)).get();
    }
    catch (Platform::InvalidArgumentException^)
    {
        try
        {
            // Try relative to the LocalState folder
            mRecordingFolder = create_task(Windows::Storage::ApplicationData::Current->LocalFolder->GetFolderAsync(mRecordingFolderPath)).get();
        }
        catch (Platform::InvalidArgumentException^)
        {
            Platform::log("Invalid recording path");
            return false;
        }
        catch (Platform::COMException^)
        {
            Platform::log("Recording path not found");
            return false;
        }
    }
    catch (Platform::AccessDeniedException^)
    {
        Platform::log("Cannot open recording path. Access denied");
        return false;
    }
    catch (Platform::COMException^)
    {
        Platform::log("Recording path not found");
        return false;
    }

    return true;
}

} // UWP
} // Platform
