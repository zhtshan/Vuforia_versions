/*===============================================================================
Copyright (c) 2021 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

#include "Platform/Android/AndroidFileReader.h"

#include "FileDriverUserData.h"
#include "Platform/Android/ScopedJNIEnv.h"
#include "Platform/Platform.h"
#include "RGBAPixelConverter.h"
#include "Platform/Android/AndroidJNIUtils.h"

#include <sstream>

const std::string Platform::Android::AndroidFileReader::JAVA_FILE_READER_CLASS = "com/vuforia/samples/fileDriver/FileReader";

enum
{
    JAVA_FILE_READER_CONSTRUCTOR,
    JAVA_FILE_READER_GET_FILE_CONTENTS,
    JAVA_FILE_READER_GET_FILE_CONTENTS_FROM_BUNDLE_ID,
    JAVA_FILE_READER_GET_RGBA_PIXELS,
    JAVA_FILE_READER_GET_RGBA_PIXELS_FROM_BUNDLE_ID,
    JAVA_FILE_READER_GET_ASSETMANAGER
};

namespace
{
    /// Java methods of the FileReader to be called from Native
    JNIJavaMethod g_file_reader_JavaMethodInfo[] =
    {
        { "<init>",                           "()V" },
        {"getFileContents",                   "(Ljava/lang/String;)[B" },
        {"getFileContentsFromBundle",         "(Landroid/app/Activity;Ljava/lang/String;)[B" },
        {"getRGBAPixels",                     "(Ljava/lang/String;)[I" },
        {"getRGBAPixelsFromBundle",           "(Landroid/app/Activity;Ljava/lang/String;)[I" },
        {"getAssetManager",                   "(Landroid/app/Activity;)Landroid/content/res/AssetManager;" },
        _JNI_JAVAMETHODS_FINISHED_
    };
}

namespace Platform
{
namespace Android
{
bool
AndroidFileReader::init(VuforiaDriver::PlatformData* platformData, FileDriverUserData* userData)
{
    // Check if the user has provided the absolute path to image files.
    std::string sequenceDirectoryAbsolutePath;
    if (userData != nullptr)
    {
        sequenceDirectoryAbsolutePath = userData->sequenceDirectoryAbsolutePath;
        //append "/" to the path in case user did not specify absolute path ending with "/"
        std::size_t found = sequenceDirectoryAbsolutePath.rfind("/");
        if (found != (sequenceDirectoryAbsolutePath.length() -1))
        {
            sequenceDirectoryAbsolutePath += "/";
        }
    }

    // If the user has not provided a path, reading will be done from inside the app bundle.
    mReadFilesFromBundle = sequenceDirectoryAbsolutePath.empty();
    mPlatformData = platformData;
    mAbsolutePath = sequenceDirectoryAbsolutePath;

    // Initialize the JNI method references.
    ScopedJNIEnv jniEnv(mPlatformData->javaVM, mPlatformData->jniVersion);
    if (jniEnv == nullptr)
    {
        log("No JNIEnv available");
        return false;
    }

    // Get the class reference and all the static methods that are needed.
    if (mFileReaderClass == nullptr)
    {
        jclass fileReaderClass = jniEnv->FindClass(JAVA_FILE_READER_CLASS.c_str());
        if (fileReaderClass == nullptr)
        {
            log("Failed to get Java FileReader class");
            return false;
        }

        mFileReaderClass = (jclass) jniEnv->NewGlobalRef(fileReaderClass);
        jniEnv->DeleteLocalRef(fileReaderClass);
    }
    // Make sure the JNI environment does not have some previous issue pending.
    if(jniEnv->ExceptionCheck())
    {
        jniEnv->ExceptionDescribe();
        jniEnv->ExceptionClear();
        return false;
    }
    int numMethods = getNumJavaMethods(&g_file_reader_JavaMethodInfo[0]);
    mFileReaderClass_methodIDs = new jmethodID[numMethods];
    if(jniEnv->ExceptionCheck())
    {
        Platform::log("Unable to get number of methods for JAVA_FILE_READER_CLASS");
        jniEnv->ExceptionDescribe();
        jniEnv->ExceptionClear();
        return false;
    }
    JNIEnv* localJNIEnv = nullptr;
    mPlatformData->javaVM->GetEnv((void**) &localJNIEnv, mPlatformData->jniVersion);

    // Retrieve Java functions we intend to use in native code:
    bool result = getJavaFunctions(localJNIEnv, mFileReaderClass,
                                   mFileReaderClass_methodIDs,
                                   &g_file_reader_JavaMethodInfo[0],
                                   false, numMethods);
    if (!result)
    {
        Platform::log("Failed to retrieve JAVA_FILE_READER_CLASS functions.");
        if(jniEnv->ExceptionCheck())
        {
            jniEnv->ExceptionDescribe();
            jniEnv->ExceptionClear();
        }
        return false;
    }
    jobject jniObjLocal = jniEnv->NewObject(mFileReaderClass, mFileReaderClass_methodIDs[JAVA_FILE_READER_CONSTRUCTOR]);
    if (!jniObjLocal)
    {
        Platform::log( "Failed to locate JAVA_FILE_READER_CLASS constructor...");
        if(jniEnv->ExceptionCheck())
        {
            jniEnv->ExceptionDescribe();
            jniEnv->ExceptionClear();
        }
        return false;
    }
    mFileReaderClass_obj = jniEnv->NewGlobalRef(jniObjLocal);
    if (mFileReaderClass_obj == nullptr)
    {
        Platform::log("Failed to create global reference for mFileReaderClass_obj");
        if(jniEnv->ExceptionCheck())
        {
            jniEnv->ExceptionDescribe();
            jniEnv->ExceptionClear();
        }
        return false;
    }
    //call the constructor
    jniEnv->CallVoidMethod( mFileReaderClass_obj, mFileReaderClass_methodIDs[JAVA_FILE_READER_CONSTRUCTOR]);

    // Retrieve Java-level AssetManager object:
    jobject assetManagerJava = jniEnv->CallObjectMethod(mFileReaderClass_obj, mFileReaderClass_methodIDs[JAVA_FILE_READER_GET_ASSETMANAGER], mPlatformData->activity);
    if (assetManagerJava == NULL)
    {
        Platform::log("Failed to acquire Java AssetManager");
        return false;
    }
    // Obtain native AssetManager object from corresponding Java-level AssetManager object
    mAssetManagerNative = AAssetManager_fromJava(localJNIEnv, assetManagerJava);
    if (mAssetManagerNative == NULL)
    {
        Platform::log("Failed to acquire Java AssetManager");
        return false;
    }
    jniEnv->DeleteLocalRef(assetManagerJava);
    return true;
}

bool
AndroidFileReader::deInit()
{
    Platform::log("AndroidFileReader::deInit()");
    mXMLReader.clear();
    if(mXMLAsset)
    {
        AAsset_close(mXMLAsset);
    }
    mXMLAsset = NULL;
    Platform::Android::ScopedJNIEnv jniEnv(mPlatformData->javaVM, mPlatformData->jniVersion);
    if (jniEnv == nullptr)
    {
        Platform::log("AndroidFileReader::deInit() no JNI available....");
        return false;
    }
    else
    {
        if (mFileReaderClass_obj != nullptr)
        {
            jniEnv->DeleteGlobalRef(mFileReaderClass_obj);
            mFileReaderClass_obj = nullptr;
        }
        if (mFileReaderClass != nullptr)
        {
            jniEnv->DeleteGlobalRef(mFileReaderClass);
            mFileReaderClass = nullptr;
        }
    }
    return true;
}

XMLFileReader::ElementInfo
AndroidFileReader::readRecording(const std::string& filename)
{
    XMLFileReader::ElementInfo seqInfo;
    ScopedJNIEnv jniEnv(mPlatformData->javaVM, mPlatformData->jniVersion);

    // Create full path to the file. mAbsolutePath is empty when reading from the bundle.
    // For reading from the bundle, we need to rely on AssetManager and read the entire file content into a buffer.
    std::string fullFilePath = mAbsolutePath + filename;
    if(mAssetManagerNative && mAbsolutePath.empty())
    {
        if(!mAssetDatabuffer)
        {
            //Open the asset and get the file content in a buffer.
            mXMLAsset = AAssetManager_open(mAssetManagerNative, fullFilePath.c_str(), AASSET_MODE_UNKNOWN);
            if(mXMLAsset)
            {
                mAssetDatabuffer = AAsset_getBuffer(mXMLAsset);
            }
        }
        if(mAssetDatabuffer && mXMLAsset)
        {
            if(mXMLReader.load(mAssetDatabuffer, (int)AAsset_getLength(mXMLAsset)))
            {
                seqInfo = mXMLReader.getNextElement(mCapability);
            }
        }
    }
    else if(!fullFilePath.empty())
    {
        if(mXMLReader.load((const char*)fullFilePath.c_str()))
        {
            seqInfo = mXMLReader.getNextElement(mCapability);
        }
    }
    return seqInfo;
}

void AndroidFileReader::setCapability(VuforiaDriver::Capability capability)
{
    mCapability = capability;
}

bool
AndroidFileReader::readImage(const std::string& filename, VuforiaDriver::CameraMode cameraMode, std::vector<uint8_t>& outBytes, uint32_t& outStride)
{
    ScopedJNIEnv jniEnv(mPlatformData->javaVM, mPlatformData->jniVersion);
    bool retVal = false;

    // Create full path to the file. mAbsolutePath is empty when reading from the bundle.
    std::string fullFilePath = mAbsolutePath + filename;
    jstring jFileName = jniEnv->NewStringUTF(fullFilePath.c_str());

    if (isXPGMFile(filename))
    {
        jbyteArray jniFileBytes = nullptr;
        if (mReadFilesFromBundle)
        {
            jniFileBytes = (jbyteArray)jniEnv->CallObjectMethod( mFileReaderClass_obj,
                                                                 mFileReaderClass_methodIDs[JAVA_FILE_READER_GET_FILE_CONTENTS_FROM_BUNDLE_ID],
                                                                 mPlatformData->activity, jFileName);
        }
        else
        {
            jniFileBytes = (jbyteArray)jniEnv->CallObjectMethod( mFileReaderClass_obj,
                                                                 mFileReaderClass_methodIDs[JAVA_FILE_READER_GET_FILE_CONTENTS],
                                                                 jFileName);
        }

        if (jniFileBytes != nullptr)
        {
            jsize numBytes = jniEnv->GetArrayLength(jniFileBytes);
            jbyte* elements = jniEnv->GetByteArrayElements(jniFileBytes, NULL);

            retVal = readXPGMImage(reinterpret_cast<char*>(elements), numBytes, cameraMode, outBytes, outStride);

            jniEnv->ReleaseByteArrayElements(jniFileBytes, elements, JNI_ABORT);
        }
    }
    else
    {
        // Call either getRGBAPixelsFromBundle or getRGBAPixels depending on
        // from where the user wants to read the image files.
        jintArray jniPixelArray = nullptr;
        if (mReadFilesFromBundle)
        {
            jniPixelArray = (jintArray) jniEnv->CallObjectMethod( mFileReaderClass_obj,
                                                                  mFileReaderClass_methodIDs[JAVA_FILE_READER_GET_RGBA_PIXELS_FROM_BUNDLE_ID],
                                                                  mPlatformData->activity, jFileName);
        }
        else
        {
            jniPixelArray = (jintArray) jniEnv->CallObjectMethod( mFileReaderClass_obj,
                                                              mFileReaderClass_methodIDs[JAVA_FILE_READER_GET_RGBA_PIXELS], jFileName);
        }
        jniEnv->DeleteLocalRef(jFileName);
        if(jniPixelArray == nullptr)
        {
            return false;
        }

        jint* jniPixelBuffer = jniEnv->GetIntArrayElements(jniPixelArray, 0);

        // Android provides these in ARGB channel order, but due to endianness and reading
        // the image as int array the memory layout is flipped, so we are using BGRA here.
        // If you have rendering problems (channels switched), please check
        // the source order and possibly adjust this parameter accordingly.
        auto channelOrder = RGBAPixelConverter::ChannelOrder::BGRA;
        retVal = RGBAPixelConverter::convert(cameraMode.format,
                                             reinterpret_cast<uint8_t*>(jniPixelBuffer),
                                             cameraMode.width, cameraMode.height,
                                             channelOrder,
                                             outBytes, outStride);
        jniEnv->ReleaseIntArrayElements(jniPixelArray, jniPixelBuffer, 0);
    }

    return retVal;
}

bool 
AndroidFileReader::assetExists(const std::string& name) const
{
    ScopedJNIEnv jniEnv(mPlatformData->javaVM, mPlatformData->jniVersion);

    AAsset* asset = AAssetManager_open(mAssetManagerNative, name.c_str(), AASSET_MODE_UNKNOWN);
    if (asset != nullptr)
    {
        AAsset_close(asset);
        return true;
    }
    return false;
}

AAssetManager* 
AndroidFileReader::getAssetManager()
{
    return mAssetManagerNative;
}

} // Android
} // Platform
