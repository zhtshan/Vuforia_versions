/*===============================================================================
Copyright (c) 2020 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

package com.vuforia.samples.fileDriver;

import android.app.Activity;
import android.graphics.BitmapFactory;
import android.graphics.Bitmap;
import android.util.Log;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.IOException;

import android.content.res.AssetManager;
import android.os.Environment;

public final class FileReader
{
    private static final String MODULE_TAG                                 = "Vuforia-FileDriver";
    private static final Bitmap.Config RGBA_FORMAT                         = Bitmap.Config.ARGB_8888;

    private  int[] getRGBAInternal(Bitmap bitmap)
    {
        if (bitmap == null)
        {
            return null;
        }

        int width  = bitmap.getWidth();
        int height = bitmap.getHeight();
        int[] pixels = new int[width * height];
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height);
        return pixels;
    }

    public byte[] getFileContents(String fullPath)
    {
        byte[] contents = null;
        BufferedInputStream bis = null;
        try
        {
            try
            {
                File file = new File(fullPath);
                contents = new byte[(int)file.length()];
                bis = new BufferedInputStream(new FileInputStream(file));
                bis.read(contents, 0, contents.length);
            }
            finally
            {
                if(bis != null)
                {
                    bis.close();
                }
                bis = null;
            }
        }
        catch (Exception e)
        {
            contents = null;
            Log.e(MODULE_TAG, "getFileContents exception: " + fullPath);
        }
        return contents;
    }

    public AssetManager getAssetManager(Activity activity)
    {
        if(activity == null)
        {
            Log.e(MODULE_TAG, "Failed to get AssetManager");
            return null;
        }
        return activity.getAssets();
    }

    public byte[] getFileContentsFromBundle(Activity activity, String filename)
    {
        byte[] contents = null;
        InputStream stream = null;
        BufferedInputStream bis = null;
        try
        {
            try
            {
                stream = activity.getAssets().open(filename);
                contents = new byte[stream.available()];
                bis = new BufferedInputStream(stream);
                bis.read(contents, 0, contents.length);
            }
            finally
            {
                if(bis != null)
                {
                    bis.close();
                }
                bis = null;
                if(stream != null)
                {
                    stream.close();
                }
                stream = null;
            }
        }
        catch (IOException e)
        {
            contents = null;
            Log.e(MODULE_TAG, "Error reading image from the bundle: " + filename);
        }
        return contents;
    }

    public  int[] getRGBAPixels(String fullPath)
    {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inPreferredConfig = RGBA_FORMAT;
        Bitmap bitmap = BitmapFactory.decodeFile(fullPath, options);
        return getRGBAInternal(bitmap);
    }

    public  int[] getRGBAPixelsFromBundle(Activity activity, String filename)
    {
        Bitmap bitmap = null;
        InputStream stream = null;
        try
        {
            try
            {
                BitmapFactory.Options options = new BitmapFactory.Options();
                options.inPreferredConfig = RGBA_FORMAT;
                stream = activity.getAssets().open(filename);
                bitmap = BitmapFactory.decodeStream(stream, null, options);
            }
            finally
            {
                if(stream != null)
                {
                    stream.close();
                }
                stream = null;
            }
        }
        catch (IOException e)
        {
            Log.e(MODULE_TAG, "Error reading image from the bundle: " + filename);
        }
        return getRGBAInternal(bitmap);
    }
 }
