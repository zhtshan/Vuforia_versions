/*===============================================================================
Copyright (c) 2021 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/
#include "Platform/Platform.h"

#include "FileDriverUserData.h"
#include "Platform/Android/AndroidFileReader.h"

#include <android/log.h>

namespace Platform
{

void
log(const std::string& message)
{
    __android_log_print(ANDROID_LOG_DEBUG, "Vuforia-FileDriver", "%s", message.c_str());
}

std::unique_ptr<FileReader>
createFileReader()
{
    return std::unique_ptr<Android::AndroidFileReader>{ new Android::AndroidFileReader() };
}

} // Platform
