/*===============================================================================
Copyright (c) 2021 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/
#include "Platform/Android/AndroidJNIUtils.h"

int getNumJavaMethods(const JNIJavaMethod* methods)
{
    int methodArraySize = 0;
    if(methods)
    {
        while ( methods[methodArraySize].name != 0 && methods[methodArraySize].signature != 0)
        {
            methodArraySize++;
        }
    }
    return methodArraySize;
}

bool getJavaFunctions(JNIEnv* jniEnv, jclass cls, jmethodID*& jniMethodIDs, const JNIJavaMethod* methods,
                      bool staticMethods, int nNumMethods)
{
    int methodArraySize = (nNumMethods < 0) ? getNumJavaMethods(methods) : nNumMethods;
    for (int i = 0; i < methodArraySize; i++)
    {
        jniMethodIDs[i] = staticMethods ?
        jniEnv->GetStaticMethodID(cls, methods[i].name, methods[i].signature) :
        jniEnv->GetMethodID(cls, methods[i].name, methods[i].signature);

        if (!jniMethodIDs[i])
        {
            return false;
        }
        if(jniEnv->ExceptionCheck())
        {
            jniEnv->ExceptionDescribe();
            jniEnv->ExceptionClear();
            return false;
        }
    }
    return true;
}
