/*===============================================================================
Copyright (c) 2021 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/
#include "Platform/Windows/WindowsFileReader.h"

#include "FileDriverUserData.h"
#include "Platform/Platform.h"
#include "RGBAPixelConverter.h"

#include <shlwapi.h>
#include <wincodec.h>

#include <cassert>
#include <ios>
#include <string>
#include <sstream>
#include <vector>

std::string wStrToStdString(PCWSTR param)
{
    assert(param != nullptr);

    int paramLength = int(std::wcslen(param));
    if (paramLength > 0)
    {
        int length = ::WideCharToMultiByte(CP_ACP, 0, param, paramLength, NULL, 0, NULL, NULL);
        if (length == 0)
        {
            return std::string();
        }

        std::vector<char> buffer(length);
        ::WideCharToMultiByte(CP_ACP, 0, param, paramLength, &buffer[0], length, NULL, NULL);

        return std::string(buffer.begin(), buffer.end());
    }
    else
    {
        return std::string();
    }
}

namespace Platform
{
namespace Windows
{

bool
WindowsFileReader::init(VuforiaDriver::PlatformData*  /*platformData*/ , FileDriverUserData* userData)
{
    if (!mCoInitialized)
    {
        // Required for the CoCreateInstance call when reading PNG files
        HRESULT hr = CoInitializeEx(NULL, COINIT_MULTITHREADED);

        mCoInitialized = SUCCEEDED(hr);
        if (!mCoInitialized)
        {
            std::stringstream buffer;
            buffer << std::hex << hr;
            // Even with CoInitializeEx failing, PNG files can still be read on Unity.
            // Therefore we are not very strict about checking the result, but only log
            // it in case of an error.
            Platform::log("CoInitializeEx failed with result value " + buffer.str() +
                          " (This might simply indicate a change in the concurrency model)");
        }
    }

    if (userData != nullptr)
    {
        mRecordingDirectoryAbsolutePath = userData->sequenceDirectoryAbsolutePath;
        if (!mRecordingDirectoryAbsolutePath.empty() &&
            mRecordingDirectoryAbsolutePath.back() != '\\' &&
            mRecordingDirectoryAbsolutePath.back() != '/')
        {
            mRecordingDirectoryAbsolutePath.append("\\");
        }
    }
    else
    {
        mRecordingDirectoryAbsolutePath = "";
    }
    return true;
}

bool WindowsFileReader::deInit()
{
    mXMLReader.clear();

    if (mCoInitialized)
    {
        CoUninitialize();
        mCoInitialized = false;
    }

    return true;
}

bool
WindowsFileReader::readImage(const std::string& filename, VuforiaDriver::CameraMode cameraMode, std::vector<uint8_t>& outBytes, uint32_t& outStride)
{
    std::string fullImageFilepath = (mRecordingDirectoryAbsolutePath + filename);
    bool bRet = false;

    if (isXPGMFile(fullImageFilepath))
    {
        FILE *fp = NULL;
        fopen_s(&fp, fullImageFilepath.c_str(), "rb");
        if (fp)
        {
            fseek(fp, 0, SEEK_END);
            size_t length = ftell(fp);
            rewind(fp);
            char* data = new char[length];
            if (data)
            {
                size_t nread = fread(data, 1, length, fp);
                size_t remaining = length - nread;
                while (remaining)
                {
                  size_t chunk = fread(data + nread, 1, remaining, fp);
                  if (!chunk)
                  {
                      //we either read all data or read failed, break in both cases.
                      break;
                  }
                  //update read index and number of remaining bytes to read
                  nread += chunk;
                  remaining -= chunk;
                }
                if (!remaining && length)
                {
                    //we read all bytes, go ahead and process xpgm file now
                    bRet = readXPGMImage(data, nread, cameraMode, outBytes, outStride);
                }
                else
                {
                    Platform::log("Failed to read data from the ImageFile " + fullImageFilepath);
                }
            }
            else
            {
                Platform::log("Failed to allocate memory to read data from the ImageFile " + fullImageFilepath);
            }
            //close file pointer in case we end up looping and free the allocated memory.
            fclose(fp);
            delete[] data;
        }
        else
        {
            Platform::log("Failed to open Imagefile " + fullImageFilepath);
        }
        return bRet;
    }
    else
    {
        IWICBitmapDecoder *pDecoder = NULL;
        IWICImagingFactory *pIWICFactory = NULL;
        //create WIC (Windows Imaging Component) factory.

        HRESULT hr = CoCreateInstance(CLSID_WICImagingFactory, NULL, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&pIWICFactory));
        if (SUCCEEDED(hr))
        {
            std::wstring fileName_wstr = std::wstring(fullImageFilepath.begin(), fullImageFilepath.end());
            LPCWSTR fileName_lpcwstr = fileName_wstr.c_str();
            //create decoder from the factory to decode png
            hr = pIWICFactory->CreateDecoderFromFilename(fileName_lpcwstr,                 // Image to be decoded
                                                           NULL,                           // Do not prefer a particular vendor
                                                           GENERIC_READ,                   // Desired read access to the file
                                                           WICDecodeMetadataCacheOnDemand, // Cache metadata when needed
                                                           &pDecoder                       // Pointer to the decoder
                                                           );
            // Retrieve the first frame of the image from the decoder
            IWICBitmapFrameDecode *pFrame = NULL;

            if (SUCCEEDED(hr))
            {
                hr = pDecoder->GetFrame(0, &pFrame);
                if (SUCCEEDED(hr))
                {
                    // Convert to 32bpp RGBA for easier processing.
                    IWICBitmapSource *pConvertedFrame = NULL;
                    hr = WICConvertBitmapSource(GUID_WICPixelFormat32bppRGBA, pFrame, &pConvertedFrame);
                    if (SUCCEEDED(hr))
                    {
                        // Copy the 32bpp RGBA image for pixel conversion.
                        UINT width, height;
                        pConvertedFrame->GetSize(&width, &height);
                        const unsigned bytesPerPixel = 4;
                        const unsigned stride = width * bytesPerPixel;
                        const unsigned bitmapSize = width * height * bytesPerPixel;
                        BYTE *buffer = new BYTE[bitmapSize];
                        pConvertedFrame->CopyPixels(nullptr, stride, bitmapSize, buffer);
                        if (buffer)
                        {
                            bRet = RGBAPixelConverter::convert(cameraMode.format, buffer, cameraMode.width, cameraMode.height,
                                                               RGBAPixelConverter::ChannelOrder::RGBA, outBytes, outStride);
                            delete[] buffer;
                        }
                    }
                }
            }
        }
    }
    if (!bRet)
    {
        Platform::log("Error processing " + fullImageFilepath);
    }
    return bRet;
}

XMLFileReader::ElementInfo WindowsFileReader::readRecording(const std::string& filename)
{
    XMLFileReader::ElementInfo retSeqInfo;
    if(mXMLReader.load((const char*)(mRecordingDirectoryAbsolutePath + filename).c_str()))
    {
        retSeqInfo = mXMLReader.getNextElement(mCapability);
    }
    return retSeqInfo;
}

void WindowsFileReader::setCapability(VuforiaDriver::Capability capability)
{
    //reader will send out data based on capability.
    if( ((capability & VuforiaDriver::Capability::CAMERA_POSE)  != VuforiaDriver::Capability::CAMERA_POSE) &&
        ((capability & VuforiaDriver::Capability::CAMERA_IMAGE) != VuforiaDriver::Capability::CAMERA_IMAGE) )
    {
        Platform::log("Invalid capability "+std::to_string(capability)+". Expected "+
                      std::to_string(VuforiaDriver::Capability::CAMERA_IMAGE)+" or "+std::to_string(VuforiaDriver::Capability::CAMERA_POSE));
    }
    else
    {
        mCapability = capability;
    }
}

} // Windows
} // Platform
