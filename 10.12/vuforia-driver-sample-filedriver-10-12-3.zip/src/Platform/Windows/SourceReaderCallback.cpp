/*===============================================================================
Copyright (c) 2021 PTC Inc., Its Subsidiary Companies, and /or its Partners.
All Rights Reserved.

Confidential and Proprietary - Protected under copyright and other laws.
Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

#include "Platform/Windows/SourceReaderCallback.h"

#include <cassert>

using namespace Platform::Windows;


SourceReaderCallback::SourceReaderCallback(SampleCallback sampleCallback) :
    mCallback(std::move(sampleCallback))
{
}


SourceReaderCallback::~SourceReaderCallback()
{
    assert(mRefCount == 0);
}


STDMETHODIMP_(ULONG) 
SourceReaderCallback::AddRef()
{
    return ++mRefCount;
}


STDMETHODIMP_(ULONG) 
SourceReaderCallback::Release()
{
    ULONG count = --mRefCount;
    if (count == 0)
    {
        delete this;
    }
    return count;
}


STDMETHODIMP
SourceReaderCallback::QueryInterface(REFIID iid, void** ppv)
{
    if (ppv == nullptr)
    {
        return E_POINTER;
    }

    if (iid == IID_IUnknown)
    {
        *ppv = static_cast<IUnknown*>(static_cast<IMFSourceReaderCallback*>(this));
    }
    else if (iid == __uuidof(IMFSourceReaderCallback))
    {
        *ppv = static_cast<IMFSourceReaderCallback*>(this);
    }
    else
    {
        *ppv = nullptr;
        return E_NOINTERFACE;
    }

    AddRef();
    return S_OK;
}


STDMETHODIMP
SourceReaderCallback::OnEvent(DWORD /*dwStreamIndex*/, IMFMediaEvent* /*pEvent*/)
{
    return S_OK;
}


STDMETHODIMP
SourceReaderCallback::OnFlush(DWORD /*dwStreamIndex*/)
{
    return S_OK;
}


STDMETHODIMP
SourceReaderCallback::OnReadSample(HRESULT hrStatus, DWORD /*dwStreamIndex*/, DWORD dwStreamFlags, LONGLONG llTimestamp, IMFSample* pSample)
{
    if (mCallback)
    {
        mCallback(hrStatus, pSample, llTimestamp, dwStreamFlags);
    }
    return S_OK;
}

