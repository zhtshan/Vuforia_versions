/*===============================================================================
Copyright (c) 2021 PTC Inc., Its Subsidiary Companies, and /or its Partners.
All Rights Reserved.

Confidential and Proprietary - Protected under copyright and other laws.
Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

#include "Platform/Windows/SampleProviderStreamSource.h"

#include "Platform/Platform.h"
#include "Platform/Windows/ScopedComPtr.h"

#include <cassert>
#include <chrono>

using namespace Platform::Windows;


SampleProviderStreamSource::SampleProviderStreamSource(IMFMediaSource* mediaSource, IMFStreamDescriptor* streamDescriptor, size_t maxSampleQueueSize) :
    mMediaSource(mediaSource),
    mStreamDescriptor(streamDescriptor),
    mMaxQueueSize(maxSampleQueueSize)
{
    assert(mediaSource != nullptr);
    assert(streamDescriptor != nullptr);
}


SampleProviderStreamSource::~SampleProviderStreamSource()
{
    assert(mRefCount == 0);
}


STDMETHODIMP_(ULONG) 
SampleProviderStreamSource::AddRef()
{
    return ++mRefCount;
}


STDMETHODIMP_(ULONG) 
SampleProviderStreamSource::Release()
{
    ULONG count = --mRefCount;
    if (count == 0)
    {
        delete this;
    }
    return count;
}


STDMETHODIMP
SampleProviderStreamSource::QueryInterface(REFIID iid, void** ppv)
{
    if (ppv == nullptr)
    {
        return E_POINTER;
    }

    if (iid == IID_IUnknown)
    {
        *ppv = static_cast<IUnknown*>(static_cast<IMFMediaStream*>(this));
    }
    else if (iid == __uuidof(IMFMediaStream))
    {
        *ppv = static_cast<IMFMediaStream*>(this);
    }
    else if (iid == __uuidof(IMFMediaEventGenerator))
    {
        *ppv = static_cast<IMFMediaEventGenerator*>(this);
    }
    else
    {
        *ppv = nullptr;
        return E_NOINTERFACE;
    }

    AddRef();
    return S_OK;
}


STDMETHODIMP
SampleProviderStreamSource::GetMediaSource(IMFMediaSource** ppMediaSource)
{
    std::scoped_lock lock(mInstanceMutex);
    if (isShutDown())
    {
        return MF_E_SHUTDOWN;
    }

    return mMediaSource->QueryInterface(IID_PPV_ARGS(ppMediaSource));
}


STDMETHODIMP
SampleProviderStreamSource::GetStreamDescriptor(IMFStreamDescriptor** ppStreamDescriptor)
{
    std::scoped_lock lock(mInstanceMutex);
    if (isShutDown())
    {
        return MF_E_SHUTDOWN;
    }

    return mStreamDescriptor->QueryInterface(IID_PPV_ARGS(ppStreamDescriptor));
}


STDMETHODIMP
SampleProviderStreamSource::RequestSample(IUnknown* pToken)
{
    std::unique_lock lock(mInstanceMutex);
    if (isShutDown())
    {
        return MF_E_SHUTDOWN;
    }

    ScopedComPtr<IMFSample> sample;
    if (mSampleQueue.empty())
    {
        mSampleQueueCv.wait(lock, [&]() { return !mSampleQueue.empty() || mEndOfStream; });

        if (mEndOfStream && mSampleQueue.empty())
        {
            return sendEndOfStreamEvents();
        }
    }

    assert(!mSampleQueue.empty());
    sample = *mSampleQueue.begin();
    mSampleQueue.pop_front();
    mSampleQueueCv.notify_all();

    if (pToken != nullptr)
    {
        HRESULT hr = sample->SetUnknown(MFSampleExtension_Token, pToken);
        if (FAILED(hr))
        {
            return hr;
        }
    }

    return QueueEventWithIUnknownArg(MEMediaSample, GUID_NULL, S_OK, sample);
}

bool
SampleProviderStreamSource::enqueueSample(IMFSample* sample, int32_t timeoutUs)
{
    std::unique_lock lock(mInstanceMutex);

    if (mEndOfStream)
    {
        return false;
    }

    if (mSampleQueue.size() >= mMaxQueueSize)
    {
        auto predicate = [&]() { return mSampleQueue.size() < mMaxQueueSize; };

        if (timeoutUs > 0)
        {
            auto timeout = std::chrono::microseconds(timeoutUs);
            if (!mSampleQueueCv.wait_for(lock, timeout, predicate))
            {
                return false;
            }
        }
        else if (timeoutUs < 0)
        {
             mSampleQueueCv.wait(lock, predicate);
        }
        else
        {
            return false;
        }
    }

    assert(mSampleQueue.size() < mMaxQueueSize);
    mSampleQueue.push_back(sample);
    mSampleQueueCv.notify_all();
    return true;
}


bool
SampleProviderStreamSource::canEnqueueWithoutWait()
{
    std::scoped_lock lock(mInstanceMutex);
    return mSampleQueue.size() < mMaxQueueSize;
}


void
SampleProviderStreamSource::notifyEndOfStream()
{
    std::scoped_lock lock(mInstanceMutex);
    mEndOfStream = true;
    mSampleQueueCv.notify_all();
}


void
SampleProviderStreamSource::waitForEmptySampleQueue()
{
    std::unique_lock lock(mInstanceMutex);
    mSampleQueueCv.wait(lock, [&]() { return mSampleQueue.empty(); });
}


HRESULT 
SampleProviderStreamSource::sendEndOfStreamEvents()
{
    HRESULT hr = QueueEvent(MEEndOfStream, GUID_NULL, S_OK, nullptr);
    if (FAILED(hr))
    {
        return hr;
    }

    hr = mMediaSource->QueueEvent(MEEndOfPresentation, GUID_NULL, S_OK, nullptr);
    if (FAILED(hr))
    {
        return hr;
    }

    return MF_E_END_OF_STREAM;
}