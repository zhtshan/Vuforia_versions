/*===============================================================================
Copyright (c) 2022 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

#include "Platform/Windows/MediaFoundationInitializer.h"

#include "Platform/Platform.h"

#include <roapi.h>
#include <mfapi.h>

using namespace Platform::Windows;


MediaFoundationInitializer::MediaFoundationInitializer()
{
    mRuntimeInitializeSuccess = SUCCEEDED(::Windows::Foundation::Initialize(RO_INIT_MULTITHREADED));
    if (!mRuntimeInitializeSuccess)
    {
        Platform::log("Failed to properly initialize COM");  
    }

    mMfInitializeSuccess = SUCCEEDED(MFStartup(MF_VERSION));
    if (!mMfInitializeSuccess)
    {
        Platform::log("Failed to properly initialize Windows Media Foundation");  
    }
}


MediaFoundationInitializer::~MediaFoundationInitializer()
{
    if (mMfInitializeSuccess) 
    {
        if(FAILED(MFShutdown())) 
        {
            Platform::log("Failed to properly shutdown Windows Media Foundation");
        }
    }

    if (mRuntimeInitializeSuccess) 
    {
        ::Windows::Foundation::Uninitialize();
    }
}
