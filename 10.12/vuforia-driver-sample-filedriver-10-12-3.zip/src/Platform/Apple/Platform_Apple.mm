/*===============================================================================
Copyright (c) 2018 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/
#import <Foundation/Foundation.h>
#include "Platform/Platform.h"
#include "FileDriverUserData.h"
#include "Platform/Apple/AppleFileReader.h"


namespace Platform
{

void
log(const std::string& message)
{
    NSLog(@"[Vuforia-FileDriver] %s", message.c_str());
}

std::unique_ptr<FileReader>
createFileReader()
{
    return std::unique_ptr<Apple::AppleFileReader>{ new Apple::AppleFileReader() };
}

} // Platform
