/*===============================================================================
Copyright (c) 2019 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

#import <Foundation/Foundation.h>

#include "Platform/Apple/AppleFileReader.h"

#include "FileDriverUserData.h"
#include "Platform/Platform.h"
#include "RGBAPixelConverter.h"

#ifdef FILEDRIVER_PLATFORM_IOS
#import <UIKit/UIKit.h>
#elif FILEDRIVER_PLATFORM_MACOS
#import <Cocoa/Cocoa.h>
#endif

#import <CoreGraphics/CGImage.h>
#include <vector>
#include <iostream>


namespace Platform
{
namespace Apple
{
bool
AppleFileReader::init(VuforiaDriver::PlatformData* platformData, FileDriverUserData* userData)
{
    // Check if the user has provided the absolute path to image files.
    if (userData != nullptr && strlen(userData->sequenceDirectoryAbsolutePath))
    {        
        mAbsolutePath = [[NSString stringWithCString:userData->sequenceDirectoryAbsolutePath encoding:NSASCIIStringEncoding] retain];
        std::string msg = "Reading data from the provided absolute path " + std::string([mAbsolutePath UTF8String]);
        log(msg);
    }
    else
    {
        log("Reading data from the app bundle.");
        mAbsolutePath = [[[NSBundle mainBundle] resourcePath] retain];
        log("Reading data from app bundle resourcePath " + std::string([mAbsolutePath UTF8String]));
    }

    mPlatformData = platformData;
    return true;
}


AppleFileReader::~AppleFileReader()
{
    [mAbsolutePath release];
}


bool AppleFileReader::deInit()
{
    mXMLReader.clear();

    [mAbsolutePath release];
    mAbsolutePath = nil;

    return true;
}

bool
AppleFileReader::readImage(const std::string& filename, VuforiaDriver::CameraMode cameraMode, std::vector<uint8_t>& outBytes, uint32_t& outStride)
{
    bool ret = false;
    //iOS and macOS imaging related code in this function relies on Automatic Reference Counting (ARC).
    //Marking whole block with autoreleasepool ensures objects are released as soon as their ref. count reaches zero.
    @autoreleasepool
    {
        // Create the full path of the image file if needed
        NSString* leafname = [NSString stringWithCString:filename.c_str() encoding:NSASCIIStringEncoding];
        NSString* fullPath = [mAbsolutePath stringByAppendingPathComponent:leafname];

        if (isXPGMFile(filename))
        {
            NSData* myData = [[NSData alloc] initWithContentsOfFile:fullPath];
            if (myData != nil)
            {
                ret = readXPGMImage(static_cast<const char*>(myData.bytes), myData.length, cameraMode, outBytes, outStride);
                [myData release];
            }
        }
        else
        {
#ifdef FILEDRIVER_PLATFORM_IOS
            // Create a UIImage with the contents of the file
            UIImage* uiImage   = [[UIImage alloc] initWithContentsOfFile:fullPath];
            if (uiImage)
            {
                CGImageRef cgImage = [uiImage CGImage];
                int width = static_cast<int>(uiImage.size.width);
                int height = static_cast<int>(uiImage.size.height);
                if (width == cameraMode.width && height == cameraMode.height)
                {
                    CFDataRef pixels = CGDataProviderCopyData(CGImageGetDataProvider(cgImage));
                    const UInt8* pixelBuffer = CFDataGetBytePtr(pixels);
                    ret = RGBAPixelConverter::convert(cameraMode.format,
                                                      pixelBuffer,
                                                      cameraMode.width, cameraMode.height,
                                                      RGBAPixelConverter::ChannelOrder::RGBA,
                                                      outBytes, outStride);
                    CFRelease(pixels);
                }
                else
                {
                    log(std::string("Camera frame has unexpected width and/or height: ").append([fullPath cStringUsingEncoding:NSASCIIStringEncoding]));
                }
                [uiImage release];
            }
            else
            {
                log(std::string("Failed to read camera frame image: ").append([fullPath cStringUsingEncoding:NSASCIIStringEncoding]));
            }
#elif FILEDRIVER_PLATFORM_MACOS
            NSImage* anImage = [[NSImage alloc] initWithContentsOfFile: fullPath];
            if(anImage)
            {
                CGImageRef imageRef = [anImage CGImageForProposedRect:NULL context:nil hints:nil];
                int width = static_cast<int>(CGImageGetWidth(imageRef));
                int height = static_cast<int>(CGImageGetHeight(imageRef));
                CFDataRef pixels = CGDataProviderCopyData(CGImageGetDataProvider(imageRef));
                const UInt8* data = CFDataGetBytePtr(pixels);
                if (width == cameraMode.width && height == cameraMode.height && data)
                {
                    ret = RGBAPixelConverter::convert(cameraMode.format,
                                                      data,
                                                      cameraMode.width, cameraMode.height,
                                                      RGBAPixelConverter::ChannelOrder::RGBA,
                                                      outBytes, outStride);
                }
                else
                {
                    log(std::string("Camera frame has unexpected width and/or height: ").append([fullPath cStringUsingEncoding:NSASCIIStringEncoding]));
                }
                CFRelease(pixels);

                [anImage release];
            }
            else
            {
                log(std::string("Failed to read camera frame image: ").append([fullPath cStringUsingEncoding:NSASCIIStringEncoding]));
            }
#endif
        }
    }//@autoreleasepool
    return ret;
}

XMLFileReader::ElementInfo AppleFileReader::readRecording(const std::string& filename)
{
    NSString* leafname = [NSString stringWithCString:filename.c_str() encoding:NSASCIIStringEncoding];
    NSString* fullPath = [mAbsolutePath stringByAppendingPathComponent:leafname];
    const char *str =  [fullPath cStringUsingEncoding:NSUTF8StringEncoding];
    XMLFileReader::ElementInfo retSeqInfo;
    if(mXMLReader.load(str))
    {
        retSeqInfo = mXMLReader.getNextElement(mCapability);
    }
    return retSeqInfo;
}

void AppleFileReader::setCapability(VuforiaDriver::Capability capability)
{
    //reader will send out data based on capability.
   if( ((capability & VuforiaDriver::Capability::CAMERA_POSE)  != VuforiaDriver::Capability::CAMERA_POSE) &&
       ((capability & VuforiaDriver::Capability::CAMERA_IMAGE) != VuforiaDriver::Capability::CAMERA_IMAGE) )
    {
        log(std::string("Invalid capability ").append(std::to_string(capability)).append(". Expected "). \
            append(std::to_string(VuforiaDriver::Capability::CAMERA_IMAGE)).append(" or ").append(std::to_string(VuforiaDriver::Capability::CAMERA_POSE)));
    }
    else
    {
        mCapability = capability;
    }
}


std::string 
AppleFileReader::getAppAssetDirectory() const
{
    return std::string([[[NSBundle mainBundle] resourcePath] UTF8String]) + "/";
}


} // Apple
} // Platform
