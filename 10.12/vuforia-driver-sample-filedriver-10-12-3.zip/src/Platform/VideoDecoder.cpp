/*===============================================================================
Copyright (c) 2021 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

#include "Platform/VideoDecoder.h"
#include "Platform/Platform.h"

#include <cassert>

namespace Platform
{

bool
VideoDecoder::isSupportedResolution(uint16_t width, uint16_t height)
{
    /*
     * It is difficult to determine the image resolutions that are supported by
     * H.264. Some resources online claim both dimensions have to be a multiple of 16.
     * This however cannot be true as 1080 (as in FullHD 1920x1080) is not divisible by 16.
     * 
     * Not all platforms return an error if a resolution is not supported, some (Android)
     * just expect the input image to be padded to some supported resolution.
     * 
     * The limit below is probably stricter than necessary. However, it seems to
     * work well on all platforms and covers all the common resolutions (640x480, 960x540, 
     * 1280x720, 1920x1080, ...)
     */

    return width % 16 == 0 && height % 4 == 0;
}


bool
VideoDecoder::convertAvccToAnnexB(uint8_t* buffer, size_t bufferSize)
{
    if (bufferSize < NALU_HEADER_SIZE)
    {
        return false;
    }

    for (size_t i = 0; i < bufferSize;)
    {
        uint32_t naluSize = buffer[i] << 24 | buffer[i + 1] << 16 | buffer[i + 2] << 8 | buffer[i + 3];

        if (i + naluSize > bufferSize || naluSize == 0)
        {
            return false;
        }

        buffer[i] = 0x00;
        buffer[i + 1] = 0x00;
        buffer[i + 2] = 0x00;
        buffer[i + 3] = 0x01;
        i += NALU_HEADER_SIZE + naluSize;
    }

    return true;
}


bool
VideoDecoder::containsIFrame(const uint8_t* buffer, size_t bufferSize)
{
    if (bufferSize < NALU_HEADER_SIZE)
    {
        return false;
    }

    for (size_t i = 0; i < bufferSize;)
    {
        uint32_t naluSize = buffer[i] << 24 | buffer[i + 1] << 16 | buffer[i + 2] << 8 | buffer[i + 3];

        if (i + naluSize > bufferSize || naluSize == 0)
        {
            return false;
        }

        uint32_t naluType = static_cast<uint32_t>(buffer[i + 4] & 0x1F);
        if (naluType == NALU_ID_I_FRAME)
        {
            return true;
        }
        i += NALU_HEADER_SIZE + naluSize;
    }

    return false;
}


std::vector<uint8_t>
VideoDecoder::convertCodecConfigDataToAnnexB(const VideoCodecConfigurationData& codecConfigData)
{
    std::vector<uint8_t> nalus;
    for (const auto& nalu : codecConfigData)
    {
        nalus.insert(nalus.end(), NALU_HEADER, NALU_HEADER + NALU_HEADER_SIZE);
        nalus.insert(nalus.end(), nalu.second.begin(), nalu.second.end());
    }

    return nalus;
}


void
VideoDecoder::prependAnnexBHeader(std::vector<uint8_t>& naluWithoutHeader)
{
    naluWithoutHeader.insert(naluWithoutHeader.begin(), NALU_HEADER, NALU_HEADER + NALU_HEADER_SIZE);
}


uint32_t
VideoDecoder::guessVerticalStride(uint32_t horizontalStride, uint32_t imageHeight, size_t bufferSize)
{
    // No vertical stride
    size_t expectedBufferSize = (horizontalStride * imageHeight) + (horizontalStride * imageHeight / 2);
    if (bufferSize == expectedBufferSize)
    {
        return imageHeight;
    }

    // Round imageHeight up to the next multiple of 2, 4, 8, 16, 32 and 64 and check if it fits
    for (uint32_t i = 2; i <= 64; i <<= 1)
    {
        uint32_t heightWithStride = ((imageHeight - 1) | (i - 1)) + 1;

        size_t bufferSizeWithStride = (horizontalStride * heightWithStride) + (horizontalStride * heightWithStride / 2);
        if (bufferSize == bufferSizeWithStride)
        {
            return heightWithStride;
        }
    }

    Platform::log("Could not determine a matching vertical stride. Buffer size is " + std::to_string(bufferSize) +
                  " for a " + std::to_string(horizontalStride) + "x" + std::to_string(imageHeight) + " image");
    return imageHeight;
}


size_t
VideoDecoder::trimVerticalStride(uint8_t* buffer, size_t bufferSize, uint32_t horizontalStride, uint32_t verticalStride, uint32_t imageHeight, VuforiaDriver::PixelFormat imageFormat)
{
    assert(verticalStride >= imageHeight);

    auto paddedYPlaneSize = (horizontalStride * verticalStride);
    auto paddedUvPlaneSize = (horizontalStride * verticalStride / 2); 

    size_t expectedBufferSize = paddedYPlaneSize + paddedUvPlaneSize;
    if (expectedBufferSize > bufferSize)
    {
        Platform::log("Image buffer size is " + std::to_string(bufferSize) + ", but at least " + std::to_string(expectedBufferSize) + " is expected");
        return 0;
    }

    if (verticalStride == imageHeight)
    {
        // nothing to do here
        return expectedBufferSize;
    }

    auto yPlaneSize = (horizontalStride * imageHeight);

    if(imageFormat == VuforiaDriver::PixelFormat::YV12 || imageFormat == VuforiaDriver::PixelFormat::YUV420P)
    {
        auto planeSize = (horizontalStride * imageHeight) / 4;
        auto paddedPlaneSize = horizontalStride * verticalStride / 4; 

        auto firstChromaPlaneStart = buffer + yPlaneSize;
        auto secondChromaPlaneStart = firstChromaPlaneStart + planeSize;

        auto firstPaddedChromePlaneStart = buffer + paddedYPlaneSize;
        auto secondPaddedChromaPlaneStart = firstPaddedChromePlaneStart + paddedPlaneSize;

        memmove(firstChromaPlaneStart, firstPaddedChromePlaneStart, planeSize);
        memmove(secondChromaPlaneStart, secondPaddedChromaPlaneStart, planeSize);
        return yPlaneSize + (2 * planeSize);
    }
    else if(imageFormat == VuforiaDriver::PixelFormat::NV12 || imageFormat == VuforiaDriver::PixelFormat::NV21)
    {
        auto uvPlaneSize = (horizontalStride * imageHeight) / 2;

        auto uvPlaneStart = buffer + yPlaneSize;
        auto paddedUvPlaneStart = buffer + paddedYPlaneSize;

        memmove(uvPlaneStart, paddedUvPlaneStart, uvPlaneSize);
        return yPlaneSize + uvPlaneSize;
    }
    else
    {
        Platform::log("Cannot trim vertical stride of an image buffer with format " + std::to_string(static_cast<int>(imageFormat)));
        return 0;
    }
}

} // namespace Platform
