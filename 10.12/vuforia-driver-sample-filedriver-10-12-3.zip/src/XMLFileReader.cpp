/*===============================================================================
Copyright (c) 2021 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

#include "XMLFileReader.h"

#include "Platform/Platform.h"

#include <algorithm>
#include <cassert>
#include <istream>
#include <string>
#include <sstream>

#include "pugixml.hpp"

namespace
{

std::optional<size_t>
getClosetIndex(const std::vector<XMLFileReader::ElementInfo>& items, uint64_t timestamp)
{
    if (items.size() == 0)
    {
        return {};
    }
    
    auto firstTsIt = items[0].attributeMap.find("timestamp");
    if (firstTsIt == items[0].attributeMap.end())
    {
        return {};
    }
    
    uint64_t firstTimestamp = static_cast<uint64_t>(atoll(firstTsIt->second.c_str()));
    
    uint64_t bestTimestampDelta = std::numeric_limits<uint64_t>::max();
    for (size_t i = 0; i < items.size(); ++i)
    {
        auto itemTsIt = items[i].attributeMap.find("timestamp");
        if (itemTsIt == items[i].attributeMap.end())
        {
            return {};
        }
        
        uint64_t itemTimestamp = static_cast<uint64_t>(atoll(itemTsIt->second.c_str()));
        if(firstTimestamp > itemTimestamp)
        {
            return {};
        }
        
        uint64_t relativeTimestamp = itemTimestamp - firstTimestamp;
        uint64_t delta = timestamp > relativeTimestamp ? timestamp - relativeTimestamp : relativeTimestamp - timestamp;
        
        assert(delta != bestTimestampDelta); // we should never see two items with the same delta
        
        if (delta < bestTimestampDelta)
        {
            // Moving towards target item
            bestTimestampDelta = delta;
            continue;
        }
        else if (delta > bestTimestampDelta)
        {
            // First item where we move away from target
            return i - 1;
        }
    }
    
    return items.size() - 1;
}

}


const std::vector<XMLFileReader::Version>
XMLFileReader::SUPPORTED_FORMAT_VERSIONS{ "2.0", "2.1" };

bool
XMLFileReader::load(const char* filename)
{
    bool error = false;
    if(!filename)
    {
        Platform::log("load NULL filename");
    }
    else if(!mParsingDone)
    {
        mStartedParsingFrame = false;
        pugi::xml_document doc;
        //Initialize result object to failed state
        pugi::xml_parse_result result;
        result = doc.load_file(filename, pugi::parse_default|pugi::parse_declaration);
        if (!result)
        {
            Platform::log("XMLFileReader::load: Error parsing XML file, error reported " + std::string(result.description()));
            return error;
        }
        mXmlRoot = doc.document_element();
        //parse rest of the XML nodes and set mParsingDone to true if no error occurs while parsing else will set mParsingDone to false.
        populateFramesAndPosesVector();
    }
    return mParsingDone;
}

bool
XMLFileReader::load(const void* buffer, int size)
{
    bool error = false;
    if(!buffer || !size)
    {
        Platform::log("load NULL or empty buffer");
    }
    else if(!mParsingDone)
    {
        XMLFileReader::ElementInfo seqInfo;
        mStartedParsingFrame = false;
        pugi::xml_document doc;
        //Initialize result object to failed state
        pugi::xml_parse_result result;
        result = doc.load_buffer(buffer, size, pugi::parse_default|pugi::parse_declaration);
        if (!result)
        {
            Platform::log("XMLFileReader::load: Error parsing XML file, error reported " + std::string(result.description()));
            return error;
        }
        mXmlRoot = doc.document_element();
        //parse rest of the XML nodes and set mParsingDone to true if no error occurs while parsing else will set mParsingDone to false.
        populateFramesAndPosesVector();
    }
    return mParsingDone;
}

void XMLFileReader::populateFramesAndPosesVector()
{
    bool error = false;
    mStartedParsingFrame = false;
    //process root node
    XMLFileReader::ElementInfo nodeInfo = getNodeInfo(mXmlRoot, error);
    if(error)
    {
        Platform::log("populateFramesAndPosesVector Error parsing root element");
        return;
    }
    //Move to the first child of the root node to parse subsequent nodes.
    pugi::xml_node child = mXmlRoot.first_child();

    while(!error)
    {
        nodeInfo = getNodeInfo(child, error);
        if(!nodeInfo.elementName.compare("") || error)
        {
            // pugixml parser returns element name if node is found else just returns ""
            // If unsupported version is detected, parameter 'error' will be set to true in getNodeInfo.
            break;
        }
        if(!nodeInfo.elementName.compare("CameraCapture"))
        {
            //parse the first child
            nodeInfo = getNodeInfo(child.first_child(), error);
        }
        if(!nodeInfo.elementName.compare("Elements"))
        {
            std::string source_value = nodeInfo.attributeMap["source"];
            if(source_value.compare("camera"))
            {
                child = child.next_sibling();
                Platform::log("populateFramesAndPosesVector skipping non camera source Elements, source_value "+source_value);
            }
            else
            {
                //parse the first child
                child = child.first_child();
            }
            continue;
        }
        if(!nodeInfo.elementName.compare("Element"))
        {
            child = child.first_child();
            nodeInfo = getNodeInfo(child, error); // <Frame> or <Pose>
            if(!nodeInfo.elementName.compare("Frame"))
            {
                nodeInfo = getNodeInfo(child.first_child(), error); // <Intrinsics>
                pugi::xml_node frame_node = child;
                child = child.next_sibling();
                nodeInfo = getNodeInfo(child, error); // could be Pose
                if(!nodeInfo.elementName.compare(""))
                {
                    //Frame node does not have Pose as a sibling, back track to Frame node
                    child = frame_node;
                }
            }
            if(!nodeInfo.elementName.compare("Pose"))
            {
                nodeInfo = getNodeInfo(child.first_child(), error); // <TrackableStatus>
            }
            //go back to parent ('Element') so that we can process it's next sibling in subsequent iteration
            child = child.parent();
        }
        //Move to next Element tag
        child = child.next_sibling();
    }
    if(!error)
    {
        mParsingDone = true;
        Platform::log("populateFramesAndPosesVector ok");
    }
}

XMLFileReader::ElementInfo XMLFileReader::getNextElement(uint32_t capability)
{
    XMLFileReader::ElementInfo retSeqInfo;
    //Depending on capability passed in, we will return either camera frame or pose from the respective vector once MetaData vector is exhausted.
    if(mRecordingInfo.metaDataVector.size() && (mRecordingInfo.metaDataIndex < mRecordingInfo.metaDataVector.size()))
    {
        return mRecordingInfo.metaDataVector[mRecordingInfo.metaDataIndex++];
    }
    else if(mRecordingInfo.cameraVector.size() &&
            (mRecordingInfo.cameraFrameIndex < mRecordingInfo.cameraVector.size()) &&
            (capability == VuforiaDriver::Capability::CAMERA_IMAGE))
    {
        return mRecordingInfo.cameraVector[mRecordingInfo.cameraFrameIndex++];
    }
    else if(mRecordingInfo.poseVector.size() &&
            (mRecordingInfo.poseIndex < mRecordingInfo.poseVector.size()) &&
            (capability == VuforiaDriver::Capability::CAMERA_POSE))
    {
        return mRecordingInfo.poseVector[mRecordingInfo.poseIndex++];
    }
    //recording exhausted, return ElementInfo with empty ("") elementName to end the playback.
    return retSeqInfo;
}


bool XMLFileReader::rewindRecording(uint64_t timestamp)
{
    mRecordingInfo.metaDataIndex = 0;
    
    if (mRecordingInfo.cameraVector.size() == 0)
    {
        return false;
    }
    
    auto closestCameraIndex = getClosetIndex(mRecordingInfo.cameraVector, timestamp);
    if(!closestCameraIndex.has_value())
    {
        return false;
    }
    
    mRecordingInfo.cameraFrameIndex = static_cast<uint32_t>(*closestCameraIndex);
    
    if (mRecordingInfo.poseVector.size() > 0)
    {
        auto closestPoseIndex = getClosetIndex(mRecordingInfo.poseVector, timestamp);
        if(!closestPoseIndex.has_value())
        {
            return false;
        }
        
        mRecordingInfo.poseIndex = static_cast<uint32_t>(*closestPoseIndex);
    }
    
    return true;
}


uint32_t XMLFileReader::getLoopCount() const
{
    return mRecordingInfo.loopCounter < 0 ? 0 : static_cast<uint32_t>(mRecordingInfo.loopCounter);
}


XMLFileReader::ElementInfo XMLFileReader::getNodeInfo(pugi::xml_node node, bool& error)
{
    XMLFileReader::ElementInfo seqInfo;
    seqInfo.elementName = node.name();
    pugi::xml_attribute attr;
    error = false;
    if(!seqInfo.elementName.compare("Sequence"))
    {
        //make sure mandatory attribute is present
        if(!strlen(node.attribute("version").value()))
        {
            error = true;
            Platform::log("Error parsing Sequence tag");
            return seqInfo;
        }
        mFormatVersion = std::string(node.attribute("version").value());
        if(!XMLFileReader::isFormatVersionSupported(mFormatVersion))
        {
            Platform::log(std::string("XMLFileReader::getNodeInfo Unsupported driver format version '") + mFormatVersion.toString() +
                          std::string("' in Sequence tag. Supported versions are ") + XMLFileReader::listSupportedFormatVersions());
            error = true;
        }
    }
    else if (!seqInfo.elementName.compare("Orientation"))
    {
        if(strlen(node.attribute("view").value()))
        {
            seqInfo.attributeMap.insert(std::make_pair("view", std::string(node.attribute("view").value())));
        }

        if(strlen(node.attribute("camera").value()))
        {
            seqInfo.attributeMap.insert(std::make_pair("camera", std::string(node.attribute("camera").value())));
        }

        if(strlen(node.attribute("device").value()))
        {
            seqInfo.attributeMap.insert(std::make_pair("device", std::string(node.attribute("device").value())));
        }
        mRecordingInfo.metaDataVector.push_back(seqInfo);
    }
    else if(!seqInfo.elementName.compare("CameraCapture"))
    {
        //make sure mandatory attributes are present
        if(!strlen(node.attribute("fps").value()) || !strlen(node.attribute("pixelFormat").value()))
        {
            error = true;
            Platform::log("Error parsing CameraCapture tag.");
            return seqInfo;
        }
        //default loop counter is 1. If CameraCapture has loop attribute, update loopCounter accordingly.
        mRecordingInfo.loopCounter = 1;
        if(strlen(node.attribute("loop").value()))
        {
            mRecordingInfo.loopCounter = (int)node.attribute("loop").as_int();
            //non numerical string as a loop attribute will result in 0 and will cause the recording to loop forever.
            //We only support negative numbers as a valid input to loop forever.
            if(mRecordingInfo.loopCounter == 0)
            {
                mRecordingInfo.loopCounter = 1;
            }
        }
        Platform::log("Driver loopCounter "+ std::to_string(mRecordingInfo.loopCounter));
        seqInfo.attributeMap.insert(std::make_pair("fps", std::string(node.attribute("fps").value())));
        seqInfo.attributeMap.insert(std::make_pair("pixelFormat", std::string(node.attribute("pixelFormat").value())));
        mRecordingInfo.metaDataVector.push_back(seqInfo);
    }
    else if(!seqInfo.elementName.compare("Intrinsics"))
    {
        //make sure mandatory attributes are present
        if(!strlen(node.attribute("w").value()) || !strlen(node.attribute("h").value()) || !strlen(node.attribute("fx").value()) ||
           !strlen(node.attribute("fy").value()) || !strlen(node.attribute("px").value()) || !strlen(node.attribute("py").value()) ||
           !strlen(node.attribute("rd").value()))
        {
            Platform::log("Error parsing Intrinsics tag.");
            error = true;
            return seqInfo;
        }
        //Intrinsics tag can appear inside 'CameraCapture' or 'Frame' tag.
        //CameraCapture tag appears before start of frame tag(s).
        //If this tag is contained inside Frame tag, we need to combine its attributes along with rest of the attributes from the Frame tag.
        //If part of CameraCapture, it will be added to metaData vector.
        if(mStartedParsingFrame)
        {
            if(!mParsingDone)
            {
               seqInfo = mRecordingInfo.cameraVector.back();
            }
        }
        seqInfo.attributeMap.insert(std::make_pair("w", std::string(node.attribute("w").value())));
        seqInfo.attributeMap.insert(std::make_pair("h", std::string(node.attribute("h").value())));
        seqInfo.attributeMap.insert(std::make_pair("fx", std::string(node.attribute("fx").value())));
        seqInfo.attributeMap.insert(std::make_pair("fy", std::string(node.attribute("fy").value())));
        seqInfo.attributeMap.insert(std::make_pair("px", std::string(node.attribute("px").value())));
        seqInfo.attributeMap.insert(std::make_pair("py", std::string(node.attribute("py").value())));
        seqInfo.attributeMap.insert(std::make_pair("rd", std::string(node.attribute("rd").value())));
        if(!mStartedParsingFrame)
        {
            mRecordingInfo.metaDataVector.push_back(seqInfo);
        }
    }
    else if(!seqInfo.elementName.compare("Elements"))
    {
        //make sure mandatory attribute is present
        if(!strlen(node.attribute("source").value()))
        {
            Platform::log("Error parsing source attribbute in Elements tag.");
            error = true;
            return seqInfo;
        }
        seqInfo.attributeMap.insert(std::make_pair("source", std::string(node.attribute("source").value())));
        mRecordingInfo.metaDataVector.push_back(seqInfo);
        mStartedParsingFrame = true;
    }
    else if(!seqInfo.elementName.compare("Element"))
    {
        //make sure mandatory attribute is present
        if(!strlen(node.attribute("timestamp").value()))
        {
            Platform::log("Error parsing timestamp attribute in Element tag.");
            error = true;
            return seqInfo;
        }
        mElementTS = std::string(node.attribute("timestamp").value());
        mElementPresTS = mElementTS;
        if(!strlen(node.attribute("presTimestamp").value()))
        {
            mElementPresTS = std::string(node.attribute("presTimestamp").value());
        }
    }
    else if(!seqInfo.elementName.compare("Frame") && (!mParsingDone))
    {
        //make sure mandatory attribute is present
        if(!strlen(node.attribute("filename").value()))
        {
            Platform::log("Error parsing filename attribute in Frame tag.");
            error = true;
            return seqInfo;
        }
        seqInfo.attributeMap.insert(std::make_pair("filename", "Camera/"+std::string(node.attribute("filename").value())));
        seqInfo.attributeMap.insert(std::make_pair("timestamp", mElementTS));
        seqInfo.attributeMap.insert(std::make_pair("presTimestamp", mElementPresTS));
        if (mFormatVersion >= 2.1 && !strlen(node.attribute("exposureTime").value()))
        {
            seqInfo.attributeMap.insert(std::make_pair("exposureTime", std::string(node.attribute("exposureTime").value())));
        }
        mRecordingInfo.cameraVector.push_back(seqInfo);
    }
    else if(!seqInfo.elementName.compare("Pose") && (!mParsingDone))
    {
        //make sure mandatory attributes are present
        if(!strlen(node.attribute("x").value()) || !strlen(node.attribute("y").value()) || !strlen(node.attribute("z").value()))
        {
            Platform::log("Error parsing translation in Pose tag.");
            error = true;
            return seqInfo;
        }
        //store x,y,z translation values.
        seqInfo.attributeMap.insert(std::make_pair("x", std::string(node.attribute("x").value())));
        seqInfo.attributeMap.insert(std::make_pair("y", std::string(node.attribute("y").value())));
        seqInfo.attributeMap.insert(std::make_pair("z", std::string(node.attribute("z").value())));

        //store 3*3 rotation values.
        for(int r = 0; r < NUMBER_OF_ROTN_VALUES; r++)
        {
            std::string param = "r"+std::to_string(r);
            if(!strlen(node.attribute(param.c_str()).value()))
            {
                Platform::log("Error parsing rotation data in Pose tag.");
                error = true;
                return seqInfo;
            }
            seqInfo.attributeMap.insert(std::make_pair(param, std::string(node.attribute(param.c_str()).value())));
        }
        //store remaining pose attributes
        seqInfo.attributeMap.insert(std::make_pair("timestamp", mElementTS));
        seqInfo.attributeMap.insert(std::make_pair("presTimestamp", mElementPresTS));

        mRecordingInfo.poseVector.push_back(seqInfo);
    }
    else if(!seqInfo.elementName.compare("TrackableStatus") && (!mParsingDone))
    {
        //make sure mandatory attributes are present
        if(!strlen(node.attribute("validity").value()) || !strlen(node.attribute("info").value()))
        {
            Platform::log("Error parsing TrackableStatus tag.");
            error = true;
            return seqInfo;
        }
        else
        {
            //Combine attributes from TrackableStatus tag along with rest of the attributes from the Pose tag.
            mRecordingInfo.poseVector.back().attributeMap.insert(std::make_pair("validity", std::string(node.attribute("validity").value())));
            mRecordingInfo.poseVector.back().attributeMap.insert(std::make_pair("info", std::string(node.attribute("info").value())));
        }
    }
    return seqInfo;
}
bool
XMLFileReader::isFormatVersionSupported(Version version)
{
    auto b = XMLFileReader::SUPPORTED_FORMAT_VERSIONS.begin();
    auto e = XMLFileReader::SUPPORTED_FORMAT_VERSIONS.end();
    return std::find(b, e, version) != e;
}


std::string
XMLFileReader::listSupportedFormatVersions()
{
    std::string supportedVersions, comma;

    for (auto const& version : XMLFileReader::SUPPORTED_FORMAT_VERSIONS)
    {
        supportedVersions.append(comma).append(version.toString());
        if (comma.empty())
        {
            comma = ", ";
        }
    }
    return supportedVersions;
}


XMLFileReader::Version::Version(const char* versionStr)
{
    *this = std::string(versionStr);
}
void
XMLFileReader::Version::operator=(std::string versionStr)
{
    std::string invalidStringErrorMsg;
    invalidStringErrorMsg.append("'").append(versionStr).append("' is not a valid version string");

    size_t dotPosition = versionStr.find(DOT);
    if (dotPosition == std::string::npos)
    {
        Platform::log(invalidStringErrorMsg);
        return;
    }

    auto major = versionStr.substr(0, dotPosition);
    auto minor = versionStr.substr(dotPosition + 1);

    try
    {
        mMajor = std::stoi(major);
        mMinor = std::stoi(minor);
        mCachedCopy = std::stod(versionStr);
    }
    catch (const std::invalid_argument& invArgExc)
    {
        std::string msg = invalidStringErrorMsg;
        msg.append(" - invalid_argument exception was raised:\n").append(invArgExc.what());
        Platform::log(msg);

        resetNumbers();
    }
    catch (const std::out_of_range& outOfRangeExc)
    {
        // This should never happen, as version numbers are small. However this exception
        // ought to be handled, as it's in the called functions' specs.
        std::string msg = invalidStringErrorMsg;
        msg.append(" - out_of_range exception was raised:\n").append(outOfRangeExc.what());
        Platform::log(msg);
        resetNumbers();
    }
}
bool
XMLFileReader::Version::operator>(double version) const
{
    return mCachedCopy > version;
}
bool
XMLFileReader::Version::operator==(double version) const
{
    return mCachedCopy == version;
}


bool
XMLFileReader::Version::operator==(const Version& other) const
{
    return mCachedCopy == other.mCachedCopy;
}


bool
XMLFileReader::Version::operator>=(double version) const
{
    return mCachedCopy >= version;
}


std::string
XMLFileReader::Version::toString() const
{
    std::string versionStr;
    versionStr.append(std::to_string(mMajor)).append(DOT).append(std::to_string(mMinor));
    return versionStr;
}


void
XMLFileReader::Version::resetNumbers()
{
    mMajor = 0;
    mMinor = 0;
    mCachedCopy = 0.0;
}
