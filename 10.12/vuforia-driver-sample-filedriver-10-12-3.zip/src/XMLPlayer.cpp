/*===============================================================================
Copyright (c) 2021 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/
#include "XMLPlayer.h"
#include "FileCamera.h"
#include "Platform/Platform.h"

#include <algorithm>
#include <cassert>
#include <chrono>
#include <iomanip>
#include <sstream>
#include <vector>
#include <thread>
#include "../include/FilePositionalDeviceTracker.h"

//Each camera frame starts with 'Frame' tag while each pose starts with 'Pose' tag.
static constexpr char POSE_TAG[]          = "Pose";
static constexpr char CAMERA_FRAME_TAG[]  = "Frame";

// Tags to parse driver camera recording
static constexpr char INTRINSICS_TAG[]             = "Intrinsics";
static constexpr char CAMERA_CAPTURE_TAG[]         = "CameraCapture";
static constexpr char ORIENTATION_TAG[]            = "Orientation";
static constexpr int  NUM_RAD_DIST_VALUES          = 8;

namespace
{

VuforiaDriver::PixelFormat
getPixelFormat(const std::string& format)
{
    if (format == "YUYV")
    {
        return VuforiaDriver::PixelFormat::YUYV;
    }
    else if (format == "NV21")
    {
        return VuforiaDriver::PixelFormat::NV21;
    }
    else if (format == "NV12")
    {
        return VuforiaDriver::PixelFormat::NV12;
    }
    else
    {
        Platform::log("Error: Pixel format format " + format + " is unknown");
        return VuforiaDriver::PixelFormat::UNKNOWN;
    }
}


bool
parseRotation(std::string rotationStr, uint32_t& rotation)
{
    bool parsed = false;

    try
    {
        auto value = std::stoi(rotationStr);
        if (value >= 0 && value < 360 && value % 90 == 0)
        {
            rotation = value;
            parsed = true;
        }
    }
    catch (const std::invalid_argument& invalidArg)
    {
        Platform::log("FileDriver::parseRotation : Could not parse '" + rotationStr + "' (the error was: " + invalidArg.what() + ")");
    }
    catch (const std::out_of_range& outOfRange)
    {
        Platform::log("FileDriver::parseRotation : Could not parse '" + rotationStr + "' (the error was: " + outOfRange.what() + ")");
    }

    return parsed;
}

}

//Gets the next camera frame from the recording file.
bool
XMLPlayer::getCameraFrame(VuforiaDriver::CameraFrame& cameraFrame,  std::vector<uint8_t>& frameBytes)
{
    mFileReader->setCapability(VuforiaDriver::Capability::CAMERA_IMAGE);
    std::string content;
    uint32_t frameStride = 0;
    bool gotFrame = false;
    bool result   = false;
    while(true)
    {
        XMLFileReader::ElementInfo seqInfo = mFileReader->readRecording(DRIVER_SEQ_FILE);
        if (seqInfo.elementName.length())
        {
            //Keep parsing till Camera frame tag is not found.
            if(seqInfo.elementName.compare(CAMERA_FRAME_TAG) != 0)
            {
                continue;
            }
            gotFrame = true;
            std::string fileName = seqInfo.attributeMap.at("filename");
            cameraFrame.timestamp = atoll(seqInfo.attributeMap.at("timestamp").c_str());
            if (seqInfo.attributeMap.find("exposureTime") != seqInfo.attributeMap.end()) // can use contains(key) in C++20
            {
                cameraFrame.exposureTime = atoi(seqInfo.attributeMap.at("exposureTime").c_str());
            }
            result = mFileReader->readImage(fileName, mRecordingProperties.cameraMode, frameBytes, frameStride);
            if (result)
            {
                cameraFrame.buffer = frameBytes.data();
                cameraFrame.bufferSize = static_cast<uint32_t>(frameBytes.size());
                cameraFrame.format = mRecordingProperties.cameraMode.format;
                //if per frame intrinsics is present, update camera frame height and width from it.
                if (seqInfo.attributeMap.find("h") != seqInfo.attributeMap.end())
                {
                    //use height from per frame intrinsics.
                    cameraFrame.height = atoi(seqInfo.attributeMap.at("h").c_str());
                }
                else
                {
                    //use height from global intrinsics.
                    cameraFrame.height = mRecordingProperties.cameraMode.height;
                }
                if (seqInfo.attributeMap.find("w") != seqInfo.attributeMap.end())
                {
                    //use width from per frame intrinsics.
                    cameraFrame.width = atoi(seqInfo.attributeMap.at("w").c_str());
                }
                else
                {
                    //use width from global intrinsics.
                    cameraFrame.width = mRecordingProperties.cameraMode.width;
                }
                cameraFrame.index = mCurrentFrameIndex;
                //if per frame intrinsics is present, use it else rely on global intrinsics.
                if ((seqInfo.attributeMap.find("rd") != seqInfo.attributeMap.end()) &&
                    (seqInfo.attributeMap.find("px") != seqInfo.attributeMap.end()) &&
                    (seqInfo.attributeMap.find("py") != seqInfo.attributeMap.end()) &&
                    (seqInfo.attributeMap.find("fx") != seqInfo.attributeMap.end()) &&
                    (seqInfo.attributeMap.find("fy") != seqInfo.attributeMap.end()))
                {
                    //use per frame intrinsics.
                    VuforiaDriver::CameraIntrinsics pfi;
                    pfi.principalPointX =   (float)atof(seqInfo.attributeMap.at("px").c_str());
                    pfi.principalPointY =   (float)atof(seqInfo.attributeMap.at("py").c_str());
                    pfi.focalLengthX =  (float)atof(seqInfo.attributeMap.at("fx").c_str());
                    pfi.focalLengthY =  (float)atof(seqInfo.attributeMap.at("fy").c_str());
                    // parse all radial distortion values.
                    std::istringstream attributes(seqInfo.attributeMap.at("rd").c_str());
                    std::string token;
                    for(int j = 0; j < 8; j++)
                    {
                        std::getline(attributes, token, ',');
                        pfi.distortionCoefficients[j] = (float)atof(token.c_str());
                    }
                    cameraFrame.intrinsics = pfi;
                }
                else
                {
                    //use global intrinsics.
                    cameraFrame.intrinsics = mRecordingProperties.cameraIntrinsics;
                }
                cameraFrame.stride = frameStride;
            }
            else
            {
                std::string message("Error reading ");
                message.append(fileName);
                Platform::log(message);
            }
        }
        break;
    }
    return (gotFrame && result);
}

//Gets the next pose from the recording file.
bool
XMLPlayer::getPose(VuforiaDriver::Pose& pose)
{
    mFileReader->setCapability(VuforiaDriver::Capability::CAMERA_POSE);
    
    bool gotPose = false;
    bool result  = false;
    while(true)
    {
        XMLFileReader::ElementInfo seqInfo = mFileReader->readRecording(DRIVER_SEQ_FILE);
        if (seqInfo.elementName.length())
        {
            //Keep parsing till Pose tag is not found.
            if(seqInfo.elementName.compare(POSE_TAG) != 0)
            {
                continue;
            }
            /*
            * Each pose appear in following format in XML file.
            * <Pose x='' y='' z='' r0='' r1='' r2='' r3='' r4='' r5='' r6='' r7='' r8='' validity='VALID' reason='VALID' timestamp=''/>
            *
            */
            gotPose = true;

            //First three values represent translation along x, y and z.
            pose.translationData[0] = (float)atof(seqInfo.attributeMap.at("x").c_str());
            pose.translationData[1] = (float)atof(seqInfo.attributeMap.at("y").c_str());
            pose.translationData[2] = (float)atof(seqInfo.attributeMap.at("z").c_str());

            //3*3 values represent rotation elements.
            for(int i = 0; i < NUMBER_OF_ROTN_VALUES; i++)
            {
                pose.rotationData[i] = (float)atof(seqInfo.attributeMap.at("r"+std::to_string(i)).c_str());
            }
            //Initialize pose validity and reason to known values.
            pose.validity = VuforiaDriver::PoseValidity::UNRELIABLE;
            pose.reason = VuforiaDriver::PoseReason::INITIALIZING;

            //parse pose validity, pose reason, pose base, pose target, pose coordinate system and timestamps.

            if(seqInfo.attributeMap.at("validity").compare("VALID") == 0)
            {
                pose.validity = VuforiaDriver::PoseValidity::VALID;
            }

            if(seqInfo.attributeMap.at("info").compare("VALID") == 0)
            {
                pose.reason = VuforiaDriver::PoseReason::VALID;
            }

            //Default to CAMERA coordinate system as this is the only system driver supports.
            pose.coordinateSystem = VuforiaDriver::PoseCoordSystem::CAMERA;
            pose.timestamp = atoll(seqInfo.attributeMap.at("timestamp").c_str());
            result = true;
        }
        break;
    }
    return (gotPose && result);
}


// XMLPlayer thread reads pose/frame from recording file.
void
XMLPlayer::threadFunction()
{
    bool gotPose = false;
    bool holdPose = false;
    bool gotCameraFrame = false;
    bool holdCamera = false;
    bool updateTimeOffset = true;
    bool playRealTime = (mRecordingProperties.playbackMode == FILEDRIVER_PLAYBACK_MODE_RESPECT);
    VuforiaDriver::Pose currentPose;
    VuforiaDriver::CameraFrame currentFrame;
    std::vector<uint8_t> frameBytes;
    uint64_t prvCameraTimestamp = 0;
    uint64_t prvPoseTimestamp = 0;
    uint64_t timestampOffset = 0;
    uint64_t firstTimestamp = mRecordingProperties.firstCameraTimestamp;
    
    if (mRecordingProperties.firstPoseTimestamp != 0)
    {
        firstTimestamp = std::min(firstTimestamp, mRecordingProperties.firstPoseTimestamp);
    }
    
    uint32_t numLoopsPlayed = 0;
    
    // Construct a Pose object that we can send when the recording doesn't provide one
    VuforiaDriver::Pose poseInitializing;
    memset(&poseInitializing, 0, sizeof(VuforiaDriver::Pose));
    poseInitializing.coordinateSystem = VuforiaDriver::PoseCoordSystem::CAMERA;
    poseInitializing.reason = VuforiaDriver::PoseReason::INITIALIZING;
    poseInitializing.validity = VuforiaDriver::PoseValidity::UNRELIABLE;
    
    if (mStartPositionChanged)
    {
        // start position was reset before the thread even started
        mStartPositionChanged = false;
        if(!mFileReader->rewindRecording(mStartPlaybackTimestamp))
        {
            Platform::log("Failed to restart playback. Stopping player.");
            return;
        }
        
        mPlaybackPosition = mStartPlaybackTimestamp.load();
    }
    
    while (mPlaybackState != PlaybackState::StopRequested)
    {
        {
            std::unique_lock lock(mPlaybackMutex);

            bool playbackWasPaused = false;
            if (mPlaybackState == PlaybackState::PauseRequested)
            {
                // Notify other threads that playback is now paused
                mPlaybackState = PlaybackState::Paused;
                mPlaybackCv.notify_all();

                playbackWasPaused = true;
            }
            
            mPlaybackCv.wait(lock, [this] { return mPlaybackState != PlaybackState::Paused; });
            
            if (mPlaybackState == PlaybackState::StopRequested)
            {
                break;
            }
            
            if (playbackWasPaused)
            {
                playRealTime = (mRecordingProperties.playbackMode == FILEDRIVER_PLAYBACK_MODE_RESPECT);            
            
                if (mStartPositionChanged)
                {
                    gotPose = false;
                    gotCameraFrame = false;
                    holdPose = false;
                    holdCamera = false;
                    updateTimeOffset = true;
                    mStartPositionChanged = false;
                    if(!mFileReader->rewindRecording(mStartPlaybackTimestamp))
                    {
                        Platform::log("Failed to restart playback. Stopping player.");
                        break;
                    }
                    mPlaybackPosition = mStartPlaybackTimestamp.load();
                }
            }
        }
        auto processingStartTime = std::chrono::steady_clock::now();

        uint64_t maxPrvTimestamp = std::max(prvCameraTimestamp, prvPoseTimestamp);
        if (maxPrvTimestamp != 0 && updateTimeOffset)
        {
            // Compute timestamp adjustment value after playback restarted to ensure that the
            // engine always gets incrementing and unique timestamps.
            //
            // A global timestamp offset values is computed which is added to all timestamps that will
            // be submitted to the engine. On every playback restart, this offset is incremented by the
            // duration of the previous playback.
            //
            // The duration is calculated as "lowest timestamp found in the sequence minus
            // highest timestamp seen in last playback iteration". This is then a safe offset
            // value that can be applied to both frames and poses.
            timestampOffset += (maxPrvTimestamp - firstTimestamp);

            // Reset the timestamps of the previously submitted frame/pose. (they are
            // used for computing the sleep time between farmes/poses)
            prvCameraTimestamp = 0;
            prvPoseTimestamp = 0;

            updateTimeOffset = false;
        }

        //Check if pose and camera frame were retrieved successfully
        if(mDevicePoseCallback && gotPose && gotCameraFrame)
        {
            // If pose timestamp matches camera timestamp, go ahead and send the pose into Vuforia.
            if(currentPose.timestamp == currentFrame.timestamp)
            {
                holdPose = false;
                holdCamera = false;
            }
            // No pose for the current camera frame
            // Hold on to the pose till we get a matching camera frame
            else if(currentPose.timestamp > currentFrame.timestamp)
            {
                holdPose = true;
                holdCamera = false;
                // We must send a pose before each camera frame, there wasn't a matching
                // pose in the recording so send a pose with status 'initializing'
                poseInitializing.timestamp = currentFrame.timestamp;
                prvPoseTimestamp = poseInitializing.timestamp;
                poseInitializing.timestamp += timestampOffset;
                mDevicePoseCallback(&poseInitializing);
            }
            // No camera frame for the current pose
            // Hold on to the camera frame until we get a matching pose
            else if(currentPose.timestamp < currentFrame.timestamp)
            {
                holdPose = false;
                holdCamera = true;
            }
            if (!holdPose)
            {
                if(holdCamera && currentFrame.timestamp > mRecordingProperties.lastPoseTimestamp)
                {
                    //do not hold camera frame if its TS is beyond the last pose frame TS.
                    holdCamera = false;
                }
                prvPoseTimestamp = currentPose.timestamp;
                currentPose.timestamp += timestampOffset;
                mDevicePoseCallback(&currentPose);
            }
        }
        if(gotCameraFrame && !holdCamera)
        {
            mPlaybackPosition = currentFrame.timestamp - mRecordingProperties.firstCameraTimestamp;
            if(holdPose && currentPose.timestamp > mRecordingProperties.lastCameraTimestamp)
            {
                //Do not hold a pose if its TS is beyond the last camera frame timestamp.
                holdPose = false;
            }
            prvCameraTimestamp = currentFrame.timestamp;
            currentFrame.timestamp += timestampOffset;
            // send the camera frame into Vuforia
            mCameraFrameCallback(&currentFrame);
        }

        {
            //Make sure we are not holding onto previous pose before pulling in new pose from the recording file.
            if (mDevicePoseCallback && !holdPose)
            {
                gotPose = getPose(currentPose);
            }
            //Retrieve the camera frame.
            if (mCameraFrameCallback && !holdCamera)
            {
                gotCameraFrame = getCameraFrame(currentFrame, frameBytes);
            }
        }

        // Go to sleep until the next pose or camera frame should be delivered
        uint64_t timeToNextDevicePose = 0;
        if (prvPoseTimestamp != 0 && gotPose && currentPose.timestamp > prvPoseTimestamp)
        {
            timeToNextDevicePose = currentPose.timestamp - prvPoseTimestamp;
        }
        uint64_t timeToNextCameraFrame = 0;
        if (prvCameraTimestamp != 0 && gotCameraFrame && currentFrame.timestamp > prvCameraTimestamp)
        {
            timeToNextCameraFrame = currentFrame.timestamp - prvCameraTimestamp;
        }
        auto timeToNext = (mDevicePoseCallback) ? std::min(timeToNextDevicePose, timeToNextCameraFrame) : timeToNextCameraFrame;

        auto processingTime = std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now() - processingStartTime).count();

        auto sleepTime = (timeToNext > uint64_t(processingTime)) ? timeToNext - processingTime : 0;
        if (playRealTime && sleepTime > 1000000) // avoid short sleeps
        {
            std::this_thread::sleep_for(std::chrono::nanoseconds(sleepTime));
        }

        if((!gotCameraFrame && !gotPose && !holdPose) || mPlaybackPosition >= mEndPlaybackTimestamp)
        {
            std::unique_lock lock(mPlaybackMutex);
            numLoopsPlayed++;
            
            if (mLoopCount > 0 && numLoopsPlayed >= mLoopCount)
            {
                mPlaybackState = PlaybackState::PauseRequested;
                numLoopsPlayed = 0;
            }
            
            gotPose = false;
            gotCameraFrame = false;
            holdPose = false;
            holdCamera = false;
            updateTimeOffset = true;
            
            if(!mFileReader->rewindRecording(mStartPlaybackTimestamp))
            {
                Platform::log("Failed to restart playback. Stopping player.");
                mPlaybackState = PlaybackState::StopRequested;
                break;
            }
            
            mPlaybackPosition = mStartPlaybackTimestamp.load();
        }
    }

    mPlaybackState = PlaybackState::Stopped;
}


XMLPlayer::~XMLPlayer()
{
    {
        std::scoped_lock lock(mPlaybackMutex);
        mPlaybackState = PlaybackState::StopRequested;
        mPlaybackCv.notify_one();
    }
    
    if (mPlayingThread.joinable())
    {
        mPlayingThread.join();
    }
    
    if(mFileReader)
    {
        mFileReader->deInit();
    }
}


bool
XMLPlayer::init(VuforiaDriver::PlatformData* platformData, FileDriverUserData* userData)
{
    assert(platformData != nullptr);
    
    mFileReader = Platform::createFileReader();

    if(!mFileReader->init(platformData, userData))
    {
        return false;
    }
    
    if (!readRecordingProperties())
    {
        return false;
    }
    
    // Playback is initialized in paused state. Playback will 
    // be "resumed" when start() is called.
    mPlaybackState = PlaybackState::PauseRequested;
    mPlayingThread = std::thread(&XMLPlayer::threadFunction, this);
    return true;
}

bool
XMLPlayer::open(CameraFrameCallback cameraCallback)
{
    mCameraFrameCallback = std::move(cameraCallback);
    return true;
}

bool
XMLPlayer::open(DevicePoseCallback poseCallback)
{
    mDevicePoseCallback = std::move(poseCallback);
    return true;
}

bool
XMLPlayer::start()
{
    std::lock_guard<std::mutex> lock(mPlaybackMutex);

    if (mPlaybackState == PlaybackState::Stopped)
    {
        // Stopped state means that the playback thread has ended.
        // Cannot resume playback without full re-init.
        Platform::log("Cannot start playback as the playback thread is stopped.");
        return false;
    }

    mPlaybackState = PlaybackState::Running;
    mPlaybackCv.notify_one();
    return true;
}

bool
XMLPlayer::stop()
{
    std::unique_lock<std::mutex> lock(mPlaybackMutex);

    if (mPlaybackState != PlaybackState::Running)
    {
        // Nothing to do here. Playback is already paused or stopped.
        // (e.g. because end of sequence was reached)
        return true;
    }

    mPlaybackState = PlaybackState::PauseRequested;

    // Wait for state change.
    //    Paused -> playback thread confirmed pause
    //    Stopped -> error on playback thread
    //    Running -> (unlikely) concurrent start() call
    mPlaybackCv.wait(lock, [this] { return mPlaybackState != PlaybackState::PauseRequested; });
    return mPlaybackState != PlaybackState::Running;
}

void
XMLPlayer::close()
{
    std::lock_guard<std::mutex> lock(mPlaybackMutex);
    mCameraFrameCallback = nullptr;
    mDevicePoseCallback = nullptr;
}

bool
XMLPlayer::setPlaybackStartTime(uint64_t timestamp)
{
    if (timestamp > mRecordingProperties.lastCameraTimestamp - mRecordingProperties.firstCameraTimestamp)
    {
        return false;
    }

    if (timestamp >= mEndPlaybackTimestamp)
    {
        return false;
    }
    
    mStartPlaybackTimestamp = timestamp;
    mStartPositionChanged = true;
    
    return true;
}

bool
XMLPlayer::setPlaybackEndTime(uint64_t timestamp)
{
    if (timestamp > mRecordingProperties.lastCameraTimestamp - mRecordingProperties.firstCameraTimestamp)
    {
        return false;
    }
    
    if (timestamp <= mStartPlaybackTimestamp)
    {
        return false;
    }
    
    mEndPlaybackTimestamp = timestamp;
    return true;
}

uint64_t
XMLPlayer::getPlaybackPosition()
{
    return mPlaybackPosition;
}

void
XMLPlayer::setPlaybackLoop(uint32_t loopCount)
{
    mLoopCount = loopCount;
}


void
XMLPlayer::setPlaybackMode(FileDriverPlaybackMode mode)
{
    mRecordingProperties.playbackMode = mode;
}


bool
XMLPlayer::readRecordingProperties()
{
    mFileReader->setCapability(VuforiaDriver::Capability::CAMERA_IMAGE);

    XMLFileReader::ElementInfo seqInfo = mFileReader->readRecording(DRIVER_SEQ_FILE);
    if(seqInfo.elementName.length() == 0)
    {
        Platform::log("Error: Failed to open or parse " + std::string(DRIVER_SEQ_FILE));
        mFileReader->rewindRecording(0);
        return false;
    }

    uint64_t frameTimestamp = 0;
    while (seqInfo.elementName.length() > 0)
    {
        // Once a match is found for the tag, parse attributes within each tag
        if(seqInfo.elementName.compare(CAMERA_CAPTURE_TAG) == 0)
        {
            mRecordingProperties.cameraMode.fps =  atoi(seqInfo.attributeMap.at("fps").c_str());
            mRecordingProperties.cameraMode.format = getPixelFormat(seqInfo.attributeMap.at("pixelFormat").c_str());
        }
        else if(seqInfo.elementName.compare(INTRINSICS_TAG) == 0)
        {
            mRecordingProperties.cameraMode.width =   atoi(seqInfo.attributeMap.at("w").c_str());
            mRecordingProperties.cameraMode.height =  atoi(seqInfo.attributeMap.at("h").c_str());
            mRecordingProperties.cameraIntrinsics.principalPointX =   (float)atof(seqInfo.attributeMap.at("px").c_str());
            mRecordingProperties.cameraIntrinsics.principalPointY =   (float)atof(seqInfo.attributeMap.at("py").c_str());
            mRecordingProperties.cameraIntrinsics.focalLengthX =  (float)atof(seqInfo.attributeMap.at("fx").c_str());
            mRecordingProperties.cameraIntrinsics.focalLengthY =  (float)atof(seqInfo.attributeMap.at("fy").c_str());
            // parse all radial distortion values.
            std::istringstream attributes(seqInfo.attributeMap.at("rd").c_str());
            std::string token;
            for(int j = 0; j < NUM_RAD_DIST_VALUES; j++)
            {
                std::getline(attributes, token, ',');
                mRecordingProperties.cameraIntrinsics.distortionCoefficients[j] = (float)atof(token.c_str());
            }
        }
        else if(seqInfo.elementName.compare(CAMERA_FRAME_TAG) == 0)
        {
            frameTimestamp = atoll(seqInfo.attributeMap.at("timestamp").c_str());
            if (mRecordingProperties.firstCameraTimestamp == 0)
            {
                mRecordingProperties.firstCameraTimestamp = frameTimestamp;
            }
        }

        seqInfo = mFileReader->readRecording(DRIVER_SEQ_FILE);
    }
    mFileReader->rewindRecording(0);

    mRecordingProperties.lastCameraTimestamp = frameTimestamp;
        
    checkRecordingHasDevicePoses();
    
    mLoopCount = mFileReader->getLoopCount();
    return true;
}

const RecordingProperties&
XMLPlayer::getRecordingProperties() const
{
    return mRecordingProperties;
}


void
XMLPlayer::checkRecordingHasDevicePoses()
{
    //set the hint to parse for Pose.
    mFileReader->setCapability(VuforiaDriver::Capability::CAMERA_POSE);
    XMLFileReader::ElementInfo seqInfo = mFileReader->readRecording(DRIVER_SEQ_FILE);

    uint64_t poseTiemstamp = 0;

    bool gotOrientationInfo = true;
    while (true)
    {
        if (seqInfo.elementName.length())
        {
            if(seqInfo.elementName.compare(POSE_TAG) == 0)
            {
                // Update capability as we found pose in the recording.
                mRecordingProperties.hasDevicePoses = true;

                poseTiemstamp = atoll(seqInfo.attributeMap.at("timestamp").c_str());
                if (mRecordingProperties.firstPoseTimestamp == 0)
                {
                    mRecordingProperties.firstPoseTimestamp = poseTiemstamp;
                }
            }
            else if (seqInfo.elementName.compare(ORIENTATION_TAG) == 0)
            {
                if (seqInfo.attributeMap.find("device") != seqInfo.attributeMap.end())
                {
                    gotOrientationInfo &= parseRotation(seqInfo.attributeMap.at("device"), mRecordingProperties.recDevOrientInDegrees);
                }

                if (gotOrientationInfo && seqInfo.attributeMap.find("camera") != seqInfo.attributeMap.end())
                {
                    gotOrientationInfo &= parseRotation(seqInfo.attributeMap.at("camera"), mRecordingProperties.recCamOrientInDegrees);
                }

                mRecordingProperties.supportsCameraOrientation = gotOrientationInfo;
            }
        }
        else
        {
            // We reached the end of the recording.
            break;
        }

        // Parse the next XML element.
        seqInfo = mFileReader->readRecording(DRIVER_SEQ_FILE);
    }
    mFileReader->rewindRecording(0);
    mRecordingProperties.lastPoseTimestamp = poseTiemstamp;
}
