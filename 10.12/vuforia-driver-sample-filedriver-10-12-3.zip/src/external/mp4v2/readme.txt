mp4v2 5.0.0 (TechSmith fork) - a library to create, read and modify mp4 files as defined by ISO-IEC:14496-1:2001 MPEG-4 Systems. 
The full source for mp4v2 can be found at https://github.com/TechSmith/mp4v2
mp4v2 is licensed under the Mozilla Public License, version 1.1.