/*===============================================================================
Copyright (c) 2021 PTC Inc. All Rights Reserved.

Confidential and Proprietary - Protected under copyright and other laws.
Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/
#include "FilePositionalDeviceTracker.h"
#include "Player.h"
#include "Platform/Platform.h"
#include <sstream>


FilePositionalDeviceTracker::FilePositionalDeviceTracker(Player* player) : mPlayer(player)
{
}

bool
FilePositionalDeviceTracker::open()
{
    if (mPlayer == nullptr)
    {
        Platform::log("Failed to open device tracker, player not initialized");
        return false;
    }
    return mPlayer->open([this](VuforiaDriver::Pose* poseInfo) { posesPlayerCallback(poseInfo); });
}

bool
FilePositionalDeviceTracker::close()
{
    if (mPlayer == nullptr)
    {
        Platform::log("Failed to close device tracker, player not initialized");
        return false;
    }
    mPlayer->close();
    return true;
}

bool FilePositionalDeviceTracker::resetTracking()
{
    //return false as resetTracking is not implemented in FilePositionalDeviceTracker(reference) implementation.
    return false;
}

bool
FilePositionalDeviceTracker::start(VuforiaDriver::PoseCallback* cb, VuforiaDriver::AnchorCallback* acb)
{
    // Assign the callback that will be used to deliver the poses to Vuforia.
    mCallback = cb;
    (void)acb;
    if (mPlayer == nullptr)
    {
        Platform::log("Failed to start device tracker, player not initialized");
        return false;
    }
    return mPlayer->start();
}

bool
FilePositionalDeviceTracker::stop()
{
    if (mPlayer == nullptr)
    {
        Platform::log("Failed to stop device tracker, player not initialized");
        return false;
    }
    return mPlayer->stop();
}

void
FilePositionalDeviceTracker::posesPlayerCallback(VuforiaDriver::Pose* info)
{
    if (mCallback)
    {
        mCallback->onNewPose(info);
    }
    else
    {
        Platform::log("Pose callback to Vuforia not found.");
    }
}
