/*===============================================================================
Copyright (c) 2021 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

#include "MP4Player.h"
#include "MP4SampleDeserializer.h"
#include "Platform/Platform.h"

#ifdef __ANDROID__
#include "Platform/Android/ScopedJNIEnv.h"
#endif

#ifdef __APPLE__
#include <TargetConditionals.h>
#endif

#include <cassert>

constexpr auto VUFORIA_TAG_VERSION = "com.vuforia.recording.version";
constexpr auto VUFORIA_TAG_FPS = "com.vuforia.recording.camera.fps";
constexpr auto VUFORIA_TAG_INTRINSICS = "com.vuforia.recording.camera.intrinsics";
constexpr auto VUFORIA_TAG_CAMERA_ORIENTATION = "com.vuforia.recording.orientation.camera";
constexpr auto VUFORIA_TAG_DEVICE_ORIENTATION = "com.vuforia.recording.orientation.device";
constexpr auto VUFORIA_TRACK_TYPE_CAMERA_METADATA = "vucm";
constexpr auto VUFORIA_TRACK_TYPE_DEVICE_POSES = "vudp";
constexpr int32_t SUPPORTED_RECORDING_VERSION = 1;

using namespace Platform;


MP4Player::~MP4Player()
{
    {
        std::scoped_lock lock(mPlaybackMutex);
        mPlaybackState = PlaybackState::StopRequested;
        mPlaybackCv.notify_all();
    }
    
    if (mPlaybackThread.joinable())
    {
        mPlaybackThread.join();
    }
    
    if (mMP4Reader != nullptr)
    {
        mMP4Reader->close();
    }
}


bool
MP4Player::init(VuforiaDriver::PlatformData* platformData, FileDriverUserData* userData)
{
    mFileReader = createFileReader();
    if(!mFileReader->init(platformData, userData))
    {
        Platform::log("Failed to init file reader.");
        return false;
    }
    
    if (userData == nullptr || userData->sequenceDirectoryAbsolutePath == nullptr)
    {
        mMP4Reader = MP4Reader::openAsset(MP4_ASSET_NAME, mFileReader, platformData);
    }
    else
    {
        std::string path = userData->sequenceDirectoryAbsolutePath;
        if (mFileReader->isAssetUri(path))
        {
            mMP4Reader = MP4Reader::openAsset(mFileReader->getAssetPathFromAssetUri(path), mFileReader, platformData);
        }
        else
        {
            mMP4Reader = MP4Reader::open(userData->sequenceDirectoryAbsolutePath, platformData);
        }
    }

    if (mMP4Reader == nullptr)
    {
        Platform::log("Could not open MP4 file.");
        return false;
    }

    mPlatformData = platformData;
    
    if (!isCompatibleMP4Recording())
    {
        Platform::log("The provided MP4 file is not compatible with FileDriver.");
        return false;
    }

    // This call has to be performed before readRecordingProperties() as it sets up the platform video decoder
    // which is needed to determine the image format that will be used for camera frames.
    if (!initializeTracksForPlayback())
    {
        // errors are logged by called method
        return false;
    }
    
    readRecordingProperties();
    
    // Playback is initialized in paused state. Playback will 
    // be "resumed" when start() is called.
    mPlaybackState = PlaybackState::PauseRequested;
    mPlaybackThread = std::thread(&MP4Player::playbackThread, this);
    return true;
}


bool
MP4Player::open(CameraFrameCallback cameraCallback)
{
    std::scoped_lock lock(mPlaybackMutex);
    if (!mVideoTrack.has_value() || !mCameraMetadataTrack.has_value())
    {
        Platform::log("Failed to open camera. The required tracks from the MP4 file are not loaded.");
        return false;
    }

    mCameraFrameCallback = cameraCallback;
    return true;
}


bool
MP4Player::open(DevicePoseCallback poseCallback)
{
    std::scoped_lock lock(mPlaybackMutex);
    if (!mDevicePoseTrack.has_value())
    {
        Platform::log("Failed to open device tracker. The required track from the MP4 file is not loaded.");
        return false;
    }

    mDevicePoseCallback = poseCallback;
    return true;
}


bool
MP4Player::start()
{
    std::scoped_lock lock(mPlaybackMutex);

    if (mPlaybackState == PlaybackState::Stopped)
    {
        // Stopped state means that the playback thread has ended.
        // Cannot resume playback without full re-init.
        Platform::log("Cannot start playback as the playback thread is stopped.");
        return false;
    }

    mPlaybackState = PlaybackState::Running;
    mPlaybackCv.notify_all();
    return true;
}


bool
MP4Player::stop()
{
    std::unique_lock lock(mPlaybackMutex);

    if (mPlaybackState != PlaybackState::Running)
    {
        // Nothing to do here. Playback is already paused or stopped.
        // (e.g. because end of sequence was reached)
        return true;
    }

    mPlaybackState = PlaybackState::PauseRequested;

    // Wait for state change.
    //    Paused -> playback thread confirmed pause
    //    Stopped -> error on playback thread
    //    Running -> (unlikely) concurrent start() call
    mPlaybackCv.wait(lock, [this] { return mPlaybackState != PlaybackState::PauseRequested; });
    return mPlaybackState != PlaybackState::Running;
}


void
MP4Player::close()
{
    std::scoped_lock lock(mPlaybackMutex);
    mCameraFrameCallback = nullptr;
    mDevicePoseCallback = nullptr;
}


const RecordingProperties&
MP4Player::getRecordingProperties() const
{
    return mRecordingProperties;
}


bool
MP4Player::setPlaybackStartTime(uint64_t timestamp)
{
    if (timestamp > mRecordingProperties.lastCameraTimestamp - mRecordingProperties.firstCameraTimestamp)
    {
        return false;
    }

    if (timestamp >= mEndPlaybackTimestamp)
    {
        return false;
    }
    
    mStartPlaybackTimestamp = timestamp;
    mStartPositionChanged = true;
    
    return true;
}


bool
MP4Player::setPlaybackEndTime(uint64_t timestamp)
{
    if (timestamp > mRecordingProperties.lastCameraTimestamp - mRecordingProperties.firstCameraTimestamp)
    {
        return false;
    }
    
    if (timestamp <= mStartPlaybackTimestamp)
    {
        return false;
    }
    
    mEndPlaybackTimestamp = timestamp;
    return true;
}


uint64_t
MP4Player::getPlaybackPosition()
{
    return mPlaybackPosition;
}


void
MP4Player::setPlaybackLoop(uint32_t loopCount)
{
    mLoopCount = loopCount;
}


void
MP4Player::setPlaybackMode(FileDriverPlaybackMode mode)
{
    mRecordingProperties.playbackMode = mode;
}


bool
MP4Player::isCompatibleMP4Recording() const
{
    assert(mMP4Reader != nullptr);
    
    // Check the version tag
    auto version = mMP4Reader->getInt32Tag(VUFORIA_TAG_VERSION);
    if (!version.has_value() || *version != SUPPORTED_RECORDING_VERSION)
    {
        return false;
    }
    
    // Check that a video track and a metadata track exist
    auto videoTracks = mMP4Reader->getTracks(MP4_TRACK_TYPE_VIDEO);
    auto cameraMetadataTracks = mMP4Reader->getTracks(VUFORIA_TRACK_TYPE_CAMERA_METADATA);
    return !videoTracks.empty() && !cameraMetadataTracks.empty();
}


void
MP4Player::readRecordingProperties()
{
    assert(mMP4Reader != nullptr);
    
    auto fpsTag = mMP4Reader->getInt32Tag(VUFORIA_TAG_FPS);
    auto intrinsicsTag = mMP4Reader->getByteArrayTag(VUFORIA_TAG_INTRINSICS);
    auto deviceOrientationTag = mMP4Reader->getInt32Tag(VUFORIA_TAG_DEVICE_ORIENTATION);
    auto cameraOrientationTag = mMP4Reader->getInt32Tag(VUFORIA_TAG_CAMERA_ORIENTATION);
    
    auto videoTracks = mMP4Reader->getTracks(MP4_TRACK_TYPE_VIDEO);
    auto metadataTracks = mMP4Reader->getTracks(VUFORIA_TRACK_TYPE_CAMERA_METADATA);
    auto devicePoseTracks = mMP4Reader->getTracks(VUFORIA_TRACK_TYPE_DEVICE_POSES);

    // already checked via isCompatibleMP4Recording()
    assert(!videoTracks.empty());
    assert(!metadataTracks.empty());
    
    const MP4Reader::TrackInfo& videoTrack = videoTracks[0];
    
    mRecordingProperties.cameraMode.format = mMP4Reader->getVideoColorOutputFormat();
    mRecordingProperties.cameraMode.width = videoTrack.mVideoWidth;
    mRecordingProperties.cameraMode.height = videoTrack.mVideoHeight;
    
    if (fpsTag.has_value())
    {
        mRecordingProperties.cameraMode.fps = *fpsTag;
    }
    
    if (intrinsicsTag.has_value())
    {
        auto intrinsics = MP4SampleDeserializer::readIntrinsics(*intrinsicsTag);
        if (intrinsics.has_value())
        {
            mRecordingProperties.cameraIntrinsics = *intrinsics;
        }
    }
        
    if (deviceOrientationTag.has_value() && cameraOrientationTag.has_value())
    {
        mRecordingProperties.recCamOrientInDegrees = *cameraOrientationTag;
        mRecordingProperties.recDevOrientInDegrees = *deviceOrientationTag;
        mRecordingProperties.supportsCameraOrientation = true;
    }
    
    mRecordingProperties.numberOfImages = videoTrack.mNumSamples;
    mRecordingProperties.hasDevicePoses = !devicePoseTracks.empty();

    if(mRecordingProperties.hasDevicePoses)
    {
        auto poseSampleInfo = mMP4Reader->readSample(devicePoseTracks[0].mId, 0, mSampleReadBuffer);
        if(poseSampleInfo.has_value())
        {            
            if(auto devicePose = MP4SampleDeserializer::readDevicePose(mSampleReadBuffer); devicePose.has_value())
            {
                mRecordingProperties.firstPoseTimestamp = devicePose->timestamp;
            }
        }

        poseSampleInfo = mMP4Reader->readSample(devicePoseTracks[0].mId, devicePoseTracks[0].mNumSamples - 1, mSampleReadBuffer);
        if(poseSampleInfo.has_value())
        {            
            if(auto devicePose = MP4SampleDeserializer::readDevicePose(mSampleReadBuffer); devicePose.has_value())
            {
                mRecordingProperties.lastPoseTimestamp = devicePose->timestamp;
            }
        }
    }

    auto frameSampleInfo = mMP4Reader->readSample(metadataTracks[0].mId, 0, mSampleReadBuffer);
    if(frameSampleInfo.has_value())
    {        
        if(auto frameMetadata = MP4SampleDeserializer::readFrameMetadata(mSampleReadBuffer); frameMetadata.has_value())
        {
            mRecordingProperties.firstCameraTimestamp = frameMetadata->mTimestamp;
        }
    }

    frameSampleInfo = mMP4Reader->readSample(metadataTracks[0].mId, metadataTracks[0].mNumSamples - 1, mSampleReadBuffer);
    if(frameSampleInfo.has_value())
    {        
        if(auto frameMetadata = MP4SampleDeserializer::readFrameMetadata(mSampleReadBuffer); frameMetadata.has_value())
        {
            mRecordingProperties.lastCameraTimestamp = frameMetadata->mTimestamp;
        }
    }
}


bool 
MP4Player::resetPlaybackToStart()
{
    assert(mMP4Reader != nullptr);

    mVideoTrack.reset();
    mCameraMetadataTrack.reset();
    mDevicePoseTrack.reset();
    mMP4Reader->reset();    
    return initializeTracksForPlayback();
}


bool 
MP4Player::initializeTracksForPlayback()
{
    assert(mMP4Reader != nullptr);

    auto videoTracks = mMP4Reader->getTracks(MP4_TRACK_TYPE_VIDEO);
    auto metadataTracks = mMP4Reader->getTracks(VUFORIA_TRACK_TYPE_CAMERA_METADATA);
    auto devicePoseTracks = mMP4Reader->getTracks(VUFORIA_TRACK_TYPE_DEVICE_POSES);

    if (videoTracks.empty() || metadataTracks.empty())
    {
        Platform::log("No video+metadata track found in file.");
        return false;
    }
    
    if (videoTracks[0].mNumSamples != metadataTracks[0].mNumSamples)
    {
        Platform::log("Video and metadata track do not match.");
        return false;
    }
    
    if(!mMP4Reader->selectTrack(videoTracks[0].mId))
    {
        Platform::log("Could not select video track for playback.");
        return false;
    }
    
    if(!mMP4Reader->selectTrack(metadataTracks[0].mId))
    {
        Platform::log("Could not select camera metadata track for playback.");
        return false;
    }
      
    mNumFramesRead = 0;
    mVideoTrack = videoTracks[0];
    mCameraMetadataTrack = metadataTracks[0];
    
    auto maxRequiredBufferSize = metadataTracks[0].mMaxSampleSize;

    if (!devicePoseTracks.empty())
    {
        if(!mMP4Reader->selectTrack(devicePoseTracks[0].mId))
        {
            Platform::log("Could not select device pose track for playback.");
            return false;
        }
            
        mNumDevicePosesRead = 0;
        mDevicePoseTrack = devicePoseTracks[0];
        maxRequiredBufferSize = std::max(maxRequiredBufferSize, metadataTracks[0].mMaxSampleSize);
    }

    if (mSampleReadBuffer.capacity() < maxRequiredBufferSize)
    {
        mSampleReadBuffer.reserve(maxRequiredBufferSize);
    }
    
    mPlaybackPosition = mStartPlaybackTimestamp.load();
    
    // Configure proper start position
    if (mStartPlaybackTimestamp > 0)
    {
        auto videoSampleIndex = mMP4Reader->getSampleIndexForTimestamp(videoTracks[0].mId, mStartPlaybackTimestamp / 1000);
        
        if (!videoSampleIndex.has_value())
        {
            Platform::log("Could not find video sample index for timestamp " + std::to_string(mStartPlaybackTimestamp));
            return false;
        }
        
        if (!mMP4Reader->setPlaybackLocation(videoTracks[0].mId, *videoSampleIndex))
        {
            Platform::log("Failed to set playback location of video track.");
            return false;
        }
        
        if (!mMP4Reader->setPlaybackLocation(metadataTracks[0].mId, *videoSampleIndex))
        {
            Platform::log("Failed to set playback location of camera metadata track.");
            return false;
        }
        
        if (!devicePoseTracks.empty())
        {
            auto poseSampleIndex = mMP4Reader->getSampleIndexForTimestamp(devicePoseTracks[0].mId, mStartPlaybackTimestamp / 1000);
            
            if (!poseSampleIndex.has_value())
            {
                Platform::log("Could not find pose sample index for timestamp " + std::to_string(mStartPlaybackTimestamp));
                return false;
            }
            
            if (!mMP4Reader->setPlaybackLocation(devicePoseTracks[0].mId, *poseSampleIndex))
            {
                Platform::log("Failed to set playback location of pose track.");
                return false;
            }
        }
    }

    return true;
}


void
MP4Player::playbackThread()
{
#ifdef __ANDROID__
    assert(mPlatformData != nullptr);
    Android::ScopedJNIEnv jniEnv(mPlatformData->javaVM, mPlatformData->jniVersion);
    if (jniEnv == nullptr)
    {
        Platform::log("No JNIEnv available");
        return;
    }
#endif

    std::optional<VuforiaDriver::CameraFrame> currentFrame{};
    std::optional<VuforiaDriver::Pose> currentPose{};
    
    bool holdCamera = false;
    bool holdPose = false;
    bool updateTimeOffset = true;
    bool playRealTime = (mRecordingProperties.playbackMode == FILEDRIVER_PLAYBACK_MODE_RESPECT);
    
    uint64_t prvCameraTimestamp = 0;
    uint64_t prvPoseTimestamp = 0;
    uint64_t timestampOffset = 0;
    uint64_t firstTimestamp = mRecordingProperties.firstCameraTimestamp;
    
    if (mRecordingProperties.firstPoseTimestamp != 0)
    {
        firstTimestamp = std::min(firstTimestamp, mRecordingProperties.firstPoseTimestamp);
    }
    
    uint32_t numLoopsPlayed = 0;
    
    // Construct a Pose object that we can send when the recording doesn't provide one
    VuforiaDriver::Pose poseInitializing{};
    poseInitializing.coordinateSystem = VuforiaDriver::PoseCoordSystem::CAMERA;
    poseInitializing.reason = VuforiaDriver::PoseReason::INITIALIZING;
    poseInitializing.validity = VuforiaDriver::PoseValidity::UNRELIABLE;

    if (mStartPositionChanged)
    {
        std::unique_lock lock(mPlaybackMutex);
        
        // start position was reset before the thread even started
        mStartPositionChanged = false;
        if(!resetPlaybackToStart())
        {
            Platform::log("Failed to restart playback. Stopping player.");
            return;
        }
    }
        
    while (mPlaybackState != PlaybackState::StopRequested)
    {
        {
            std::unique_lock lock(mPlaybackMutex);

            bool playbackWasPaused = false;
            if (mPlaybackState == PlaybackState::PauseRequested)
            {
                mMP4Reader->pause();

                // Notify other threads that playback is now paused
                mPlaybackState = PlaybackState::Paused;
                mPlaybackCv.notify_all();

                playbackWasPaused = true;
            }

            mPlaybackCv.wait(lock, [this] { return mPlaybackState != PlaybackState::Paused; });
            
            if (mPlaybackState == PlaybackState::StopRequested)
            {
                break;
            }

            if (playbackWasPaused)
            {
                playRealTime = (mRecordingProperties.playbackMode == FILEDRIVER_PLAYBACK_MODE_RESPECT);

                if(!mMP4Reader->resume())
                {
                    Platform::log("Failed to resume MP4 playback.");
                    break;
                }
                
                if (mStartPositionChanged)
                {
                    currentFrame.reset();
                    currentPose.reset();
                    holdPose = false;
                    holdCamera = false;
                    updateTimeOffset = true;
                    mStartPositionChanged = false;
                    if(!resetPlaybackToStart())
                    {
                        Platform::log("Failed to restart playback. Stopping player.");
                        break;
                    }
                }
            }
        }
        
        auto processingStartTime = std::chrono::steady_clock::now();

        uint64_t maxPrvTimestamp = std::max(prvCameraTimestamp, prvPoseTimestamp);
        if (maxPrvTimestamp != 0 && updateTimeOffset)
        {
            // Compute timestamp adjustment value after playback restarted to ensure that the
            // engine always gets incrementing and unique timestamps.
            //
            // A global timestamp offset values is computed which is added to all timestamps that will 
            // be submitted to the engine. On every playback restart, this offset is incremented by the 
            // duration of the previous playback.
            //
            // The duration is calculated as "lowest timestamp found in the sequence minus 
            // highest timestamp seen in last playback iteration". This is then a safe offset 
            // value that can be applied to both frames and poses.
            timestampOffset += (maxPrvTimestamp - firstTimestamp);

            // Reset the timestamps of the previously submitted frame/pose. (they are
            // used for computing the sleep time between farmes/poses)
            prvCameraTimestamp = 0;
            prvPoseTimestamp = 0;

            updateTimeOffset = false;
        }


        // Check if pose and camera frame were retrieved successfully
        if(mDevicePoseCallback && currentFrame.has_value() && currentPose.has_value())
        {
            // If pose timestamp matches camera timestamp, go ahead and send the pose into Vuforia.
            if(currentPose->timestamp == currentFrame->timestamp)
            {
                holdPose = false;
                holdCamera = false;
            }
            // No pose for the current camera frame
            // Hold on to the pose till we get a matching camera frame
            else if(currentPose->timestamp > currentFrame->timestamp)
            {
                holdPose = true;
                holdCamera = false;
                // We must send a pose before each camera frame, there wasn't a matching
                // pose in the recording so send a pose with status 'initializing'
                poseInitializing.timestamp = currentFrame->timestamp;
                prvPoseTimestamp = poseInitializing.timestamp;
                poseInitializing.timestamp += timestampOffset;
                mDevicePoseCallback(&poseInitializing);
            }
            // No camera frame for the current pose
            // Hold on to the camera frame until we get a matching pose
            else if(currentPose->timestamp < currentFrame->timestamp)
            {
                holdPose = false;
                holdCamera = true;
            }
            
            if (!holdPose)
            {
                if(holdCamera && currentFrame->timestamp > mRecordingProperties.lastPoseTimestamp)
                {
                    // do not hold camera frame if its TS is beyond the last pose frame TS.
                    holdCamera = false;
                }
                prvPoseTimestamp = currentPose->timestamp;
                currentPose->timestamp += timestampOffset;
                mDevicePoseCallback(&(*currentPose));
            }
        }
        if(currentFrame.has_value() && !holdCamera)
        {
            mPlaybackPosition = currentFrame->timestamp - mRecordingProperties.firstCameraTimestamp;
            if(holdPose && currentPose->timestamp > mRecordingProperties.lastCameraTimestamp)
            {
                // Do not hold a pose if its TS is beyond the last camera frame timestamp.
                holdPose = false;
            }
            prvCameraTimestamp = currentFrame->timestamp;
            currentFrame->timestamp += timestampOffset;
            // send the camera frame into Vuforia
            mCameraFrameCallback(&(*currentFrame));
        }

        {
            std::lock_guard<std::mutex> lock(mPlaybackMutex);
            
            // Make sure we are not holding onto previous pose before pulling in new pose from the recording file.
            if (mDevicePoseCallback && !holdPose)
            {
                currentPose = readNextDevicePose();
            }
            
            // Retrieve the camera frame.
            if (mCameraFrameCallback && !holdCamera)
            {
                currentFrame = readNextCameraFrame();
            }
        }


        // Go to sleep until the next pose or camera frame should be delivered
        uint64_t timeToNextDevicePose = 0;
        if (prvPoseTimestamp != 0 && currentPose.has_value() && currentPose->timestamp > prvPoseTimestamp)
        {
            timeToNextDevicePose = currentPose->timestamp - prvPoseTimestamp;
        }
        uint64_t timeToNextCameraFrame = 0;
        if (prvCameraTimestamp != 0 && currentFrame.has_value() && currentFrame->timestamp > prvCameraTimestamp)
        {
            timeToNextCameraFrame = currentFrame->timestamp - prvCameraTimestamp;
        }
        auto timeToNext = (mDevicePoseCallback) ? std::min(timeToNextDevicePose, timeToNextCameraFrame) : timeToNextCameraFrame;

        auto processingTime = std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now() - processingStartTime).count();

        auto sleepTime = (timeToNext > uint64_t(processingTime)) ? timeToNext - processingTime : 0;
        if (playRealTime && sleepTime > 1000000) // avoid short sleeps
        {
            std::this_thread::sleep_for(std::chrono::nanoseconds(sleepTime));
        }

        if((!currentPose.has_value() && !currentFrame.has_value() && !holdPose) || mPlaybackPosition >= mEndPlaybackTimestamp)
        {
            std::unique_lock lock(mPlaybackMutex);
            numLoopsPlayed++;
            
            if (mLoopCount > 0 && numLoopsPlayed >= mLoopCount)
            {
                mPlaybackState = PlaybackState::PauseRequested;
                numLoopsPlayed = 0;
            }

            currentFrame.reset();
            currentPose.reset();
            holdPose = false;
            holdCamera = false;
            updateTimeOffset = true;
            
            if(!resetPlaybackToStart())
            {
                Platform::log("Failed to restart playback. Stopping player.");
                mPlaybackState = PlaybackState::StopRequested;
                break;
            }
        }
    }

    mPlaybackState = PlaybackState::Stopped;
}


std::optional<VuforiaDriver::CameraFrame>
MP4Player::readNextCameraFrame()
{
    assert(mCameraMetadataTrack.has_value());
    assert(mVideoTrack.has_value());
    
    if (mNumFramesRead >= mVideoTrack->mNumSamples)
    {
        return {};
    }
    
    auto metadataSampleInfo = mMP4Reader->readNextSample(mCameraMetadataTrack->mId, mSampleReadBuffer);
    if (!metadataSampleInfo.has_value())
    {
        Platform::log("Failed to read camera metadata sample.");
        return {};
    }
    
    auto frameMetadata = MP4SampleDeserializer::readFrameMetadata(mSampleReadBuffer);
    if (!frameMetadata.has_value())
    {
        Platform::log("Failed to parse camera metadata sample.");
        return {};
    }
    
    auto frameInfo = mMP4Reader->readNextFrame(mVideoTrack->mId, mFrameReadBuffer);
    if (!frameInfo.has_value())
    {
        Platform::log("Failed to read camera frame.");
        return {};
    }
    
    // During open() it was already checked that both tracks have the same number of
    // samples & the same duration. This is not a case that should happen.
    if (metadataSampleInfo->mPresentationTimestamp != frameInfo->mPresentationTimestamp)
    {
        Platform::log("WARNING: Timestamp mismatch between video and frame metadata.");
    }
    
    VuforiaDriver::CameraFrame frame{};
    frame.timestamp = static_cast<uint64_t>(frameMetadata->mTimestamp);
    frame.exposureTime = static_cast<uint64_t>(frameMetadata->mExposureTime);
    frame.width = mVideoTrack->mVideoWidth;
    frame.height = mVideoTrack->mVideoHeight;
    frame.index = mNumFramesRead++;
    frame.format = mMP4Reader->getVideoColorOutputFormat();
    frame.intrinsics = frameMetadata->mIntrinsics;
    frame.bufferSize = static_cast<uint32_t>(mFrameReadBuffer.size());
    frame.stride = frameInfo->mImageStride;
    frame.buffer = mFrameReadBuffer.data();
    return frame;
}


std::optional<VuforiaDriver::Pose>
MP4Player::readNextDevicePose()
{
    assert(mDevicePoseTrack.has_value());
    
    if (mNumDevicePosesRead >= mDevicePoseTrack->mNumSamples)
    {
        return {};
    }
    
    auto poseSampleInfo = mMP4Reader->readNextSample(mDevicePoseTrack->mId, mSampleReadBuffer);
    if (!poseSampleInfo.has_value())
    {
        Platform::log("Failed to read device pose sample.");
        return {};
    }
    
    auto devicePose = MP4SampleDeserializer::readDevicePose(mSampleReadBuffer);
    if (!devicePose.has_value())
    {
        Platform::log("Failed to parse device pose sample.");
        return {};
    }
    
    mNumDevicePosesRead++;
    return devicePose;
}
