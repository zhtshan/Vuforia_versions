/*===============================================================================
Copyright (c) 2020 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

#include "pch.h"
#include "AppSession.h"

#include "../Common/SampleUtil.h"

#include <Vuforia/Vuforia.h>
#include <Vuforia/UWP/Vuforia_UWP.h>
#include <Vuforia/CameraDevice.h>
#include <Vuforia/UWP/DXRenderer.h>
#include <Vuforia/Renderer.h>
#include <Vuforia/Tracker.h>
#include <Vuforia/VideoBackgroundConfig.h>
#include <Vuforia/TrackableResult.h>
#include <Vuforia/TrackerManager.h>
#include <Vuforia/State.h>
#include <Vuforia/ObjectTracker.h>
#include <Vuforia/PositionalDeviceTracker.h>
#include <Vuforia/SmartTerrain.h>
#include <Vuforia/RuntimeImageSource.h>

#include <locale>
#include <codecvt>
#include <string>

using namespace Platform;
using namespace Windows::Foundation;
using namespace Windows::Storage;
using namespace Windows::System::Threading;
using namespace Concurrency;
using namespace Vuforia;

using namespace VuforiaSamples;

namespace
{
    Platform::String^ LOGTAG = "AppSession";
}

AppSession::AppSession(AppControl^ appControl) :
    m_vuforiaInitialized(false),
    m_cameraRunning(false),
    m_deviceTracking(false),
    m_deviceTrackerInitialized(false),
    m_objectTracker(nullptr),
    m_deviceTracker(nullptr),
    m_smartTerrain(nullptr),
    m_appControl(appControl)
{
    LOGC(LOGTAG, "AppSession");

    allDataSets = std::make_unique<std::list<Vuforia::DataSet*>>();
}

AppSession::~AppSession()
{
    LOGC(LOGTAG, "~AppSession");
}

void AppSession::Vuforia_onUpdate(Vuforia::State& state)
{
    VuforiaState^ vuforiaState = ref new VuforiaState();
    vuforiaState->m_nativeState = &state;
    m_appControl->OnVuforiaUpdate(vuforiaState);
}

Concurrency::task<int> AppSession::InitVuforiaAsync()
{
    LOGC(LOGTAG, "InitVuforiaAsync");

    return Concurrency::create_task([]()
    {
        int progress = 0;
        while (progress >= 0 && progress < 100)
        {
            progress = Vuforia::init();
        }
        return progress;
    });
}

void AppSession::InitAR(uint8 trackerFlags)
{
    LOGC(LOGTAG, "InitAR");

    Vuforia::setInitParameters("");

    m_trackerInitFlags = trackerFlags;

    InitVuforiaAsync().then([this](int result)
    {
        if (result < 0)
        {
            ThrowVuforiaInitError(result);
        }

        if (!InitTrackers())
        {
            throw ref new Platform::Exception(E_FAIL, "Vuforia failed to initialize trackers.");
        }
    }
    ).then([this]()
    {
        if (!m_appControl->DoLoadTrackersData())
        {
            throw ref new Platform::Exception(E_FAIL, "Vuforia failed to load datasets.");
        }

        m_vuforiaInitialized = Vuforia::isInitialized();

        m_appControl->OnInitARDone();
    }
    ).then([this]()
    {
        // Wait a couple of seconds
        WaitForSingleObjectEx(GetCurrentThread(), 2000, FALSE);

        // Start the camera
        StartAR();

        // Register Vuforia UpdateCallback
        Vuforia::registerCallback(this);
    }
    ).then([this](task<void> t)
    {
        try
        {
            // If any exceptions were thrown back in the async chain then
            // this call throws that exception here and we can catch it below
            t.get();

            // If we are here, it means Vuforia has started successfully
            m_appControl->OnARStarted();
        }
        catch (Platform::Exception^ ex)
        {
            SampleCommon::SampleUtil::ShowError(L"Vuforia Initialization Error", ex->Message);
        }
    });
}

void AppSession::StartAR()
{
    LOGC(LOGTAG, "StartAR");

    if (CameraRunning())
    {
        // Camera already running
        return;
    }

    if (!InitCamera())
    {
        throw ref new Platform::Exception(E_FAIL, "Failed to init camera.");
    }

    // Before Starting Camera
    m_appControl->BeforeStartCamera();

    if (!StartCamera())
    {
        throw ref new Platform::Exception(E_FAIL, "Failed to start camera.");
    }

    // Start Trackers
    if (!m_appControl->DoStartTrackers())
    {
        throw ref new Platform::Exception(E_FAIL, "Failed to start trackers.");
    }
}

void AppSession::ConfigureDisplay(
    Windows::Foundation::Size outputSize,
    Windows::Graphics::Display::DisplayOrientations orientation)
{
    LOGC(LOGTAG, "ConfigureDisplay");

    Vuforia::setCurrentOrientation(
        Vuforia::toVuforiaDisplayOrientation(orientation));

    // inform Vuforia of the window size change
    Vuforia::onSurfaceChanged((int)outputSize.Width, (int)outputSize.Height);
}

void AppSession::ConfigureVideoBackground(
    Windows::Foundation::Size outputSize,
    Windows::Graphics::Display::DisplayOrientations orientation)
{
    LOGC(LOGTAG, "ConfigureVideoBackground");

    float screenWidth = outputSize.Width;
    float screenHeight = outputSize.Height;

    if (screenWidth <= 0 || screenHeight <= 0)
    {
        SampleCommon::SampleUtil::Log(LOGTAG, "Invalid screen size, skipping video background config.");
        return;
    }

    // Get the default video mode:
    Vuforia::CameraDevice& cameraDevice = Vuforia::CameraDevice::getInstance();
    Vuforia::VideoMode videoMode = cameraDevice.getVideoMode(Vuforia::CameraDevice::MODE_DEFAULT);

    if (videoMode.mWidth <= 0 || videoMode.mHeight <= 0)
    {
        SampleCommon::SampleUtil::Log(LOGTAG, "Video Mode not ready, skipping video background config.");
        return;
    }

    // Configure the video background
    Vuforia::VideoBackgroundConfig config;
    config.mPosition.data[0] = 0;
    config.mPosition.data[1] = 0;

    bool isPortrait =
        (orientation == Windows::Graphics::Display::DisplayOrientations::Portrait) ||
        (orientation == Windows::Graphics::Display::DisplayOrientations::PortraitFlipped);

    if (isPortrait)
    {
        config.mSize.data[0] = (int)(videoMode.mHeight * (screenHeight / (float)videoMode.mWidth));
        config.mSize.data[1] = (int)screenHeight;

        if (config.mSize.data[0] < screenWidth)
        {
            config.mSize.data[0] = (int)screenWidth;
            config.mSize.data[1] = (int)(screenWidth * (videoMode.mWidth / (float)videoMode.mHeight));
        }
    }
    else
    {
        config.mSize.data[0] = (int)screenWidth;
        config.mSize.data[1] = (int)(videoMode.mHeight * (screenWidth / (float)videoMode.mWidth));

        if (config.mSize.data[1] < screenHeight)
        {
            config.mSize.data[0] = (int)(screenHeight * (videoMode.mWidth / (float)videoMode.mHeight));
            config.mSize.data[1] = (int)screenHeight;
        }
    }

    Platform::String^ videoBgMsg = L"Configure Video Background: ";
    videoBgMsg += L" video: " + videoMode.mWidth + "," + videoMode.mHeight;
    videoBgMsg += L" screen: " + screenWidth + "," + screenHeight;
    videoBgMsg += L" size: " + config.mSize.data[0] + "," + config.mSize.data[1];

    SampleCommon::SampleUtil::Log(LOGTAG, videoBgMsg);

    // Set the config:
    Vuforia::Renderer::getInstance().setVideoBackgroundConfig(config);
}

void AppSession::StopAR()
{
    LOGC(LOGTAG, "StopAR");

    if (!VuforiaInitialized())
        return;

    Concurrency::create_task([this]()
    {
        m_appControl->BeforeStopCamera();
        StopCamera();
        m_appControl->DoStopTrackers();
        DeinitCamera();
    }
    ).then([this]()
    {
        // Lifecycle for app termination
        // 1. Deactivate DataSets
        // 2. Destroy DataSets
        // 3. Deinit Trackers
        // 4. Reset Vuforia Device Config
        // 5. Deinit Vuforia

        // Unregister the Vuforia callback
        Vuforia::registerCallback(nullptr);

        // Ensure that all asynchronous operations to initialize Vuforia
        // and loading the tracker datasets do not overlap:

        boolean unloadTrackersSuccess = false;
        unloadTrackersSuccess = DeactivateAllDataSets();
        unloadTrackersSuccess = DestroyAllDataSets();

        if (!unloadTrackersSuccess)
            throw ref new Platform::Exception(E_FAIL, "Failed to unload trackers data.");

        boolean deinitTrackersSuccess = DeinitTrackers();

        if (!deinitTrackersSuccess)
            throw ref new Platform::Exception(E_FAIL, "Failed to deinit the trackers.");

        m_appControl = nullptr;

        // Deinitialize Vuforia SDK:
        Vuforia::deinit();
        if (!Vuforia::isInitialized())
            LOG("AppSession : Vuforia Deinitialized");

        m_vuforiaInitialized = false;

        LOG("AppSession::StopAR() finished.");
    });
}

// ***** DISCRETE METHODS *****
/*
bool InitCamera();
void DeinitCamera();
bool StartCamera();
void StopCamera();
bool GetOrInitTracker(Vuforia::Type trackerType);
bool DeinitTracker(Vuforia::Type trackerType);
bool StartTracker(Vuforia::Type trackerType);
bool StopTracker(Vuforia::Type trackerType);
Vuforia::DataSet * CreateDataSet(const char * datasetPath);
bool ActivateDataSet(Vuforia::DataSet * dataset);
bool DeactivateAllDataSets();
bool DestroyAllDataSets();
*/

bool AppSession::InitCamera()
{
    LOGC(LOGTAG, "InitCamera");

    if (!CameraRunning())
    {
        if (Vuforia::CameraDevice::getInstance().init())
        {
            SampleCommon::SampleUtil::Log(LOGTAG, "Successfully initialized the camera.");
            m_cameraInitialized = true;
        }
        else
        {
            SampleCommon::SampleUtil::Log(LOGTAG, "Failed to initialize the camera.");
            return false;
        }

    }

    return true;
}

bool AppSession::StartCamera()
{
    LOGC(LOGTAG, "StartCamera");

    if (!CameraRunning())
    {
        if (!Vuforia::CameraDevice::getInstance().start())
        {
            SampleCommon::SampleUtil::Log(LOGTAG, "Failed to start the camera.");
            return false;
        }

        this->m_cameraRunning = true;
    }

    return true;
}

void AppSession::StopCamera()
{
    LOGC(LOGTAG, "StopCamera");

    if (CameraRunning())
    {
        if (!Vuforia::CameraDevice::getInstance().stop())
        {
            throw ref new Platform::Exception(E_FAIL, "Failed to stop the camera.");
        }

        this->m_cameraRunning = false;
    }

    LOG("AppSession::StopCamera() finished.");
}

void AppSession::DeinitCamera()
{
    LOGC(LOGTAG, "DeinitCamera");

    if (Vuforia::CameraDevice::getInstance().deinit())
    {
        SampleCommon::SampleUtil::Log(LOGTAG, "Successfully deinitialized the camera.");
        m_cameraInitialized = false;
    }
    else
    {
        throw ref new Platform::Exception(E_FAIL, "Failed to deinit the camera.");
    }
}

bool AppSession::InitTrackers()
{
    LOGC(LOGTAG, "InitTrackers");

    bool success = false;

    if (m_trackerInitFlags & OBJECT_TRACKER)
    {
        success = GetOrInitTracker(Vuforia::ObjectTracker::getClassType());
    }
    if (m_trackerInitFlags & DEVICE_TRACKER)
    {
        success = GetOrInitTracker(Vuforia::PositionalDeviceTracker::getClassType());
    }
    if (m_trackerInitFlags & SMART_TERRAIN)
    {
        success = GetOrInitTracker(Vuforia::SmartTerrain::getClassType());
    }
    return success;
}

bool AppSession::DeinitTrackers()
{
    LOGC(LOGTAG, "DeinitTrackers");

    bool success = false;

    if (m_trackerInitFlags & OBJECT_TRACKER)
    {
        success = DeinitTracker(Vuforia::ObjectTracker::getClassType());
    }
    if (m_trackerInitFlags & DEVICE_TRACKER)
    {
        success = DeinitTracker(Vuforia::PositionalDeviceTracker::getClassType());
    }
    if (m_trackerInitFlags & SMART_TERRAIN)
    {
        success = DeinitTracker(Vuforia::SmartTerrain::getClassType());
    }
    return success;
}

bool AppSession::GetOrInitTracker(Vuforia::Type trackerType)
{
    Vuforia::TrackerManager &trackerManager = Vuforia::TrackerManager::getInstance();

    if (trackerType.isOfType(Vuforia::ObjectTracker::getClassType()))
    {
        // Check if instance of tracker is already initialized
        m_objectTracker = static_cast<Vuforia::ObjectTracker*>
            (trackerManager.getTracker(Vuforia::ObjectTracker::getClassType()));

        // If instance hasn't been initialized yet (i.e. nullptr), initialize the tracker
        if (m_objectTracker == nullptr)
        {
            if (CameraInitialized())
            {
                SampleCommon::SampleUtil::Log(LOGTAG, "Can only initialize a tracker when the CameraDevice is uninitialized.");
                return false;
            }
            // Initialize the tracker
            m_objectTracker = static_cast<Vuforia::ObjectTracker*>
                (trackerManager.initTracker(Vuforia::ObjectTracker::getClassType()));

            // Check if the initialization was successful
            if (m_objectTracker == nullptr)
            {
                SampleCommon::SampleUtil::Log(LOGTAG, "Failed to get instance of ObjectTracker.");
                return false;
            }
        }
        m_objectTrackerInitialized = true;
        SampleCommon::SampleUtil::Log(LOGTAG, "Successfully acquired instance of ObjectTracker.");
        return true;
    }

    if (trackerType.isOfType(Vuforia::DeviceTracker::getClassType()))
    {
        // Check if instance of tracker is already initialized
        m_deviceTracker = static_cast<Vuforia::PositionalDeviceTracker*>
            (trackerManager.getTracker(Vuforia::PositionalDeviceTracker::getClassType()));

        // If instance hasn't been initialized yet (i.e. nullptr), initialize the tracker
        if (m_deviceTracker == nullptr)
        {
            if (CameraInitialized())
            {
                SampleCommon::SampleUtil::Log(LOGTAG, "Can only initialize a tracker when the CameraDevice is uninitialized.");
                return false;
            }
            // Initialize the tracker
            m_deviceTracker = static_cast<Vuforia::PositionalDeviceTracker*>
                (trackerManager.initTracker(Vuforia::PositionalDeviceTracker::getClassType()));

            // Check if the initialization was successful
            if (m_deviceTracker == nullptr)
            {
                SampleCommon::SampleUtil::Log(LOGTAG, "Failed to get instance of DeviceTracker.");
                return false;
            }
        }
        m_deviceTrackerInitialized = true;
        SampleCommon::SampleUtil::Log(LOGTAG, "Successfully acquired instance of DeviceTracker.");
        return true;
    }

    if (trackerType.isOfType(Vuforia::SmartTerrain::getClassType()))
    {
        // Check if instance of tracker is already initialized
        m_smartTerrain = static_cast<Vuforia::SmartTerrain*>
            (trackerManager.getTracker(Vuforia::SmartTerrain::getClassType()));

        // If instance hasn't been initialized yet (i.e. nullptr), initialize the tracker
        if (m_smartTerrain == nullptr)
        {
            if (CameraInitialized())
            {
                SampleCommon::SampleUtil::Log(LOGTAG, "Can only initialize a tracker when the CameraDevice is uninitialized.");
                return false;
            }
            // Initialize the tracker
            m_smartTerrain = static_cast<Vuforia::SmartTerrain*>
                (trackerManager.initTracker(Vuforia::SmartTerrain::getClassType()));

            // Check if the initialization was successful
            if (m_smartTerrain == nullptr)
            {
                SampleCommon::SampleUtil::Log(LOGTAG, "Failed to get instance of Smart Terrain.");
                return false;
            }
        }

        m_smartTerrainInitialized = true;
        SampleCommon::SampleUtil::Log(LOGTAG, "Successfully acquired instance of Smart Terrain.");
        return true;
    }

    SampleCommon::SampleUtil::Log(LOGTAG, "Unknown tracker requested.");
    return false;
}

/// <summary>
/// Deinit a Vuforia Tracker. Safe to use with initialized or unitialized trackers.
/// </summary>
bool AppSession::DeinitTracker(Vuforia::Type trackerType)
{
    LOGC(LOGTAG, "DeinitTracker");

    if ((trackerType.isOfType(Vuforia::ObjectTracker::getClassType()) && m_objectTrackerInitialized) ||
        (trackerType.isOfType(Vuforia::PositionalDeviceTracker::getClassType()) && m_deviceTrackerInitialized) ||
        (trackerType.isOfType(Vuforia::SmartTerrain::getClassType()) && m_smartTerrainInitialized))
    {
        Vuforia::TrackerManager &trackerManager = Vuforia::TrackerManager::getInstance();

        if (trackerManager.deinitTracker(trackerType))
        {
            SampleCommon::SampleUtil::Log(LOGTAG, "Successfully deinitialized the tracker: ");

            if (trackerType.isOfType(Vuforia::ObjectTracker::getClassType()))
            {
                LOG(typeid(Vuforia::ObjectTracker).name());
                m_objectTrackerInitialized = false;
            }
            else if (trackerType.isOfType(Vuforia::PositionalDeviceTracker::getClassType()))
            {
                LOG(typeid(Vuforia::PositionalDeviceTracker).name());
                m_deviceTrackerInitialized = false;
            }
            else if (trackerType.isOfType(Vuforia::SmartTerrain::getClassType()))
            {
                LOG(typeid(Vuforia::SmartTerrain).name());
                m_smartTerrainInitialized = false;
            }

            return true;
        }
        else
        {
            SampleCommon::SampleUtil::Log(LOGTAG, "Failed to deinit the requested tracker.");
            return false;
        }
    }
    else
    {
        // If selected tracker is not initialized, return silent success for deinitialization request.
        SampleCommon::SampleUtil::Log(LOGTAG, "The requested tracker is already in uninitialized state.");
        return true;
    }
}

bool AppSession::StartTracker(Vuforia::Type trackerType)
{
    LOGC(LOGTAG, "StartTracker");

    if (trackerType.isOfType(Vuforia::ObjectTracker::getClassType()))
    {
        if (GetOrInitTracker(trackerType) && m_objectTracker->start())
        {
            SampleCommon::SampleUtil::Log(LOGTAG, "Successfully started the Object Tracker.");
            return true;
        }
        else
        {
            SampleCommon::SampleUtil::Log(LOGTAG, "Could not start the Object Tracker.");
            return false;
        }
    }

    if (trackerType.isOfType(Vuforia::DeviceTracker::getClassType()))
    {
        if (GetOrInitTracker(trackerType) && m_deviceTracker->start())
        {
            SampleCommon::SampleUtil::Log(LOGTAG, "Successfully started the Device Tracker.");
            m_deviceTracking = true;
            return true;
        }
        else
        {
            SampleCommon::SampleUtil::Log(LOGTAG, "Could not start the Device Tracker.");
            return false;
        }
    }

    if (trackerType.isOfType(Vuforia::SmartTerrain::getClassType()))
    {
        if (GetOrInitTracker(trackerType) && m_smartTerrain->start())
        {
            SampleCommon::SampleUtil::Log(LOGTAG, "Successfully started the Smart Terrain tracker.");
            return true;
        }
        else
        {
            SampleCommon::SampleUtil::Log(LOGTAG, "Could not start the Smart Terrain tracker.");
            return false;
        }
    }

    SampleCommon::SampleUtil::Log(LOGTAG, "Unknown tracker requested.");
    return false;
}

bool AppSession::StopTracker(Vuforia::Type trackerType)
{
    LOGC(LOGTAG, "StopTracker");

    if (trackerType.isOfType(Vuforia::ObjectTracker::getClassType()))
    {
        if (GetOrInitTracker(trackerType))
        {
            m_objectTracker->stop();
            SampleCommon::SampleUtil::Log(LOGTAG, "Successfully stopped the Object Tracker.");
            return true;
        }
        else
        {
            SampleCommon::SampleUtil::Log(LOGTAG, "Cannot stop Object Tracker because tracker is null.");
            return false;
        }
    }

    if (trackerType.isOfType(Vuforia::DeviceTracker::getClassType()))
    {
        if (GetOrInitTracker(trackerType))
        {
            m_deviceTracker->stop();
            SampleCommon::SampleUtil::Log(LOGTAG, "Successfully stopped the Device Tracker.");
            return true;
        }
        else
        {
            SampleCommon::SampleUtil::Log(LOGTAG, "Cannot stop Device Tracker because tracker is null.");
            return false;
        }
    }

    if (trackerType.isOfType(Vuforia::SmartTerrain::getClassType()))
    {
        if (GetOrInitTracker(trackerType))
        {
            m_smartTerrain->stop();
            SampleCommon::SampleUtil::Log(LOGTAG, "Successfully stopped the Smart Terrain tracker.");
            return true;
        }
        else
        {
            SampleCommon::SampleUtil::Log(LOGTAG, "Cannot stop Smart Terrain Tracker because tracker is null.");
            return false;
        }
    }

    SampleCommon::SampleUtil::Log(LOGTAG, "Unknown tracker requested.");
    return false;
}

Vuforia::DataSet* AppSession::CreateDataSet(const char *datasetPath)
{
    LOGC(LOGTAG, "CreateDataSet");

    Vuforia::DataSet *dataset = m_objectTracker->createDataSet();
    if (dataset == nullptr)
    {
        SampleCommon::SampleUtil::Log(LOGTAG, "Failed to create the dataset.");
        return nullptr;
    }
    if (!dataset->load(datasetPath, Vuforia::STORAGE_TYPE::STORAGE_APPRESOURCE))
    {
        SampleCommon::SampleUtil::Log(LOGTAG, "Failed to load the dataset.");
        return nullptr;
    }
    allDataSets->push_back(dataset);
    return dataset;
}

/// <summary>
/// Creating a dataset with multiple image targets created from images loaded at run time using the native
/// C++ UWP BitmapDecoder class to access raw pixel data.
/// A second version loads from the image file via Vuforia instead.
/// The images map contains pairs of [target name, image file path]
/// The function returns a Vuforia::DataSet containing all the images from the map, or a nullptr if one of the 
/// Images couldn't be loaded
/// 
/// The steps to use the Instant Image Target api are highlighted with "Instant Image Target Step <X>" in comments
/// </summary>
Vuforia::DataSet* AppSession::CreateRuntimeImageTargetDataset(const std::map<std::string, std::string> & images)
{
    LOGC(LOGTAG, "CreateRuntimeImageTargetDataset");

    Vuforia::DataSet *dataset = m_objectTracker->createDataSet();
    if (dataset == nullptr)
    {
        SampleCommon::SampleUtil::Log(LOGTAG, "Failed to create the dataset.");
        return nullptr;
    }

    
    // Instant Image Target Step 1:
    // retrieve the RuntimeImageSource from the object tracker. The same instance can be used to
    // create multiple image targets
    Vuforia::RuntimeImageSource * runtimeImageSource = m_objectTracker->getRuntimeImageSource();
    if(runtimeImageSource == nullptr)
    {
        SampleCommon::SampleUtil::Log(LOGTAG, "Failed to retrieve the runtime image source.");
        return nullptr;
    }

    size_t apiSelector = 0;
    for(const auto & image : images)
    {
        if (apiSelector % 2 == 0)
        {
            // example code to load an image from disk using the Windows::Graphics::Imaging::BitmapDecoder
            // in order to access the raw image data.

            // the std::string needs to be converted to an UTF8 Platform::String
            std::wstring_convert<std::codecvt_utf8<wchar_t>> converter;
            std::wstring intermediateForm = converter.from_bytes(image.second);
            Platform::String^ platformImage = ref new Platform::String(intermediateForm.c_str());

            // Get the folder to load the image from. In this case the image is packaged with the UWP App
            StorageFolder^ localFolder = Windows::ApplicationModel::Package::Current->InstalledLocation;
            auto storagePath = localFolder->Path;

            Windows::Graphics::Imaging::BitmapPixelFormat pixelFormat;
            unsigned int width = 0;
            unsigned int height = 0;
            Platform::Array<unsigned char> ^ pixelData = nullptr;

            // Use the asynchronous file operations to load the images using concurrency::tasks by: 
            // * getting file stream from folder
            // * creating BitmapDecoder from file stream
            auto fileOperation = concurrency::create_task(localFolder->GetFileAsync(platformImage));
            auto pixelDataOperation = fileOperation.then([](StorageFile ^ file)
            {
                return concurrency::create_task(file->OpenAsync(Windows::Storage::FileAccessMode::Read));
            }).then([](Windows::Storage::Streams::IRandomAccessStream ^ fileStream)
            {
                return concurrency::create_task(Windows::Graphics::Imaging::BitmapDecoder::CreateAsync(fileStream));
            }).then([&pixelFormat, &width, &height](Windows::Graphics::Imaging::BitmapDecoder ^ bitmapDecoder)
            {
                // extract the image meta information, such as pixelformat, width and height.
                pixelFormat = bitmapDecoder->BitmapPixelFormat;
                width = bitmapDecoder->PixelWidth;
                height = bitmapDecoder->PixelHeight;

                // need to convert Bgra8 to Rgba8, since Vuforia does not support input from Bgra8 images
                if (pixelFormat == Windows::Graphics::Imaging::BitmapPixelFormat::Bgra8)
                {
                    pixelFormat = Windows::Graphics::Imaging::BitmapPixelFormat::Rgba8;
                    return concurrency::create_task(bitmapDecoder->GetPixelDataAsync(
                        Windows::Graphics::Imaging::BitmapPixelFormat::Rgba8,
                        Windows::Graphics::Imaging::BitmapAlphaMode::Premultiplied,
                        ref new Windows::Graphics::Imaging::BitmapTransform(),
                        Windows::Graphics::Imaging::ExifOrientationMode::RespectExifOrientation,
                        Windows::Graphics::Imaging::ColorManagementMode::DoNotColorManage));
                }
                else
                {
                    return concurrency::create_task(bitmapDecoder->GetPixelDataAsync());
                }

            });

            // get the raw pixel array (.get() is the blocking call to run the .then() task created above)
            pixelData = pixelDataOperation.get()->DetachPixelData();

            if (pixelData == nullptr)
            {
                LOGC(LOGTAG, "ERROR: unable to load image");
                m_objectTracker->destroyDataSet(dataset);
                dataset = nullptr;
            }

            // convert the Windows::Graphics::Imaging::BitmapPixelFormat to Vuforia::PIXEL_FORMAT
            Vuforia::PIXEL_FORMAT format;
            switch (pixelFormat)
            {
            case Windows::Graphics::Imaging::BitmapPixelFormat::Gray8:
                format = Vuforia::PIXEL_FORMAT::GRAYSCALE;
                break;
            case Windows::Graphics::Imaging::BitmapPixelFormat::Rgba8:
                format = Vuforia::PIXEL_FORMAT::RGBA8888;
                break;
            default:
                format = Vuforia::PIXEL_FORMAT::UNKNOWN_FORMAT;
                return nullptr;
                break;
            }

            // Instant Image Target Step 2:
            // Configure the RuntimeImageSource with the data from the loaded image.
            // Alternatively the RuntimeImageSource::setFile() call can be used to tell Vuforia to load the image data from the path.
            if (!runtimeImageSource->setImage(static_cast<void*>(&pixelData[0]), format, Vuforia::Vec2I(width, height), 0.247f, image.first.c_str()))
            {
                LOGC(LOGTAG, "ERROR: failed to load data set");
                m_objectTracker->destroyDataSet(dataset);
                dataset = nullptr;
            }
        }
        else
        {
            // Instant Image Target Step 2:
            // Configure the RuntimeImageSource with path to the file and the path type (see Vuforia::STORAGE_TYPE for options)
            if (!runtimeImageSource->setFile(image.second.c_str(), Vuforia::STORAGE_APPRESOURCE, 0.247f, image.first.c_str()))
            {
                LOGC(LOGTAG, "ERROR: failed to load data set");
                m_objectTracker->destroyDataSet(dataset);
                dataset = nullptr;
            }
        }
        
        // Instant Image Target Step 3:
        // Use the RuntimeImageSource instance to create the Trackable in the specified Vuforia::DataSet.
        dataset->createTrackable(runtimeImageSource);
        ++apiSelector;

    }

    allDataSets->push_back(dataset);
    return dataset;
}

bool AppSession::ActivateDataSet(Vuforia::DataSet *dataset)
{
    LOGC(LOGTAG, "ActivateDataSet");

    if (!m_objectTracker->activateDataSet(dataset))
    {
        SampleCommon::SampleUtil::Log(LOGTAG, "Failed to activate the dataset.");
        return false;
    }
    return true;
}

bool AppSession::DeactivateAllDataSets()
{
    LOGC(LOGTAG, "DeactivateAllDataSets");

    if (!GetOrInitTracker(Vuforia::ObjectTracker::getClassType()))
    {
        return false;
    }

    Vuforia::List<Vuforia::DataSet> activeDataSets = m_objectTracker->getActiveDataSets();

    // Deactivate all active datasets
    for (Vuforia::List<Vuforia::DataSet>::iterator it = activeDataSets.begin(); it != activeDataSets.end(); ++it)
    {
        if (m_objectTracker->deactivateDataSet(*it))
        {
            SampleCommon::SampleUtil::Log(LOGTAG, "Successfully deactivated the dataset.");
        }
        else
        {
            SampleCommon::SampleUtil::Log(LOGTAG, "Failed to deactivate the dataset.");
            return false;
        }
    }

    return true;
}

bool AppSession::DestroyAllDataSets()
{
    LOGC(LOGTAG, "DestroyAllDataSets");

    // Destroy all datasets
    for (std::list<Vuforia::DataSet*>::iterator it = allDataSets->begin(); it != allDataSets->end(); ++it)
    {
        Vuforia::DataSet* dataset = *it;

        if (m_objectTracker->destroyDataSet(dataset))
        {
            SampleCommon::SampleUtil::Log(LOGTAG, "Successfully destroyed the dataset.");
        }
        else
        {
            SampleCommon::SampleUtil::Log(LOGTAG, "Failed to destroy the dataset.");
            return false;
        }
    }
    allDataSets.reset();
    return true;
}

// ***** LIFECYCLE METHODS *****
/*
void ResumeAR();
void PauseAR();
*/

// Resumes Vuforia, restarts the trackers and the camera
void AppSession::ResumeAR()
{
    LOGC(LOGTAG, "ResumeAR");

    if (VuforiaInitialized())
    {
        // For an explanation of the following see the comment above
        // the declaration of m_resumeTask

        // Check for existing running resume task
        if (m_resumeTask == nullptr || m_resumeTask->Status != AsyncStatus::Started)
        {
            // To make sure we check the currently running pause task
            // (and not one created while we're running) we capture the
            // pointer here
            IAsyncAction^ localPauseTask = m_pauseTask;

            m_resumeTask = Concurrency::create_async([this, localPauseTask]()
            {
                if (localPauseTask != nullptr)
                {
                    while (localPauseTask->Status == AsyncStatus::Started)
                    {
                        Concurrency::wait(100);
                    }
                }

                // Only perform actions if we want to resume even after further events
                // Check that the same number or more pause events have been received
                if (m_ignoredResume >= m_ignoredPaused)
                {
                    Vuforia::onResume();
                    StartAR();

                    // Notify app control
                    m_appControl->OnARStarted();
                }
                else
                {
                    m_ignoredPaused--;
                }
            });
        }
        else
        {
            m_ignoredResume++;
        }
    }
}

// Pauses Vuforia and stops the camera
void AppSession::PauseAR()
{
    LOGC(LOGTAG, "PauseAR");

    if (VuforiaInitialized())
    {
        // For an explanation of the following see the comment above
        // the declaration of m_pauseTask

        // Check for existing running pause task
        if (m_pauseTask == nullptr || m_pauseTask->Status != AsyncStatus::Started)
        {
            // To make sure we check the currently running resume task
            // (and not one created while we're running) we capture the
            // pointer here
            IAsyncAction^ localResumeTask = m_resumeTask;

            // The camera must be stopped asynchronously
            m_pauseTask = Concurrency::create_async([this, localResumeTask]()
            {
                if (localResumeTask != nullptr)
                {
                    while (localResumeTask->Status == AsyncStatus::Started)
                    {
                        Concurrency::wait(100);
                    }
                }

                // Only perform actions if we want to pause even after further events
                // Check that the same number or more resume events have been received
                if (m_ignoredPaused >= m_ignoredResume)
                {
                    StopCamera();
                    Vuforia::onPause();
                }
                else
                {
                    m_ignoredResume--;
                }
            });
        }
        else
        {
            m_ignoredPaused++;
        }
    }
}

void AppSession::ThrowVuforiaInitError(int errorCode)
{
    if (errorCode >= 0)
        return; // not an error, do nothing

    switch (errorCode)
    {
    case Vuforia::INIT_ERROR:
        throw ref new Platform::Exception(E_FAIL,
            "Failed to initialize Vuforia.");
    case Vuforia::INIT_LICENSE_ERROR_INVALID_KEY:
        throw ref new Platform::Exception(E_FAIL,
            "Invalid Key used. " +
            "Please make sure you are using a valid Vuforia App Key");
    case Vuforia::INIT_LICENSE_ERROR_CANCELED_KEY:
        throw ref new Platform::Exception(E_FAIL,
            "This App license key has been cancelled " +
            "and may no longer be used. Please get a new license key.");
    case Vuforia::INIT_LICENSE_ERROR_MISSING_KEY:
        throw ref new Platform::Exception(E_FAIL,
            "Vuforia App key is missing. Please get a valid key, " +
            "by logging into your account at developer.vuforia.com " +
            "and creating a new project");
    case Vuforia::INIT_LICENSE_ERROR_PRODUCT_TYPE_MISMATCH:
        throw ref new Platform::Exception(E_FAIL,
            "Vuforia App key is not valid for this product. Please get a valid key, " +
            "by logging into your account at developer.vuforia.com and choosing the " +
            "right product type during project creation");
    case Vuforia::INIT_LICENSE_ERROR_NO_NETWORK_TRANSIENT:
        throw ref new Platform::Exception(E_FAIL,
            "Unable to contact server. Please try again later.");
    case Vuforia::INIT_LICENSE_ERROR_NO_NETWORK_PERMANENT:
        throw ref new Platform::Exception(E_FAIL,
            "No network available. Please make sure you are connected to the internet.");
    case Vuforia::INIT_DEVICE_NOT_SUPPORTED:
        throw ref new Platform::Exception(E_FAIL,
            "Failed to initialize Vuforia because this device is not supported.");
    case Vuforia::INIT_EXTERNAL_DEVICE_NOT_DETECTED:
        throw ref new Platform::Exception(E_FAIL,
            "Failed to initialize Vuforia because this " +
            "device is not docked with required external hardware.");
    case Vuforia::INIT_NO_CAMERA_ACCESS:
        throw ref new Platform::Exception(E_FAIL,
            "Camera Access was denied to this App. \n" +
            "When running on iOS8 devices, \n" +
            "users must explicitly allow the App to access the camera.\n" +
            "To restore camera access on your device, go to: \n" +
            "Settings > Privacy > Camera > [This App Name] and switch it ON.");
    default:
        throw ref new Platform::Exception(E_FAIL, "Vuforia init error. Unknown error.");
    }
}

// Sets the fusion provider type for DeviceTracker optimization
// This setting only affects the Tracker if the DeviceTracker is used.
// By default, the provider type is set to FUSION_OPTIMIZE_MODEL_TARGETS_AND_SMART_TERRAIN
bool AppSession::SetFusionProvider(Vuforia::FUSION_PROVIDER_TYPE providerType)
{
    LOGC(LOGTAG, "SetFusionProvider");

    int provider = Vuforia::getActiveFusionProvider();

    if ((provider& ~providerType) != 0)
    {
        if (Vuforia::setAllowedFusionProviders(providerType) ==
            Vuforia::FUSION_PROVIDER_TYPE::FUSION_PROVIDER_INVALID_OPERATION)
        {
            SampleCommon::SampleUtil::Log(LOGTAG, "Failed to set fusion provider type.");
            return false;
        }
    }

    SampleCommon::SampleUtil::Log(LOGTAG, "Successfully set fusion provider type.");

    return true;
}
