/*===============================================================================
Copyright (c) 2020 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

#pragma once

#include "AppControl.h"

#include <memory>
#include <wrl.h>
#include <ppltasks.h>

#include <Vuforia/CameraDevice.h>
#include <Vuforia/UpdateCallback.h>
#include <Vuforia/DataSet.h>
#include <Vuforia/ObjectTracker.h>
#include <Vuforia/PositionalDeviceTracker.h>
#include <Vuforia/SmartTerrain.h>

namespace VuforiaSamples
{
    const uint8 OBJECT_TRACKER = 1;
    const uint8 DEVICE_TRACKER = 2;
    const uint8 SMART_TERRAIN = 4;

    class AppSession : public Vuforia::UpdateCallback
    {
    public:
        AppSession(AppControl^ appControl);
        ~AppSession();

        // Vuforia
        void InitAR(uint8 trackerFlags);
        void StartAR();
        void StopAR();

        // Camera
        bool InitCamera();
        void DeinitCamera();
        bool StartCamera();
        void StopCamera();

        // Trackers
        bool InitTrackers();
        bool DeinitTrackers();
        bool GetOrInitTracker(Vuforia::Type trackerType);
        bool DeinitTracker(Vuforia::Type trackerType);
        bool StartTracker(Vuforia::Type trackerType);
        bool StopTracker(Vuforia::Type trackerType);

        // DataSets
        Vuforia::DataSet * CreateDataSet(const char * datasetPath);
        Vuforia::DataSet* CreateRuntimeImageTargetDataset(const std::map<std::string, std::string> & images);
        bool ActivateDataSet(Vuforia::DataSet * dataset);
        bool DeactivateAllDataSets();
        bool DestroyAllDataSets();

        // Lifecycle
        void PauseAR();
        void ResumeAR();

        bool SetFusionProvider(Vuforia::FUSION_PROVIDER_TYPE providerType);

        bool VuforiaInitialized() const { return m_vuforiaInitialized; }
        bool CameraInitialized() const { return m_cameraInitialized; }
        bool CameraRunning() const { return m_cameraRunning; }

        // Vuforia UpdateCallback interface
        virtual void Vuforia_onUpdate(Vuforia::State& state) override;

        void ConfigureDisplay(
            Windows::Foundation::Size outputSize,
            Windows::Graphics::Display::DisplayOrientations orientation
        );
        void ConfigureVideoBackground(
            Windows::Foundation::Size outputSize,
            Windows::Graphics::Display::DisplayOrientations orientation
        );


    private:

        AppControl^ m_appControl;

        uint8 m_trackerInitFlags = 0x0;

        Concurrency::task<int> InitVuforiaAsync();
        void ThrowVuforiaInitError(int errorCode);

        std::atomic<bool> m_vuforiaInitialized = false;
        std::atomic<bool> m_cameraInitialized = false;
        std::atomic<bool> m_cameraRunning = false;
        std::atomic<bool> m_objectTrackerInitialized = false;
        std::atomic<bool> m_deviceTrackerInitialized = false;
        std::atomic<bool> m_smartTerrainInitialized = false;
        std::atomic<bool> m_deviceTracking;

        Vuforia::ObjectTracker *m_objectTracker;
        Vuforia::PositionalDeviceTracker *m_deviceTracker;
        Vuforia::SmartTerrain *m_smartTerrain;

        std::unique_ptr<std::list<Vuforia::DataSet*>> allDataSets;

        /* For suspending and resuming we create an async task.
         * This is necessary because stopping and starting the camera takes
         * too long to run on the UI thread and the SDK doesn't allow this.
         * We need to ensure that these don't end up running concurrently and
         * that we always end up in the desired state even if the user
         * repeatedly suspend/resumes the app.
         */

         /// Handle to the suspend action
        Windows::Foundation::IAsyncAction^ m_pauseTask;
        /// Count the times we have ignored a suspend notification
        int m_ignoredPaused = 0;
        /// Handle to the resume action
        Windows::Foundation::IAsyncAction^ m_resumeTask;
        /// Count the times we have ignored the resume notification
        int m_ignoredResume = 0;
    };
};
