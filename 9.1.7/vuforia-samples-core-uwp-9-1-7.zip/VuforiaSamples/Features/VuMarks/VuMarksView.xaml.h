/*===============================================================================
Copyright (c) 2020 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/
#pragma once

#include "Features/VuMarks/VuMarksView.g.h"
#include "VuMarksMain.h"
#include "Common/DeviceResources.h"
#include "SampleApplication/AppSession.h"
#include "SampleApplication/AppControl.h"

#include <ppltasks.h>
#include <vector>

#include <Vuforia/DataSet.h>
#include <Vuforia/TrackableResult.h>

namespace VuMarks
{
    /// <summary>
    /// A page that hosts a DirectX SwapChainPanel.
    /// </summary>
    public ref class VuMarksView sealed : public VuforiaSamples::AppControl
    {
    public:
        VuMarksView();
        virtual ~VuMarksView();

        void SaveInternalState(Windows::Foundation::Collections::IPropertySet^ state);
        void LoadInternalState(Windows::Foundation::Collections::IPropertySet^ state);

        // ============================== //
        // AppControl interface methods

        // To be called before starting camera
        virtual void BeforeStartCamera();

        // To be called before stopping camera
        virtual void BeforeStopCamera();

        // To be called to start the trackers
        virtual bool DoStartTrackers();

        // To be called to stop the trackers
        virtual bool DoStopTrackers();

        // To be called to load the trackers' data
        virtual bool DoLoadTrackersData();

        // This callback is called after the Vuforia initialization is complete,
        // the trackers are initialized, their data loaded and
        // tracking is ready to start
        virtual void OnInitARDone();

        // This callback is called after the Vuforia Camera and Trackers have started
        virtual void OnARStarted();

        // This callback is called every cycle
        virtual void OnVuforiaUpdate(VuforiaSamples::VuforiaState^ vuforiaState);
        // ============================== //

    protected:

        void OnNavigatedFrom(Windows::UI::Xaml::Navigation::NavigationEventArgs^ e) override;
        void OnNavigatedTo(Windows::UI::Xaml::Navigation::NavigationEventArgs^ e) override;

    private:

        Platform::String^ LOGTAG = "VuMarksView";

        // Vuforia Sample App Session
        std::shared_ptr<VuforiaSamples::AppSession> m_appSession;
        std::unique_ptr<VuMarksMain> m_main;

        // Resources used to render the DirectX content in the XAML page background.
        std::shared_ptr<DX::DeviceResources> m_deviceResources;

        Windows::Foundation::EventRegistrationToken suspendingToken;
        Windows::Foundation::EventRegistrationToken resumingToken;
        Windows::Foundation::EventRegistrationToken visibilityChangedToken;

        Windows::Foundation::EventRegistrationToken token1;
        Windows::Foundation::EventRegistrationToken token2;
        Windows::Foundation::EventRegistrationToken token3;
        Windows::Foundation::EventRegistrationToken token4;
        Windows::Foundation::EventRegistrationToken token5;
        Windows::Foundation::EventRegistrationToken token6;
        Windows::Foundation::EventRegistrationToken token7;
        Windows::Foundation::EventRegistrationToken token8;

        void OnSuspending(Platform::Object^ sender, Windows::ApplicationModel::SuspendingEventArgs^ e);
        void OnResuming(Platform::Object^ sender, Platform::Object^ args);

        void OnPause();
        void OnResume();

        // Window event handlers.
        void OnVisibilityChanged(Windows::UI::Core::CoreWindow^ sender, Windows::UI::Core::VisibilityChangedEventArgs^ args);

        // DisplayInformation event handlers.
        void OnDpiChanged(Windows::Graphics::Display::DisplayInformation^ sender, Platform::Object^ args);
        void OnOrientationChanged(Windows::Graphics::Display::DisplayInformation^ sender, Platform::Object^ args);
        void OnDisplayContentsInvalidated(Windows::Graphics::Display::DisplayInformation^ sender, Platform::Object^ args);

        // Other event handlers.
        void OnCompositionScaleChanged(Windows::UI::Xaml::Controls::SwapChainPanel^ sender, Object^ args);
        void OnSwapChainPanelSizeChanged(Platform::Object^ sender, Windows::UI::Xaml::SizeChangedEventArgs^ e);

        // Track our independent input on a background worker thread.
        Windows::Foundation::IAsyncAction^ m_inputLoopWorker;
        Windows::UI::Core::CoreIndependentInputSource^ m_coreInput;
        Windows::UI::Input::GestureRecognizer^ m_gestureRecognizer;

        // Independent input handling functions.
        void OnPointerPressed(Platform::Object^ sender, Windows::UI::Core::PointerEventArgs^ e);
        void OnPointerMoved(Platform::Object^ sender, Windows::UI::Core::PointerEventArgs^ e);
        void OnPointerReleased(Platform::Object^ sender, Windows::UI::Core::PointerEventArgs^ e);
        void HandleSingleTap();
        void HandleDoubleTap();

        // Sample App Menu control
        void InitializeUI();
        void HideProgressIndicator();
        void ToggleMenu(bool enable);
        void EnableAutofocus();
        void Stop();

        void OnBackButtonClicked(Platform::Object ^ sender, Windows::UI::Xaml::RoutedEventArgs ^ e);
        void OnToggleDeviceTracking(Platform::Object^ sender, Windows::UI::Xaml::RoutedEventArgs^ e);
        void OnToggleAutofocus(Platform::Object^ sender, Windows::UI::Xaml::RoutedEventArgs^ e);
        void OnExitClick(Platform::Object^ sender, Windows::UI::Xaml::RoutedEventArgs^ e);
        void OnMenuAnimationDone(Platform::Object^ sender, Windows::UI::Xaml::RoutedEventArgs^ e);

        std::atomic<bool> m_windowVisible;
        std::atomic<bool> m_deviceTracking;
        std::atomic<bool> m_autofocusEnabled;
        std::atomic<bool> m_showingMenu;
        std::atomic<bool> m_showingProgress;

        // Timers for handling Relocalization
        Windows::UI::Xaml::DispatcherTimer^ m_dispatcherTimer;
        Windows::UI::Xaml::DispatcherTimer^ m_relocalizationDelayTimer;
        Windows::UI::Xaml::DispatcherTimer^ m_resetDeviceTrackerTimer;
        Windows::Foundation::EventRegistrationToken timerToken1;
        Windows::Foundation::EventRegistrationToken timerToken2;
        Windows::Foundation::EventRegistrationToken timerToken3;

        // Cached Status and StatusInfo in Enum format
        Vuforia::TrackableResult::STATUS m_enumStatus = Vuforia::TrackableResult::NO_POSE;
        Vuforia::TrackableResult::STATUS_INFO m_enumStatusInfo = Vuforia::TrackableResult::UNKNOWN;


        // Timer Init and Callbacks
        void InitializeTimers();
        void UpdateIntervalTimerTick(Platform::Object^ sender, Platform::Object^ e);
        void RelocalizationDelayTimerTick(Platform::Object^ sender, Platform::Object^ e);
        void ResetDeviceTrackerTimerTick(Platform::Object^ sender, Platform::Object^ e);

        // Logs Status and StatusInfo to Console and returns formatted String
        Platform::String^ LogAndReturnStatusString();

        void ShowTrackingStatus(bool show);

        Platform::String^ m_currentTrackingStatusString;

        // VuMarks
        void OnVuMarkCardAnimationDone(Platform::Object^ sender, Windows::UI::Xaml::RoutedEventArgs^ e);
        void OnVuMarkCardTapped(Platform::Object^ sender, Windows::UI::Xaml::RoutedEventArgs^ e);
        void UpdateVuMarkCard();

        // Vuforia Dataset
        Vuforia::DataSet *m_vuMarkDataSet;
        std::atomic<bool> m_showingVuMarkCard;

        Platform::String^ m_vuMarkId;
        Platform::String^ m_vuMarkType;
        int m_vuMarkImageWidth;
        int m_vuMarkImageHeight;
        byte* m_vuMarkImagePixels;
        Concurrency::reader_writer_lock m_vuMarkCardLock;

    public:

        void ShowVuMarkCard();
        void HideVuMarkCard();
        Platform::String^ GetCurrentVuMarkId()
        {
            Concurrency::reader_writer_lock::scoped_lock lock(m_vuMarkCardLock);
            return m_vuMarkId;
        }

    internal:
        void UpdateVuMarkInstance(
            Platform::String^ vuMarkId,
            Platform::String^ vuMarkType,
            int vuMarkImageWidth,
            int vuMarkImageHeight,
            byte* vuMarkImagePixels
        );
    };
}
