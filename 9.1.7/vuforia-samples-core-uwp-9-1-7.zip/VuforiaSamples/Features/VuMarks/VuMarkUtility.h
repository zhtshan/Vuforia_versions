/*===============================================================================
Copyright (c) 2020 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

#pragma once

#include <Vuforia\Vuforia.h>
#include <Vuforia\VuMarkTarget.h>
#include "..\..\Common\SampleAppMathUtils.h"

// VUMARK DATA HELPER METHODS

float DistanceSquared(const Vuforia::Vec2F & pos1, const Vuforia::Vec2F & pos2)
{
    return (float)(
        pow(pos1.data[0] - pos2.data[0], 2.0) +
        pow(pos1.data[1] - pos2.data[1], 2.0)
        );
}

void ConvertInstanceIdForBytes(const Vuforia::InstanceId& instanceId, char* dest)
{
    const size_t MAXLEN = 100;
    const char * src = instanceId.getBuffer();
    size_t len = instanceId.getLength();

    static const char* hexTable = "0123456789abcdef";

    if (len * 2 + 1 > MAXLEN) {
        len = (MAXLEN - 1) / 2;
    }

    // Go in reverse so the string is readable left-to-right.
    size_t bufIdx = 0;
    for (int i = (int)(len - 1); i >= 0; i--)
    {
        char upper = hexTable[(src[i] >> 4) & 0xf];
        char lower = hexTable[(src[i] & 0xf)];
        dest[bufIdx++] = upper;
        dest[bufIdx++] = lower;
    }

    // null terminate the string.
    dest[bufIdx] = 0;
}

void ConvertInstanceIdToString(const Vuforia::InstanceId& instanceId, char dest[])
{
    switch (instanceId.getDataType())
    {
    case Vuforia::InstanceId::BYTES:
        ConvertInstanceIdForBytes(instanceId, dest);
        break;

    case Vuforia::InstanceId::STRING:
        strcpy_s(dest, instanceId.getLength() + 1, instanceId.getBuffer());
        break;

    case Vuforia::InstanceId::NUMERIC:
        sprintf_s(dest, instanceId.getLength(), "%I64u", instanceId.getNumericValue());
        break;

    default:
        sprintf_s(dest, sizeof("Unknown"), "Unknown");
    }
}

void GetInstanceType(const Vuforia::InstanceId& instanceId, char dest[])
{
    switch (instanceId.getDataType())
    {
    case Vuforia::InstanceId::BYTES:
        sprintf_s(dest, sizeof("Bytes"), "Bytes");
        break;

    case Vuforia::InstanceId::STRING:
        sprintf_s(dest, sizeof("String"), "String");
        break;

    case Vuforia::InstanceId::NUMERIC:
        sprintf_s(dest, sizeof("Numeric"), "Numeric");
        break;

    default:
        sprintf_s(dest, sizeof("Unknown"), "Unknown");
    }
}
