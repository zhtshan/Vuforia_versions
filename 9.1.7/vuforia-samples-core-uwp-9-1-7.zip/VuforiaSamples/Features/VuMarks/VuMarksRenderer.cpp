/*===============================================================================
Copyright (c) 2020 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

#include "pch.h"
#include "VuMarksRenderer.h"
#include "VuMarkUtility.h"
#include "Common/DirectXHelper.h"
#include "Common/SampleAppMathUtils.h"
#include "Common/SampleUtil.h"
#include "Common/RenderUtil.h"

#include <robuffer.h>

#include <Vuforia/Vuforia.h>
#include <Vuforia/UWP/Vuforia_UWP.h>
#include <Vuforia/CameraDevice.h>
#include <Vuforia/Device.h>
#include <Vuforia/DeviceTrackableResult.h>
#include <Vuforia/UWP/DXRenderer.h>
#include <Vuforia/Renderer.h>
#include <Vuforia/Tool.h>
#include <Vuforia/VideoBackgroundConfig.h>
#include <Vuforia/VideoBackgroundTextureInfo.h>
#include <Vuforia/TrackerManager.h>
#include <Vuforia/StateUpdater.h>
#include <Vuforia/Trackable.h>
#include <Vuforia/TrackableResult.h>
#include <Vuforia/VuMarkTarget.h>
#include <Vuforia/VuMarkTargetResult.h>

#include "VuMarksView.xaml.h"

using namespace VuMarks;
using namespace DirectX;
using namespace Windows::Foundation;
using namespace Microsoft::WRL;
using namespace Windows::Storage::Streams;
using namespace Windows::UI::Xaml::Media::Imaging;

namespace
{
    Platform::String^ LOGTAG = "VuMarksRenderer";

    const float VUMARK_SCALE = 1.06f;
    const uint8 VUMARK_ID_MAX_LENGTH = 100;

    const std::wstring RES_PATH_SHADER_TEXTURED_VS = L"TexturedVertexShader.cso";
    const std::wstring RES_PATH_SHADER_TEXTURED_PS = L"TexturedPixelShader.cso";
    const std::wstring RES_PATH_SHADER_VIDEO_BKGD_VS = L"VideoBackgroundVertexShader.cso";
    const std::wstring RES_PATH_SHADER_VIDEO_BKGD_PS = L"VideoBackgroundPixelShader.cso";

    wchar_t RES_PATH_TEXTURE_VUMARK_OUTLINE[] = L"Assets/VuMarks/VuMarkOutline.png";
    wchar_t RES_PATH_TEXTURE_RETICLE[] = L"Assets/VuMarks/reticle.png";
}

// Loads vertex and pixel shaders from files, create the teapot mesh and load the textures.
VuMarksRenderer::VuMarksRenderer(const std::shared_ptr<DX::DeviceResources>& deviceResources) :
    m_deviceResources(deviceResources),
    m_rendererInitialized(false),
    m_vuforiaInitialized(false),
    m_vuforiaStarted(false),
    m_deviceTrackerEnabled(false),
    m_currentTime(0),
    m_uiDispatcher(nullptr)
{
    LOGC(LOGTAG, "VuMarksRenderer");

    CreateDeviceDependentResources();
    CreateWindowSizeDependentResources();
}

void VuMarksRenderer::SetVuMarkView(VuMarksView^ view)
{
    m_vumarkView = view;
}

void VuMarksRenderer::SetVuforiaStarted(bool started)
{
    LOGC(LOGTAG, "SetVuforiaStarted");

    m_vuforiaStarted = started;
    if (started) {
        UpdateRenderingPrimitives();
    }
    else
    {
        m_videoBackground->SetVideoBackgroundTexture();
    }
}

// Initializes view parameters when the window size changes.
void VuMarksRenderer::CreateWindowSizeDependentResources()
{
    LOGC(LOGTAG, "CreateWindowSizeDependentResources");

    if (m_vuforiaStarted)
    {
        UpdateRenderingPrimitives();
    }
    else
    {
        LOG("Failed to update rendering primitives. Vuforia not yet started.");
    }
}

void VuMarksRenderer::UpdateRenderingPrimitives()
{
    LOGC(LOGTAG, "UpdateRenderingPrimitives");

    Concurrency::critical_section::scoped_lock lock(m_renderingPrimitivesLock);
    if (m_renderingPrimitives != nullptr)
    {
        m_renderingPrimitives.reset();
    }
    m_renderingPrimitives = std::shared_ptr<Vuforia::RenderingPrimitives>(
        new Vuforia::RenderingPrimitives(Vuforia::Device::getInstance().getRenderingPrimitives())
        );

    m_videoBackground->ResetForNewRenderingPrimitives();
}

// Called once per frame
void VuMarksRenderer::Update(SampleCommon::StepTimer const& timer)
{
    m_currentTime = timer.GetTotalSeconds();
}

// Renders one frame using the vertex and pixel shaders.
void VuMarksRenderer::Render()
{
    // Vuforia initialization and data loading is asynchronous.
    // Only starts rendering after Vuforia init/loading is complete.
    if (!m_rendererInitialized || !m_vuforiaStarted)
    {
        return;
    }

    // Get the state from Vuforia and mark the beginning of a rendering section
    Vuforia::DXRenderData dxRenderData(m_deviceResources->GetD3DDevice());
    const Vuforia::State state = Vuforia::TrackerManager::getInstance().getStateUpdater().updateState();

    Vuforia::Renderer &vuforiaRenderer = Vuforia::Renderer::getInstance();
    vuforiaRenderer.begin(state, &dxRenderData);

    RenderScene(vuforiaRenderer, state);

    vuforiaRenderer.end();
}

void VuMarksRenderer::RenderReticle()
{
    auto context = m_deviceResources->GetD3DDeviceContext();

    if (!m_reticleTexture->IsInitialized()) {
        m_reticleTexture->Init();
    }

    Size outputSize = m_deviceResources->GetOutputSize();
    Windows::Graphics::Display::DisplayOrientations orientation = m_deviceResources->GetCurrentOrientation();

    bool isPortrait =
        (orientation == Windows::Graphics::Display::DisplayOrientations::Portrait) ||
        (orientation == Windows::Graphics::Display::DisplayOrientations::PortraitFlipped);

    float aspectRatio;
    if (isPortrait)
    {
        aspectRatio = outputSize.Height / outputSize.Width;
    }
    else
    {
        aspectRatio = outputSize.Width / outputSize.Height;
    }

    float fovAngleY = 45.0f * XM_PI / 180.0f;

    // This sample makes use of a right-handed coordinate system using row-major matrices.
    XMMATRIX perspectiveMatrix = XMMatrixPerspectiveFovRH(
        fovAngleY,
        aspectRatio,
        m_near,
        m_far
    );

    XMFLOAT4X4 orientationTransform = m_deviceResources->GetOrientationTransform3D();
    XMMATRIX orientationMatrix = XMLoadFloat4x4(&orientationTransform);

    XMStoreFloat4x4(
        &m_constantBufferData.projection,
        XMMatrixTranspose(perspectiveMatrix * orientationMatrix)
    );

    // We place the reticle at the near clipping plane
    float reticleDistance = 1.1f * m_near;
    static const XMVECTORF32 eye = { 0.0f, 0.0f, reticleDistance, 0.0f };
    static const XMVECTORF32 at = { 0.0f, 0.0f, 0.0f, 0.0f };
    static const XMVECTORF32 up = { 0.0f, 1.0f, 0.0f, 0.0f };

    XMStoreFloat4x4(&m_constantBufferData.view, XMMatrixTranspose(XMMatrixLookAtRH(eye, at, up)));

    float reticleScale = reticleDistance * tan(fovAngleY / 2);
    auto reticleScaleMatrix = XMMatrixScaling(reticleScale, reticleScale, reticleScale);
    XMStoreFloat4x4(&m_constantBufferData.model, XMMatrixTranspose(reticleScaleMatrix));

    // Set the color mask
    //m_constantBufferData.colorMask = { 1.0F, 1.0F, 1.0F, 1.0F };

    // Prepare the constant buffer to send it to the graphics device.
    context->UpdateSubresource1(
        m_constantBuffer.Get(),
        0,
        NULL,
        &m_constantBufferData,
        0,
        0,
        0
    );

    // Each vertex is one instance of the TexturedVertex struct.
    UINT stride = sizeof(SampleCommon::TexturedVertex);
    UINT offset = 0;
    context->IASetVertexBuffers(
        0,
        1,
        m_quadMesh->GetVertexBuffer().GetAddressOf(),
        &stride,
        &offset
    );

    context->IASetIndexBuffer(
        m_quadMesh->GetIndexBuffer().Get(),
        DXGI_FORMAT_R16_UINT, // Each index is a 16-bit unsigned integer (short).
        0
    );

    context->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

    context->IASetInputLayout(m_inputLayout.Get());

    // Attach our vertex shader.
    context->VSSetShader(m_vertexShader.Get(), nullptr, 0);

    // Send the constant buffer to the graphics device.
    context->VSSetConstantBuffers1(
        0,
        1,
        m_constantBuffer.GetAddressOf(),
        nullptr,
        nullptr
    );

    // Attach our pixel shader.
    context->PSSetShader(m_pixelShader.Get(), nullptr, 0);

    context->PSSetSamplers(0, 1, m_reticleTexture->GetD3DSamplerState().GetAddressOf());
    context->PSSetShaderResources(0, 1, m_reticleTexture->GetD3DTextureView().GetAddressOf());

    // Draw the objects.
    context->DrawIndexed(m_quadMesh->GetIndexCount(), 0, 0);
}

void VuMarksRenderer::RenderScene(Vuforia::Renderer &renderer, const Vuforia::State &state)
{
    Concurrency::critical_section::scoped_lock lock(m_renderingPrimitivesLock);

    auto context = m_deviceResources->GetD3DDeviceContext();

    // Calculate the DX Projection matrix using the current Vuforia state
    auto projectionMatrix = Vuforia::Tool::convertPerspectiveProjection2GLMatrix(
        m_renderingPrimitives->getProjectionMatrix(Vuforia::VIEW_SINGULAR, state.getCameraCalibration()),
        m_near, m_far);

    XMFLOAT4X4 dxProjection;
    memcpy(dxProjection.m, projectionMatrix.data, sizeof(float) * 16);
    XMStoreFloat4x4(&dxProjection, XMMatrixTranspose(XMLoadFloat4x4(&dxProjection)));

    XMMATRIX xmProjectionMatrix = XMLoadFloat4x4(&dxProjection);

    bool gotVuMark = false;
            
    // Render the camera video background
    m_videoBackground->Render(renderer, m_renderingPrimitives.get(), Vuforia::VIEW_SINGULAR, state);
    
    // Set state for augmentation rendering
    context->RSSetState(m_augmentationRasterStateCullBack.Get()); //Back camera

    context->OMSetDepthStencilState(m_augmentationDepthStencilState.Get(), 1);
    context->OMSetBlendState(m_augmentationBlendState.Get(), NULL, 0xffffffff);

    DirectX::XMFLOAT4X4 devicePoseMatrixDX;
    XMStoreFloat4x4(&devicePoseMatrixDX, XMMatrixIdentity());
    Vuforia::Matrix44F devicePoseMatrix = SampleAppMathUtils::Matrix44FIdentity();
    
    // Get the device pose
    if (state.getDeviceTrackableResult() != nullptr && state.getDeviceTrackableResult()->getStatus() != Vuforia::TrackableResult::NO_POSE)
    {
        Vuforia::Matrix44F modelMatrix = Vuforia::Tool::convertPose2GLMatrix(state.getDeviceTrackableResult()->getPose());
        devicePoseMatrix = SampleAppMathUtils::Matrix44FTranspose(SampleAppMathUtils::Matrix44FInverse(modelMatrix));

        SampleAppMathUtils::convertPoseFromGLtoDX(devicePoseMatrix, devicePoseMatrixDX);
    }

    int indexVuMarkToDisplay = -1;

    const auto& trackableResultList = state.getTrackableResults();
    const auto numTrackableResults = trackableResultList.size();
            
    if (numTrackableResults > 1)
    {
        float minimumDistance = FLT_MAX;
        const Vuforia::CameraCalibration* camCalib = state.getCameraCalibration();
        const Vuforia::Vec2F camSize = camCalib->getSize();
        const Vuforia::Vec2F camCenter = Vuforia::Vec2F(camSize.data[0] / 2.0f, camSize.data[1] / 2.0f);

        for (int tIdx = 0; tIdx < numTrackableResults; ++tIdx)
        {
            const Vuforia::TrackableResult* result = trackableResultList.at(tIdx);
            if (result->isOfType(Vuforia::VuMarkTargetResult::getClassType()))
            {
                Vuforia::Vec3F point = Vuforia::Vec3F(0.0, 0.0, 0.0);
                Vuforia::Vec2F projPoint = Vuforia::Tool::projectPoint(
                    *camCalib, result->getPose(), point);
                    
                float distance = DistanceSquared(projPoint, camCenter);
                if (distance < minimumDistance) 
                {
                    minimumDistance = distance;
                    indexVuMarkToDisplay = tIdx;
                }
            }
        }
    }

    std::string currVuMarkId;
    SampleCommon::SampleUtil::ToStdString(m_vumarkView->GetCurrentVuMarkId(), currVuMarkId);

    for (int tIdx = 0; tIdx < numTrackableResults; ++tIdx)
    {
        // Get the trackable:
        const Vuforia::TrackableResult* result = trackableResultList.at(tIdx);
        const Vuforia::Trackable &trackable = result->getTrackable();
        const char* trackableName = trackable.getName();

        if (result->isOfType(Vuforia::VuMarkTargetResult::getClassType()) && result->getStatus() != Vuforia::TrackableResult::STATUS::LIMITED)
        {
            gotVuMark = true;

            const Vuforia::VuMarkTargetResult* vmResult = (const Vuforia::VuMarkTargetResult*)result;
            const Vuforia::VuMarkTarget &vmTarget = vmResult->getTrackable();

            // This boolean teels if the current VuMark is the 'main' one,
            // i.e either the closest one to the camera center or the only one
            bool isMainVumark = (indexVuMarkToDisplay < 0) || (indexVuMarkToDisplay == tIdx);

            const Vuforia::VuMarkTemplate& vmTemplate = vmTarget.getTemplate();
            const Vuforia::InstanceId & vmId = vmTarget.getInstanceId();
            const Vuforia::Image & vmImage = vmTarget.getInstanceImage();

            if (isMainVumark)
            {
                char vmId_cstr[VUMARK_ID_MAX_LENGTH + 1];
                ConvertInstanceIdToString(vmId, vmId_cstr);

                char vmType_cstr[16];
                GetInstanceType(vmId, vmType_cstr);

                // If the VuMark has changed, we reset the animation
                if (strcmp(vmId_cstr, currVuMarkId.c_str()) != 0)
                {
                    BlinkVumark(true);
                }

                Platform::String^ vumarkIdStr = SampleCommon::SampleUtil::ToPlatformString(vmId_cstr);
                Platform::String^ vumarkTypeStr = SampleCommon::SampleUtil::ToPlatformString(vmType_cstr);

                // build Bitmap from Vuforia::Image and pass it here
                int vumarkImageWidth = vmImage.getWidth();
                int vumarkImageHeight = vmImage.getHeight();

                m_vumarkView->UpdateVuMarkInstance(
                    vumarkIdStr,
                    vumarkTypeStr,
                    vumarkImageWidth,
                    vumarkImageHeight,
                    (byte*)vmImage.getPixels()
                );
            }

            // Set up the modelview matrix
            auto poseGL = Vuforia::Tool::convertPose2GLMatrix(result->getPose());
            XMFLOAT4X4 poseDX;
            memcpy(poseDX.m, poseGL.data, sizeof(float) * 16);
            XMStoreFloat4x4(&poseDX, XMMatrixTranspose(XMLoadFloat4x4(&poseDX)));
            XMMATRIX xmPose = XMLoadFloat4x4(&poseDX);

            float opacity = isMainVumark ? BlinkVumark(false) : 1.0f;
            float vmOrigX = -vmTemplate.getOrigin().data[0];
            float vmOrigY = -vmTemplate.getOrigin().data[1];
            float vmWidth = vmTarget.getSize().data[0];
            float vmHeight = vmTarget.getSize().data[1];
            if (!m_augmentationTexture->IsInitialized()) {
                m_augmentationTexture->Init();
            }

            // Combine the device pose (view matrix) with the model matrix
            xmPose = DirectX::XMMatrixMultiply(XMLoadFloat4x4(&devicePoseMatrixDX), XMLoadFloat4x4(&poseDX));

            RenderVuMark(vmOrigX, vmOrigY, vmWidth, vmHeight, xmPose, xmProjectionMatrix, m_augmentationTexture, opacity);
        }
    }

    if (gotVuMark)
    {
        Windows::ApplicationModel::Core::CoreApplication::MainView->CoreWindow->Dispatcher->RunAsync(
            Windows::UI::Core::CoreDispatcherPriority::Normal,
            ref new Windows::UI::Core::DispatchedHandler([this]()
        {
            m_vumarkView->ShowVuMarkCard();
        }));
    }
    else
    {
        // We reset the state of the animation so that
        // it triggers next time a vumark is detected
        BlinkVumark(true);
        // We also reset the value of the current value of the vumark on card
        // so that we hide and show the vumark if we redetect the same vumark

        m_vumarkView->UpdateVuMarkInstance(nullptr, nullptr, 0, 0, nullptr);
    }
}

void VuMarks::VuMarksRenderer::ProcessTrackableResults(const Vuforia::State & state, DirectX::XMFLOAT4X4 &devicePoseMatrixDX, DirectX::XMMATRIX &xmProjection)
{

}

void VuMarksRenderer::RenderVuMark(
    float vumarkOriginX,
    float vumarkOriginY,
    float vumarkWidth,
    float vumarkHeight,
    const DirectX::XMMATRIX &poseMatrix,
    const DirectX::XMMATRIX &projectionMatrix,
    const std::shared_ptr<SampleCommon::Texture> texture,
    float opacity
)
{
    auto context = m_deviceResources->GetD3DDeviceContext();

    ZeroMemory(&m_constantBufferData, sizeof(SampleCommon::ModelViewProjectionConstantBuffer));

    // Set the model matrix (the 'model' part of the 'model-view' matrix)
    auto translate = XMMatrixTranslation(-vumarkOriginX, -vumarkOriginY, 0.0f);
    auto scale = XMMatrixScaling(vumarkWidth*VUMARK_SCALE, vumarkHeight*VUMARK_SCALE, 1.0f);
    auto modelMatrix = XMMatrixTranspose(translate) * XMMatrixTranspose(scale);
    XMStoreFloat4x4(&m_constantBufferData.model, modelMatrix);

    // Set the pose matrix (the 'view' part of the 'model-view' matrix)
    XMStoreFloat4x4(&m_constantBufferData.view, poseMatrix);

    // Set the projection matrix
    XMStoreFloat4x4(&m_constantBufferData.projection, projectionMatrix);

    // Set the color mask
    //m_constantBufferData.colorMask = { 1.0F, 1.0F, 1.0F, opacity };

    // Prepare the constant buffer to send it to the graphics device.
    context->UpdateSubresource1(
        m_constantBuffer.Get(),
        0,
        NULL,
        &m_constantBufferData,
        0,
        0,
        0
    );

    // Each vertex is one instance of the TexturedVertex struct.
    UINT stride = sizeof(SampleCommon::TexturedVertex);
    UINT offset = 0;
    context->IASetVertexBuffers(
        0,
        1,
        m_quadMesh->GetVertexBuffer().GetAddressOf(),
        &stride,
        &offset
    );

    context->IASetIndexBuffer(
        m_quadMesh->GetIndexBuffer().Get(),
        DXGI_FORMAT_R16_UINT, // Each index is one 16-bit unsigned integer (short).
        0
    );

    context->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

    context->IASetInputLayout(m_inputLayout.Get());

    // Attach our vertex shader.
    context->VSSetShader(m_vertexShader.Get(), nullptr, 0);

    // Send the constant buffer to the graphics device.
    context->VSSetConstantBuffers1(
        0,
        1,
        m_constantBuffer.GetAddressOf(),
        nullptr,
        nullptr
    );

    // Attach our pixel shader.
    context->PSSetShader(m_pixelShader.Get(), nullptr, 0);

    context->PSSetSamplers(0, 1, texture->GetD3DSamplerState().GetAddressOf());
    context->PSSetShaderResources(0, 1, texture->GetD3DTextureView().GetAddressOf());

    // Draw the objects.
    context->DrawIndexed(m_quadMesh->GetIndexCount(), 0, 0);
}




float VuMarksRenderer::BlinkVumark(bool reset)
{
    static double t0 = -1;
    if (reset || t0 < 0) {
        t0 = m_currentTime;
    }
    if (reset) {
        return 0.0f;
    }

    double delta = (m_currentTime - t0);
    if (delta > 1.0) {
        return 1.0;
    }
    if ((delta < 0.3) || (delta > 0.5 && delta < 0.8)) {
        return 1.0;
    }
    return 0.0;
}

void VuMarksRenderer::CreateDeviceDependentResources()
{
    LOGC(LOGTAG, "CreateDeviceDependentResources");

    m_rendererInitialized = false;

    m_videoBackground = std::make_shared<SampleCommon::VideoBackground>(m_deviceResources);

    // Load shaders asynchronously.
    auto loadVSTask = DX::ReadDataAsync(RES_PATH_SHADER_TEXTURED_VS);
    auto loadPSTask = DX::ReadDataAsync(RES_PATH_SHADER_TEXTURED_PS);
    auto loadVideoBgVSTask = DX::ReadDataAsync(RES_PATH_SHADER_VIDEO_BKGD_VS);
    auto loadVideoBgPSTask = DX::ReadDataAsync(RES_PATH_SHADER_VIDEO_BKGD_PS);

    // After the vertex shader file is loaded, create the shader and input layout.
    auto createVSTask = loadVSTask.then([this](const std::vector<byte>& fileData)
    {
        DX::ThrowIfFailed(
            m_deviceResources->GetD3DDevice()->CreateVertexShader(
                &fileData[0],
                fileData.size(),
                nullptr,
                &m_vertexShader
            )
        );

        static const D3D11_INPUT_ELEMENT_DESC vertexDesc[] =
        {
            { "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 0, D3D11_INPUT_PER_VERTEX_DATA, 0 },
            { "TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT, 0, 12, D3D11_INPUT_PER_VERTEX_DATA, 0 },
        };

        DX::ThrowIfFailed(
            m_deviceResources->GetD3DDevice()->CreateInputLayout(
                vertexDesc,
                ARRAYSIZE(vertexDesc),
                &fileData[0],
                fileData.size(),
                &m_inputLayout
            )
        );
    });

    auto createVideoBgVSTask = loadVideoBgVSTask.then([this](const std::vector<byte>& fileData)
    {
        m_videoBackground->InitVertexShader(&fileData[0], fileData.size());
    });

    // After the pixel shader file is loaded, create the shader and constant buffer.
    auto createPSTask = loadPSTask.then([this](const std::vector<byte>& fileData) {
        DX::ThrowIfFailed(
            m_deviceResources->GetD3DDevice()->CreatePixelShader(
                &fileData[0],
                fileData.size(),
                nullptr,
                &m_pixelShader
            )
        );

        CD3D11_BUFFER_DESC constantBufferDesc(sizeof(SampleCommon::ModelViewProjectionConstantBuffer), D3D11_BIND_CONSTANT_BUFFER);
        DX::ThrowIfFailed(
            m_deviceResources->GetD3DDevice()->CreateBuffer(
                &constantBufferDesc,
                nullptr,
                &m_constantBuffer
            )
        );
    });

    // After the pixel shader file is loaded, create the shader and constant buffer.
    auto createVideoBgPSTask = loadVideoBgPSTask.then([this](const std::vector<byte>& fileData)
    {
        m_videoBackground->InitFragmentShader(&fileData[0], fileData.size());
    });

    // Once both shaders are loaded, create the mesh.
    auto createAugmentationModelsTask = (createPSTask && createVSTask).then([this]()
    {
        m_quadMesh = std::make_shared<SampleCommon::QuadMesh>(m_deviceResources);
        m_quadMesh->InitMesh();
    });

    auto loadTextureTask = createAugmentationModelsTask.then([this]()
    {
        m_augmentationTexture = std::make_shared<SampleCommon::Texture>(m_deviceResources);
        m_reticleTexture = std::make_shared<SampleCommon::Texture>(m_deviceResources);

        m_augmentationTexture->CreateFromFile(RES_PATH_TEXTURE_VUMARK_OUTLINE);
        m_reticleTexture->CreateFromFile(RES_PATH_TEXTURE_RETICLE);
    });

    auto setupRasterizersTask = loadTextureTask.then([this]() {
        // setup the rasterizer
        auto context = m_deviceResources->GetD3DDeviceContext();

        ID3D11Device *device;
        context->GetDevice(&device);

        // Init rendering pipeline state for video background
        m_videoBackground->InitRenderState();

        // Create the rasterizer for video background rendering
        D3D11_RASTERIZER_DESC videoRasterDesc = SampleCommon::RenderUtil::CreateRasterizerDesc(
            D3D11_FILL_SOLID, // solid rendering
            D3D11_CULL_NONE, // no culling
            true, // CCW front face
            false //no depth clipping
        );
        device->CreateRasterizerState(&videoRasterDesc, m_videoRasterState.GetAddressOf());

        // Create the rasterizer for augmentation rendering,
        // with back-face culling
        D3D11_RASTERIZER_DESC augmentationRasterDesc = SampleCommon::RenderUtil::CreateRasterizerDesc(
            D3D11_FILL_SOLID, // solid rendering
            D3D11_CULL_BACK, // back face culling
            true, // CCW front face
            true // depth clipping enabled
        );
        device->CreateRasterizerState(&augmentationRasterDesc, m_augmentationRasterStateCullBack.GetAddressOf());

        // Create Depth-Stencil State with depth testing ON,
        // for augmentation rendering
        D3D11_DEPTH_STENCIL_DESC augDepthStencilDesc = SampleCommon::RenderUtil::CreateDepthStencilDesc(
            true,
            D3D11_DEPTH_WRITE_MASK_ZERO,// transparent
            D3D11_COMPARISON_LESS
        );
        device->CreateDepthStencilState(&augDepthStencilDesc, m_augmentationDepthStencilState.GetAddressOf());

        // Create blend state for video background (no transparency)
        D3D11_BLEND_DESC videoBlendDesc = SampleCommon::RenderUtil::CreateBlendDesc(false);
        device->CreateBlendState(&videoBlendDesc, m_videoBlendState.GetAddressOf());

        // Create augmentation blend state (with transparency)
        D3D11_BLEND_DESC augmentationBlendDesc = SampleCommon::RenderUtil::CreateBlendDesc(true);
        device->CreateBlendState(&augmentationBlendDesc, m_augmentationBlendState.GetAddressOf());

        // Set initial depth-stencil state and raster states
        context->RSSetState(m_videoRasterState.Get());
        context->OMSetDepthStencilState(m_videoDepthStencilState.Get(), 1);
        context->OMSetBlendState(m_videoBlendState.Get(), NULL, 0xffffffff);
    });

    setupRasterizersTask.then([this](Concurrency::task<void> t)
    {
        try
        {
            // If any exceptions were thrown back in the async chain then
            // this call throws that exception here and we can catch it below
            t.get();

            m_rendererInitialized = true;
        }
        catch (Platform::Exception ^ex)
        {
            SampleCommon::SampleUtil::ShowError(L"Renderer init error", ex->Message);
        }
    });
}

void VuMarksRenderer::ReleaseDeviceDependentResources()
{
    LOGC(LOGTAG, "ReleaseDeviceDependentResources");

    m_rendererInitialized = false;

    m_videoBackground->ReleaseResources();
    m_videoBackground.reset();

    m_vertexShader.Reset();
    m_inputLayout.Reset();
    m_pixelShader.Reset();
    m_constantBuffer.Reset();

    m_quadMesh->ReleaseResources();
    m_augmentationTexture->ReleaseResources();
    m_reticleTexture->ReleaseResources();

    m_renderingPrimitives.reset();
}
