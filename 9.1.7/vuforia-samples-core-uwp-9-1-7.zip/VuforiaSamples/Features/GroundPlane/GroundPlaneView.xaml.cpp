/*===============================================================================
Copyright (c) 2020 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/
#include "pch.h"

#include "GroundPlaneView.xaml.h"
#include "Common\SampleUtil.h"

#include <Vuforia\Vuforia.h>
#include <Vuforia\UWP\Vuforia_UWP.h>
#include <Vuforia\CameraDevice.h>
#include <Vuforia\State.h>
#include <Vuforia\TrackerManager.h>
#include <Vuforia\Tracker.h>
#include <Vuforia\ObjectTracker.h>
#include <Vuforia\PositionalDeviceTracker.h>
#include <Vuforia\SmartTerrain.h>
#include <Vuforia\ObjectTarget.h>
#include <Vuforia\StateUpdater.h>
#include <Vuforia\TrackableResult.h>
#include <Vuforia\DeviceTrackableResult.h>

using namespace Platform;
using namespace Windows::Foundation;
using namespace Windows::Foundation::Collections;
using namespace Windows::Graphics::Display;
using namespace Windows::Storage;
using namespace Windows::System::Threading;
using namespace Windows::UI::Core;
using namespace Windows::UI::Input;
using namespace Windows::UI::Xaml;
using namespace Windows::UI::Xaml::Controls;
using namespace Windows::UI::Xaml::Controls::Primitives;
using namespace Windows::UI::Xaml::Data;
using namespace Windows::UI::Xaml::Input;
using namespace Windows::UI::Xaml::Media;
using namespace Windows::UI::Xaml::Navigation;
using namespace concurrency;

using namespace VuforiaSamples;
using namespace GroundPlane;

GroundPlaneView::GroundPlaneView() :
    m_windowVisible(true),
    m_showingMenu(false),
    m_showingProgress(true),
    m_coreInput(nullptr),
    m_autofocusEnabled(true)
{
    LOGC(LOGTAG, "GroundPlaneView");

    InitializeComponent();

    Application^ app = Application::Current;
    suspendingToken =
        app->Suspending += ref new SuspendingEventHandler(this, &GroundPlaneView::OnSuspending);
    resumingToken =
        app->Resuming += ref new EventHandler<Object^>(this, &GroundPlaneView::OnResuming);

    // Register event handlers for page lifecycle.
    CoreWindow^ window = Window::Current->CoreWindow;

    visibilityChangedToken = window->VisibilityChanged +=
        ref new TypedEventHandler<CoreWindow^, VisibilityChangedEventArgs^>
        (this, &GroundPlaneView::OnVisibilityChanged);

    // Register DisplayInformation Events
    DisplayInformation^ currentDisplayInformation = DisplayInformation::GetForCurrentView();

    token1 = currentDisplayInformation->DpiChanged +=
        ref new TypedEventHandler<DisplayInformation^, Object^>
        (this, &GroundPlaneView::OnDpiChanged);

    token2 = currentDisplayInformation->OrientationChanged +=
        ref new TypedEventHandler<DisplayInformation^, Object^>
        (this, &GroundPlaneView::OnOrientationChanged);

    token3 = DisplayInformation::DisplayContentsInvalidated +=
        ref new TypedEventHandler<DisplayInformation^, Object^>
        (this, &GroundPlaneView::OnDisplayContentsInvalidated);

    // Register SwapChainPanel Events
    token4 = swapChainPanel->CompositionScaleChanged +=
        ref new TypedEventHandler<SwapChainPanel^, Object^>
        (this, &GroundPlaneView::OnCompositionScaleChanged);

    token5 = swapChainPanel->SizeChanged +=
        ref new SizeChangedEventHandler(this, &GroundPlaneView::OnSwapChainPanelSizeChanged);

    // At this point we have access to the device.
    // We can create the device-dependent resources.
    m_deviceResources = std::make_shared<DX::DeviceResources>();
    m_deviceResources->SetSwapChainPanel(swapChainPanel);

    // Register our SwapChainPanel to get independent input pointer events
    auto workItemHandler = ref new WorkItemHandler([this](IAsyncAction ^)
    {
        // The CoreIndependentInputSource will raise pointer events for the specified device types on whichever thread it's created on.
        m_coreInput = swapChainPanel->CreateCoreIndependentInputSource(
            Windows::UI::Core::CoreInputDeviceTypes::Mouse |
            Windows::UI::Core::CoreInputDeviceTypes::Touch |
            Windows::UI::Core::CoreInputDeviceTypes::Pen
        );

        // Register for pointer events, which will be raised on the background thread.
        token6 = m_coreInput->PointerPressed += ref new TypedEventHandler
            <Object^, PointerEventArgs^>(this, &GroundPlaneView::OnPointerPressed);
        token7 = m_coreInput->PointerMoved += ref new TypedEventHandler
            <Object^, PointerEventArgs^>(this, &GroundPlaneView::OnPointerMoved);
        token8 = m_coreInput->PointerReleased += ref new TypedEventHandler
            <Object^, PointerEventArgs^>(this, &GroundPlaneView::OnPointerReleased);

        // Begin processing input messages as they're delivered.
        m_coreInput->Dispatcher->ProcessEvents(CoreProcessEventsOption::ProcessUntilQuit);

    });

    // Run task on a dedicated high priority background thread.
    m_inputLoopWorker = ThreadPool::RunAsync(
        workItemHandler,
        WorkItemPriority::High,
        WorkItemOptions::TimeSliced
    );

    InitializeUI();

    // Init Vuforia App Session
    m_appSession = std::make_shared<AppSession>(this);
    m_appSession->InitAR(DEVICE_TRACKER | SMART_TERRAIN);

    m_main = std::make_unique<GroundPlane::GroundPlaneMain>(m_deviceResources, m_appSession, this);

    m_main->StartRenderLoop();

    InitializeTimers();
}

GroundPlaneView::~GroundPlaneView()
{
    LOGC(LOGTAG, "~GroundPlaneView");

    m_dispatcherTimer->Tick -= timerToken1;
    m_relocalizationDelayTimer->Tick -= timerToken2;
    m_resetDeviceTrackerTimer->Tick -= timerToken3;

    Application^ app = Application::Current;
    app->Suspending -= suspendingToken;
    app->Resuming -= resumingToken;

    CoreWindow^ window = Window::Current->CoreWindow;
    window->VisibilityChanged -= visibilityChangedToken;

    DisplayInformation^ currentDisplayInformation = DisplayInformation::GetForCurrentView();
    currentDisplayInformation->DpiChanged -= token1;
    currentDisplayInformation->OrientationChanged -= token2;
    DisplayInformation::DisplayContentsInvalidated -= token3;

    swapChainPanel->CompositionScaleChanged -= token4;
    swapChainPanel->SizeChanged -= token5;
}

void GroundPlaneView::OnNavigatedFrom(Windows::UI::Xaml::Navigation::NavigationEventArgs^ e)
{
    LOGC(LOGTAG, "OnNavigatedFrom");
}

void GroundPlaneView::OnNavigatedTo(Windows::UI::Xaml::Navigation::NavigationEventArgs^ e)
{
    LOGC(LOGTAG, "OnNavigatedTo");
}

// Saves the current state of the app for suspend and terminate events.
void GroundPlaneView::SaveInternalState(IPropertySet^ state)
{
    LOGC(LOGTAG, "SaveInternalState");

    critical_section::scoped_lock lock(m_main->GetCriticalSection());
    m_deviceResources->Trim();

    // Stop rendering when the app is suspended.
    m_main->StopRenderLoop();

    // Put code to save app state here.
}

// Loads the current state of the app for resume events.
void GroundPlaneView::LoadInternalState(IPropertySet^ state)
{
    LOGC(LOGTAG, "LoadInternalState");

    // Put code to load app state here.

    // Start rendering when the app is resumed.
    m_main->StartRenderLoop();
}

// BEGIN: Window Event Handlers

void GroundPlaneView::OnSuspending(Platform::Object ^ sender, Windows::ApplicationModel::SuspendingEventArgs ^ e)
{
    LOGC(LOGTAG, "OnSuspending");

    SaveInternalState(ApplicationData::Current->LocalSettings->Values);
    OnPause();
}

void GroundPlaneView::OnResuming(Platform::Object ^ sender, Platform::Object ^ args)
{
    LOGC(LOGTAG, "OnResuming");

    LoadInternalState(ApplicationData::Current->LocalSettings->Values);
    OnResume();
}

void GroundPlaneView::OnPause()
{
    LOGC(LOGTAG, "OnPause");

    try
    {
        m_appSession->PauseAR();
    }
    catch (Platform::Exception^ ex)
    {
        SampleCommon::SampleUtil::Log(LOGTAG, ex->Message);
    }

    SetMidAirModeEnabled(false);
}

void GroundPlaneView::OnResume()
{
    LOGC(LOGTAG, "OnResume");

    try
    {
        m_appSession->ResumeAR();
    }
    catch (Platform::Exception^ ex)
    {
        SampleCommon::SampleUtil::Log(LOGTAG, ex->Message);
    }
}

// END: Window Event Handlers


// CoreWindow Event Handler.

void GroundPlaneView::OnVisibilityChanged(CoreWindow^ sender, VisibilityChangedEventArgs^ args)
{
    LOGC(LOGTAG, "OnVisibilityChanged");

    m_windowVisible = args->Visible;
    if (m_windowVisible)
    {
        LOG("Window changed to Visible");
        m_appSession->ResumeAR();
        m_main->StartRenderLoop();
    }
    else
    {
        LOG("Window changed to Not Visible");
        m_main->StopRenderLoop();
        m_appSession->PauseAR();
    }
}

// DisplayInformation Event Handlers

void GroundPlaneView::OnDpiChanged(DisplayInformation^ sender, Object^ args)
{
    LOGC(LOGTAG, "OnDpiChanged");

    critical_section::scoped_lock lock(m_main->GetCriticalSection());
    // Note: The value for LogicalDpi retrieved here may not match the effective DPI of the app
    // if it is being scaled for high resolution devices. Once the DPI is set on DeviceResources,
    // you should always retrieve it using the GetDpi method.
    // See DeviceResources.cpp for more details.
    m_deviceResources->SetDpi(sender->LogicalDpi);
    m_main->CreateWindowSizeDependentResources();
}

void GroundPlaneView::OnOrientationChanged(DisplayInformation^ sender, Object^ args)
{
    LOGC(LOGTAG, "OnOrientationChanged");

    critical_section::scoped_lock lock(m_main->GetCriticalSection());
    m_deviceResources->SetCurrentOrientation(sender->CurrentOrientation);
    m_main->CreateWindowSizeDependentResources();
}

void GroundPlaneView::OnDisplayContentsInvalidated(DisplayInformation^ sender, Object^ args)
{
    LOGC(LOGTAG, "OnDisplayContentsInvalidated");

    critical_section::scoped_lock lock(m_main->GetCriticalSection());
    m_deviceResources->ValidateDevice();
}

// SwapChainPanel Event Handlers

void GroundPlaneView::OnCompositionScaleChanged(SwapChainPanel^ sender, Object^ args)
{
    LOGC(LOGTAG, "OnCompositionScaleChanged");

    critical_section::scoped_lock lock(m_main->GetCriticalSection());
    m_deviceResources->SetCompositionScale(sender->CompositionScaleX, sender->CompositionScaleY);
    m_main->CreateWindowSizeDependentResources();
}

void GroundPlaneView::OnSwapChainPanelSizeChanged(Object^ sender, SizeChangedEventArgs^ e)
{
    LOGC(LOGTAG, "OnSwapChainPanelSizeChanged");

    critical_section::scoped_lock lock(m_main->GetCriticalSection());
    m_deviceResources->SetLogicalSize(e->NewSize);
    m_main->CreateWindowSizeDependentResources();
}

// Pointer (touch) Handlers

void GroundPlaneView::OnPointerPressed(Object^ sender, PointerEventArgs^ e)
{
    static std::atomic<int> tapCount = 0;
    tapCount++;
    static double lastTime = 0;
    double currentTime = m_main->GetTimer().GetTotalSeconds();
    double dt = currentTime - lastTime;
    lastTime = currentTime;

    if (tapCount == 1)
    {
        // Run async task
        Concurrency::create_task([this]()
        {
            // Wait for half-second, if no second tap comes,
            // then we have confirmed a single-tap
            // else we have a double-tap
            WaitForSingleObjectEx(GetCurrentThread(), 500, FALSE);

            if (tapCount == 1)
            {
                // tapCount is still 1, nothing changed,
                // so we have confirmed a single-tap,
                // so we consume the single-tap event:
                tapCount = 0;

                HandleSingleTap();
            }
            else if (tapCount >= 2)
            {
                // We process the double-tap event
                tapCount = 0;

                HandleDoubleTap();
            }
        });
    }
}

void GroundPlaneView::OnPointerMoved(Object^ sender, PointerEventArgs^ e)
{
    // Move/drag event
}

void GroundPlaneView::OnPointerReleased(Object^ sender, PointerEventArgs^ e)
{
    // Touch released
}

void GroundPlaneView::HandleSingleTap()
{
    LOGC(LOGTAG, "HandleSingleTap");

    // Set a new anchor
    m_main->OnTapGesture();

    if (m_showingMenu)
    {
        // Hide menu (async on UI thread)
        Windows::ApplicationModel::Core::CoreApplication::MainView->CoreWindow->Dispatcher->RunAsync(
            Windows::UI::Core::CoreDispatcherPriority::Normal,
            ref new Windows::UI::Core::DispatchedHandler([=]()
        {
            ToggleMenu(false);
        }));
    }
    else
    {
        // Trigger an autofocus event
        Vuforia::CameraDevice::getInstance().setFocusMode(Vuforia::CameraDevice::FOCUS_MODE_TRIGGERAUTO);

        // Make sure original focus mode is restored after ~2 seconds
        WaitForSingleObjectEx(GetCurrentThread(), 2500, FALSE);

        if (m_autofocusEnabled)
        {
            // Restore continuous autofocus
            Vuforia::CameraDevice::getInstance().setFocusMode(
                Vuforia::CameraDevice::FOCUS_MODE_CONTINUOUSAUTO);
        }
        else
        {
            // Restore normal focus mode
            Vuforia::CameraDevice::getInstance().setFocusMode(
                Vuforia::CameraDevice::FOCUS_MODE_NORMAL);
        }
    }
}

void GroundPlaneView::HandleDoubleTap()
{
    LOGC(LOGTAG, "HandleDoubleTap");

    if (!m_showingMenu)
    {
        // Show the menu (async on UI thread)
        Windows::ApplicationModel::Core::CoreApplication::MainView->CoreWindow->Dispatcher->RunAsync(
            Windows::UI::Core::CoreDispatcherPriority::Normal,
            ref new Windows::UI::Core::DispatchedHandler([=]()
        {
            ToggleMenu(true);
        }));
    }
}


// ***** XAML Support Methods *****
/*
void GroundPlaneView::InitializeUI()
void GroundPlaneView::ToggleMenu(bool enable)
void GroundPlaneView::OnExitClick(Platform::Object^ sender, Windows::UI::Xaml::RoutedEventArgs^ e)
void GroundPlaneView::OnMenuAnimationDone(Platform::Object^ sender, Windows::UI::Xaml::RoutedEventArgs^ e)
void GroundPlaneView::HideProgressIndicator()
*/

void GroundPlaneView::InitializeUI()
{
    // Hide elements at start
    this->InstructionPanel->Visibility = Windows::UI::Xaml::Visibility::Collapsed;
    this->StatusToast->Visibility = Windows::UI::Xaml::Visibility::Collapsed;
    this->OptionsMenu->Visibility = Windows::UI::Xaml::Visibility::Collapsed;

    ToggleMenu(false);

    VuforiaVersion->Text = "Vuforia " + SampleCommon::SampleUtil::ToPlatformString(Vuforia::getLibraryVersion());
}

void GroundPlaneView::ToggleMenu(bool enable)
{
    LOGC(LOGTAG, "ToggleMenu");

    if (enable)
    {
        this->OptionsMenu->Visibility = Windows::UI::Xaml::Visibility::Visible;
    }

    m_showingMenu = enable;

    if (enable)
        this->ShowMenuStoryboard->Begin();
    else
        this->HideMenuStoryboard->Begin();
}

void GroundPlaneView::OnExitClick(Platform::Object^ sender, Windows::UI::Xaml::RoutedEventArgs^ e)
{
    LOGC(LOGTAG, "OnExitClick");

    ToggleMenu(false);
}

void GroundPlaneView::OnMenuAnimationDone(Platform::Object^ sender, Windows::UI::Xaml::RoutedEventArgs^ e)
{
    LOGC(LOGTAG, "OnMenuAnimationDone");

    this->OptionsMenu->Visibility = m_showingMenu ?
        Windows::UI::Xaml::Visibility::Visible :
        Windows::UI::Xaml::Visibility::Collapsed;
}

void GroundPlaneView::HideProgressIndicator()
{
    LOGC(LOGTAG, "HideProgressIndicator");

    if (!m_showingProgress) {
        // Skip, as already hidden
        return;
    }

    auto dispatcher = Windows::ApplicationModel::Core::CoreApplication::MainView->CoreWindow->Dispatcher;
    dispatcher->RunAsync(
        Windows::UI::Core::CoreDispatcherPriority::High,
        ref new Windows::UI::Core::DispatchedHandler([this]()
    {
        this->InitProgressRing->IsActive = false;
        this->InitProgressRing->Visibility = Windows::UI::Xaml::Visibility::Collapsed;
        m_showingProgress = false;
    }));
}

// ***** Vuforia Camera Management Methods *****
/*
void GroundPlaneView::BeforeStartCamera()
void GroundPlaneView::BeforeStopCamera()
*/

void GroundPlaneView::BeforeStartCamera()
{
    LOGC(LOGTAG, "BeforeStartCamera");

    if (!Vuforia::CameraDevice::getInstance().selectVideoMode(
        Vuforia::CameraDevice::MODE_DEFAULT))
    {
        SampleCommon::SampleUtil::Log(LOGTAG, "Failed to set the camera video mode.");
    }

    m_appSession->ConfigureVideoBackground(
        m_deviceResources->GetOutputSize(),
        m_deviceResources->GetCurrentOrientation()
    );

    m_main->GetRenderer()->UpdateRenderingPrimitives();
}

void GroundPlaneView::BeforeStopCamera()
{
    LOGC(LOGTAG, "BeforeStopCamera");

    // Notify renderer, do this before stopping the camera
    m_main->GetRenderer()->SetVuforiaStarted(false);
}

// ***** Vuforia Tracker Management Methods *****
/*
bool GroundPlaneView::DoStartTrackers()
bool GroundPlaneView::DoStopTrackers()
bool GroundPlaneView::DoLoadTrackersData()
*/

bool GroundPlaneView::DoStartTrackers()
{
    LOGC(LOGTAG, "DoStartTrackers");

    // Start DeviceTracker, then SmartTerrain

    if (!m_appSession->StartTracker(Vuforia::PositionalDeviceTracker::getClassType()))
    {
        return false;
    }
    if (!m_appSession->StartTracker(Vuforia::SmartTerrain::getClassType()))
    {
        m_appSession->StopTracker(Vuforia::PositionalDeviceTracker::getClassType());
        SampleCommon::SampleUtil::Log(LOGTAG, "Stopped Device Tracker due to failure to start SmartTerrain.");
        return false;
    }
    return true;
}

bool GroundPlaneView::DoStopTrackers()
{
    LOGC(LOGTAG, "DoStopTrackers");

    // Stop SmartTerrain, then DeviceTracker

    return (
        m_appSession->StopTracker(Vuforia::SmartTerrain::getClassType()) &&
        m_appSession->StopTracker(Vuforia::PositionalDeviceTracker::getClassType()));
}

bool GroundPlaneView::DoLoadTrackersData()
{
    // No datasets used in GroundPlane sample
    return true;
}

// ***** Vuforia Event Methods *****
/*
void GroundPlaneView::OnInitARDone()
void GroundPlaneView::OnARStarted()
void GroundPlaneView::OnVuforiaUpdate(VuforiaState ^ vuforiaState)
*/

// This callback is called after the Vuforia initialization is complete,
// the trackers are initialized, their data loaded and
// tracking is ready to start
void GroundPlaneView::OnInitARDone()
{
    LOGC(LOGTAG, "OnInitARDone");

    m_main->GetRenderer()->SetVuforiaInitialized(true);

    m_appSession->ConfigureDisplay(
        m_deviceResources->GetOutputSize(),
        m_deviceResources->GetCurrentOrientation()
    );
}

void GroundPlaneView::OnARStarted()
{
    LOGC(LOGTAG, "OnARStarted");

    m_main->GetRenderer()->SetVuforiaStarted(true);

    // Try enabling continuous autofocus after camera start
    EnableAutofocus();

    // Hide init progress indicator
    HideProgressIndicator();

    Vuforia::onSurfaceCreated();
}

void GroundPlaneView::EnableAutofocus()
{
    m_autofocusEnabled = Vuforia::CameraDevice::getInstance().setFocusMode(
        Vuforia::CameraDevice::FOCUS_MODE_CONTINUOUSAUTO);

    if (!m_autofocusEnabled)
    {
        // Failed, it means continuous autofocus is not supported by this device
        SampleCommon::SampleUtil::Log(LOGTAG, "Failed to enable autofocus.");

        // Fall back to normal focus mode
        Vuforia::CameraDevice::getInstance().setFocusMode(Vuforia::CameraDevice::FOCUS_MODE_NORMAL);

        // Update UI Toggle (switch it OFF)
        Windows::ApplicationModel::Core::CoreApplication::MainView->CoreWindow->Dispatcher->RunAsync(
            Windows::UI::Core::CoreDispatcherPriority::Normal,
            ref new Windows::UI::Core::DispatchedHandler([=]()
        {
            // Update the XAML UI control
            this->ToggleAutofocus->IsOn = false;
        }));
    }
}

// This callback is called every cycle
void GroundPlaneView::OnVuforiaUpdate(VuforiaState^ vuforiaState)
{
    Vuforia::State* state = vuforiaState->m_nativeState;
}

void GroundPlaneView::Stop()
{
    LOGC(LOGTAG, "Stop");

    // Stop rendering when the app is suspended.
    m_main->StopRenderLoop();

    // Notify renderer
    m_main->GetRenderer()->SetVuforiaInitialized(false);

    m_coreInput->Dispatcher->StopProcessEvents();

    // Stop and deinit Vuforia
    m_appSession->StopAR();
}

// ***** XAML UI Button Methods *****
/*
void GroundPlaneView::OnBackButtonClicked(Platform::Object ^ sender, Windows::UI::Xaml::RoutedEventArgs ^ e)
void GroundPlaneView::OnToggleDeviceTracking(Object^ sender, RoutedEventArgs^ e)
void GroundPlaneView::OnToggleAutofocus(Object^ sender, RoutedEventArgs^ e)
*/

void GroundPlaneView::OnBackButtonClicked(Platform::Object ^ sender, Windows::UI::Xaml::RoutedEventArgs ^ e)
{
    LOGC(LOGTAG, "OnBackButtonClicked");

    Stop();

    while (m_appSession->VuforiaInitialized())
    {
        Concurrency::wait(500);
    }

    // Navigate back to Menu Page
    ((Windows::UI::Xaml::Controls::Frame ^)(Window::Current->Content))->Navigate(MenuPage::typeid);
}

void GroundPlaneView::OnToggleDeviceTracking(Object^ sender, RoutedEventArgs^ e)
{
    LOGC(LOGTAG, "OnToggleDeviceTracking");

    ToggleSwitch^ toggleSwitch = (ToggleSwitch^)sender;

    if (m_appSession != nullptr && m_appSession->VuforiaInitialized())
    {
        if (toggleSwitch->IsOn)
        {
            m_deviceTracking = m_appSession->StartTracker(Vuforia::PositionalDeviceTracker::getClassType());
        }
        else
        {
            m_appSession->StopTracker(Vuforia::PositionalDeviceTracker::getClassType());
            m_deviceTracking = false;
        }
        m_main->GetRenderer()->SetDeviceTrackerEnabled(m_deviceTracking);
    }
}

void GroundPlaneView::OnToggleAutofocus(Object^ sender, RoutedEventArgs^ e)
{
    LOGC(LOGTAG, "OnToggleAutofocus");

    ToggleSwitch^ toggleSwitch = (ToggleSwitch^)sender;

    if (m_appSession != nullptr && m_appSession->VuforiaInitialized())
    {
        if (toggleSwitch->IsOn)
        {
            // Try enabling continuous autofocus
            m_autofocusEnabled = Vuforia::CameraDevice::getInstance()
                .setFocusMode(Vuforia::CameraDevice::FOCUS_MODE_CONTINUOUSAUTO);

            if (!m_autofocusEnabled)
            {
                // Failed, it means continuous autofocus is not supported by this device
                SampleCommon::SampleUtil::Log(LOGTAG, "Failed to enabled autofocus.");

                // Fall back to normal focus mode
                Vuforia::CameraDevice::getInstance().setFocusMode(Vuforia::CameraDevice::FOCUS_MODE_NORMAL);

                // Update UI Toggle (switch it OFF)
                toggleSwitch->IsOn = false;
            }
        }
        else
        {
            m_autofocusEnabled = false;
            Vuforia::CameraDevice::getInstance().setFocusMode(Vuforia::CameraDevice::FOCUS_MODE_NORMAL);
        }
    }
}

void GroundPlaneView::ShowTrackingStatus(bool show)
{
    Windows::ApplicationModel::Core::CoreApplication::MainView->CoreWindow->Dispatcher->RunAsync(
        Windows::UI::Core::CoreDispatcherPriority::Normal,
        ref new Windows::UI::Core::DispatchedHandler([=]()
    {
        // Set debug to true if you want to see device tracking status'
        bool debug = false;
        if (debug)
        {
            m_currentTrackingStatusString = LogAndReturnStatusString();
            this->StatusMessage->Text = m_currentTrackingStatusString;
            this->StatusToast->Visibility = Windows::UI::Xaml::Visibility::Visible;
            return;
        }

        if (show)
        {
            this->StatusMessage->Text = m_currentTrackingStatusString;
            this->StatusToast->Visibility = Windows::UI::Xaml::Visibility::Visible;
        }
        else
        {
            this->StatusToast->Visibility = Windows::UI::Xaml::Visibility::Collapsed;
        }
    }));
}

void GroundPlaneView::ShowInstructionText(bool show)
{
    Windows::ApplicationModel::Core::CoreApplication::MainView->CoreWindow->Dispatcher->RunAsync(
        Windows::UI::Core::CoreDispatcherPriority::Normal,
        ref new Windows::UI::Core::DispatchedHandler([=]()
    {
        if (show)
        {
            this->InstructionText->Text = m_currentInstructionString;
            this->InstructionPanel->Visibility = Windows::UI::Xaml::Visibility::Visible;
        }
        else
        {
            this->InstructionPanel->Visibility = Windows::UI::Xaml::Visibility::Collapsed;
        }
    }));
}

void GroundPlaneView::OnPlacementModeChanged(Platform::Object^ sender, Windows::UI::Xaml::RoutedEventArgs^ e)
{
    if (m_appSession != nullptr && m_appSession->VuforiaInitialized())
    {
        bool setAirMode = sender->Equals(this->MidAirModeRadio);
        m_main->OnPlacementModeChanged(setAirMode);
    }
}

void GroundPlaneView::OnResetButtonTapped(Platform::Object^ sender, Windows::UI::Xaml::Input::TappedRoutedEventArgs^ e)
{
    if (m_appSession != nullptr && m_appSession->VuforiaInitialized())
    {
        m_main->Reset();
    }
}

// === GroundPlaneUIControl Implementation -- BEGIN ===

void GroundPlaneView::SetMidAirModeEnabled(bool enable)
{
    auto dispatcher = Windows::ApplicationModel::Core::CoreApplication::MainView->CoreWindow->Dispatcher;
    dispatcher->RunAsync(
        Windows::UI::Core::CoreDispatcherPriority::Normal, ref new DispatchedHandler([=]()
    {
        if (!enable)
        {
            this->HitTestModeRadio->IsChecked = true;
        }

        this->MidAirModeRadio->IsEnabled = enable;
    }, CallbackContext::Any));
}

void GroundPlaneView::UpdateTrackingStatusInfo(int status)
{
    if (m_currentTrackingStatus != status)
    {
        bool showStatus = true;
        m_currentTrackingStatus = status;

        switch (status)
        {
        case Vuforia::TrackableResult::STATUS_INFO::NORMAL:
        case Vuforia::TrackableResult::STATUS_INFO::UNKNOWN:
            showStatus = false;
            break;

        case Vuforia::TrackableResult::STATUS_INFO::INITIALIZING:
            showStatus = true;
            m_currentTrackingStatusString = "Point your device to the floor and move to scan";
            break;

        case Vuforia::TrackableResult::STATUS_INFO::INSUFFICIENT_FEATURES:
            showStatus = true;
            m_currentTrackingStatusString = "Not enough visual features in the scene";
            break;

        case Vuforia::TrackableResult::STATUS_INFO::EXCESSIVE_MOTION:
            showStatus = true;
            m_currentTrackingStatusString = "Move slower";
            break;

        default:
            showStatus = false;
            m_currentTrackingStatusString = "";
            break;
        }

        ShowTrackingStatus(showStatus);
    }
}

void GroundPlaneView::UpdateInstructionText(Instruction instruction)
{
    if (m_currentInstructionStatus != instruction)
    {
        bool showInstruction = false;
        m_currentInstructionStatus = instruction;

        switch (m_currentInstructionStatus)
        {
        case Instruction::POINT_TO_GROUND:
            showInstruction = true;
            m_currentInstructionString = "Point device towards the ground";
            break;

        case Instruction::TAP_TO_PLACE:
            showInstruction = true;
            m_currentInstructionString = "Touch anywhere on screen";
            break;

        case Instruction::MOVE_TO_PLACE_ANCHOR:
            showInstruction = true;
            m_currentInstructionString = "Move to get better tracking for placing an anchor";
            break;

        case Instruction::INSTRUCTION_UNDEFINED:
            showInstruction = false;
            m_currentInstructionString = "";
            break;

        default:
            SampleCommon::SampleUtil::Log(LOGTAG, "Invalid user instruction");

            showInstruction = false;
            m_currentInstructionString = "";
            break;
        }

        ShowInstructionText(showInstruction);
    }
}

// === GroundPlaneUIControl Implementation -- END ===


// ***** Vuforia Tracking Timer Event Handlers *****
/*
void GroundPlaneView::InitializeTimers()
void GroundPlaneView::UpdateIntervalTimerTick(Platform::Object^ sender, Platform::Object^ e)
void GroundPlaneView::RelocalizationDelayTimerTick(Platform::Object^ sender, Platform::Object^ e)
void GroundPlaneView::ResetDeviceTrackerTimerTick(Platform::Object^ sender, Platform::Object^ e)
Platform::String^ GroundPlaneView::LogAndReturnStatusString()
*/

void GroundPlaneView::InitializeTimers()
{
    LOGC(LOGTAG, "InitializeTimers");

    const int64 OneSecond = 10'000'000; // One second = 10,000,000 ticks

    // Setup timer to check for tracking status changes at regular interval and update UI
    m_dispatcherTimer = ref new DispatcherTimer();
    timerToken1 = m_dispatcherTimer->Tick += ref new EventHandler<Object^>
        (this, &GroundPlaneView::UpdateIntervalTimerTick);
    m_dispatcherTimer->Interval = TimeSpan{ OneSecond / 2 };
    m_dispatcherTimer->Start();

    // Setup timer to wait for 1 second after receiving a RELOCALIZING tracking status event before proceeding
    m_relocalizationDelayTimer = ref new DispatcherTimer();
    timerToken2 = m_relocalizationDelayTimer->Tick += ref new EventHandler<Object^>
        (this, &GroundPlaneView::RelocalizationDelayTimerTick);
    m_relocalizationDelayTimer->Interval = TimeSpan{ OneSecond };

    // Setup timer to wait for 10 seconds after RELOCALIZING status has been constant for 1 second
    m_resetDeviceTrackerTimer = ref new DispatcherTimer();
    timerToken3 = m_resetDeviceTrackerTimer->Tick += ref new EventHandler<Object^>
        (this, &GroundPlaneView::ResetDeviceTrackerTimerTick);
    m_resetDeviceTrackerTimer->Interval = TimeSpan{ OneSecond * 10 };
}

void GroundPlaneView::UpdateIntervalTimerTick(Platform::Object^ sender, Platform::Object^ e)
{
    const Vuforia::State state = Vuforia::TrackerManager::getInstance().getStateUpdater().getLatestState();

    if (state.getDeviceTrackableResult() != nullptr)
    {
        m_enumStatus = state.getDeviceTrackableResult()->getStatus();
        m_enumStatusInfo = state.getDeviceTrackableResult()->getStatusInfo();
    }

    if (m_enumStatusInfo == Vuforia::TrackableResult::RELOCALIZING)
    {
        if (!m_relocalizationDelayTimer->IsEnabled)
        {
            m_relocalizationDelayTimer->Start();
        }
    }
    else
    {
        // Stop the relocalization and reset timers if they are active
        if (m_relocalizationDelayTimer->IsEnabled)
        {
            m_relocalizationDelayTimer->Stop();
        }

        if (m_resetDeviceTrackerTimer->IsEnabled)
        {
            m_resetDeviceTrackerTimer->Stop();
        }

        // Hide the on-screen status message if status is Normal
        if (m_enumStatusInfo == Vuforia::TrackableResult::NORMAL)
        {
            ShowTrackingStatus(false);
        }
    }
}

void GroundPlaneView::RelocalizationDelayTimerTick(Platform::Object^ sender, Platform::Object^ e)
{
    LOGC(LOGTAG, "RelocalizationDelayTimerTick");

    if (m_main->GetRenderer()->IsTargetCurrentlyTracked())
    {
        return;
    }

    m_currentTrackingStatusString = "Point back to previously seen area and rescan to relocalize.";

    ShowTrackingStatus(true);

    if (!m_resetDeviceTrackerTimer->IsEnabled)
    {
        m_resetDeviceTrackerTimer->Start();
    }
}

void GroundPlaneView::ResetDeviceTrackerTimerTick(Platform::Object^ sender, Platform::Object^ e)
{
    LOGC(LOGTAG, "ResetDeviceTrackerTimerTick");

    // If timer reaches interval ticks, this method will reset the device tracker
    m_main->Reset();
}

// Status Reporting

Platform::String^ GroundPlaneView::LogAndReturnStatusString()
{
    /* STATUS:
    NO_POSE = No pose was delivered for the trackable.
    LIMITED = The trackable is being tracked in a limited form.
    DETECTED = The trackable was detected.
    TRACKED = The trackable is being tracked.
    EXTENDED_TRACKED = The trackable is being tracked using extended tracking.
    */

    /* STATUS_INFO
    NORMAL = Status is normal, ie not NO_POSE or LIMITED.
    UNKNOWN = Unknown reason for the tracking status.
    INITIALIZING = The tracking system is currently initializing.
    RELOCALIZING = The tracking system is currently relocalizing.
    EXCESSIVE_MOTION = The device is moving too fast.
    INSUFFICIENT_FEATURES = There are insufficient features available in the scene.
    */

    std::wstring status;
    std::wstring statusInfo;

    switch (this->m_enumStatus)
    {
    case Vuforia::TrackableResult::NO_POSE:
        status = L"NO_POSE";
        break;
    case Vuforia::TrackableResult::LIMITED:
        status = L"LIMITED";
        break;
    case Vuforia::TrackableResult::DETECTED:
        status = L"DETECTED";
        break;
    case Vuforia::TrackableResult::TRACKED:
        status = L"TRACKED";
        break;
    case Vuforia::TrackableResult::EXTENDED_TRACKED:
        status = L"EXTENDED_TRACKED";
        break;
    }

    switch (this->m_enumStatusInfo)
    {
    case Vuforia::TrackableResult::NORMAL:
        statusInfo = L"NORMAL";
        break;
    case Vuforia::TrackableResult::UNKNOWN:
        statusInfo = L"UNKNOWN";
        break;
    case Vuforia::TrackableResult::INITIALIZING:
        statusInfo = L"INITIALIZING";
        break;
    case Vuforia::TrackableResult::RELOCALIZING:
        statusInfo = L"RELOCALIZING";
        break;
    case Vuforia::TrackableResult::EXCESSIVE_MOTION:
        statusInfo = L"EXCESSIVE_MOTION";
        break;
    case Vuforia::TrackableResult::INSUFFICIENT_FEATURES:
        statusInfo = L"INSUFFICIENT_FEATURES";
        break;
    }

    // Report Status and StatusInfo Changes
    std::wstring combinedStatus = L"Status: " + status + L" -- StatusInfo: " + statusInfo;

    OutputDebugString((combinedStatus + L"\n").c_str());

    return ref new String(combinedStatus.c_str());
}
