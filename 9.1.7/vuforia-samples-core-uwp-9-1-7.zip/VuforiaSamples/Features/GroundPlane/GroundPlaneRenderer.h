/*===============================================================================
Copyright (c) 2020 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/
#pragma once

#include "Common/DeviceResources.h"
#include "Common/ShaderStructures.h"
#include "Common/StepTimer.h"
#include "Common/Texture.h"
#include "Common/TeapotMesh.h"
#include "Common/SampleApp3DModel.h"
#include "Common/VideoBackground.h"

#include <Vuforia/Anchor.h>
#include <Vuforia/Matrices.h>
#include <Vuforia/Renderer.h>
#include <Vuforia/RenderingPrimitives.h>
#include <Vuforia/State.h>
#include <Vuforia/TrackableResult.h>

namespace GroundPlane
{
    // Instructions for the user
    public enum class Instruction
    {
        // Instruct the user to point the device towards the ground to detect surfaces
        POINT_TO_GROUND,

        // Instruct the user to tap the screen to place an anchored object
        TAP_TO_PLACE,

        // Instruct the user to move to be able to place an anchor
        MOVE_TO_PLACE_ANCHOR,

        // No instruction for the user
        INSTRUCTION_UNDEFINED
    };

    public interface class GroundPlaneUIControl
    {
    public:
        void SetMidAirModeEnabled(bool enable);
        void UpdateTrackingStatusInfo(int status);
        void UpdateInstructionText(Instruction instruction);
    };

    // This sample renderer instantiates a basic rendering pipeline.
    class GroundPlaneRenderer
    {
    public:
        // Modes of the ground plane sample
        enum class SampleAppMode
        {
            // This mode is set when we want to use the hitTest results so we can place an anchor on the ground
            SAMPLE_APP_INTERACTIVE_MODE,

            // This mode is to position an anchor in an arbitrary position, in the sample the object is positioned in front of the camera
            SAMPLE_APP_MIDAIR_MODE,
        };

        GroundPlaneRenderer(const std::shared_ptr<DX::DeviceResources>& deviceResources,
            GroundPlaneUIControl ^groundPlaneUIControl);

        void CreateDeviceDependentResources();
        void CreateWindowSizeDependentResources();
        void ReleaseDeviceDependentResources();

        void Update(SampleCommon::StepTimer const& timer);
        void Render();

        bool IsRendererInitialized() { return m_rendererInitialized; }
        bool IsVuforiaInitialized() { return m_vuforiaInitialized; }
        bool IsVuforiaStarted() { return m_vuforiaStarted; }
        void SetVuforiaInitialized(bool initialized) { m_vuforiaInitialized = initialized; }
        void SetVuforiaStarted(bool started);
        void SetDeviceTrackerEnabled(bool enabled) { m_deviceTrackerEnabled = enabled; }

        void UpdateRenderingPrimitives();
        void SetNewAnchor(float normalizedTouchPointX, float normalizedTouchPointY);
        void SetPlacementMode(SampleAppMode newPlacementMode);
        bool PerformHitTest(float normalizedTouchPointX, float normalizedTouchPointY, float deviceHeightInMeters, bool createAnchor, const Vuforia::State& state);
        void ResetGroundPlaneStateAndAnchors();
        void ResetTrackers();

        void SetTrackingStatus(const Vuforia::List<const Vuforia::TrackableResult> trackableResultList);
        bool IsTargetCurrentlyTracked();

    private:
        void RenderScene(Vuforia::Renderer &renderer, const Vuforia::State &state);
        void CreateMidAirAnchorWithPose(Vuforia::Matrix34F& anchorPoseMatrix);

        void Render3DModel(
            const DirectX::XMMATRIX &poseMatrix,
            const DirectX::XMMATRIX &projectionMatrix,
            const std::shared_ptr<SampleCommon::Texture> texture,
            const std::shared_ptr<SampleCommon::SampleApp3DModel> model,
            const bool enableTransparency);

        const std::shared_ptr<SampleCommon::Texture> GetAugmentationTexture(const char *targetName);

        // Lock to protect updates to RenderingPrimitives
        Concurrency::critical_section m_renderingPrimitivesLock;

        // Cached pointer to the rendering primitives
        std::shared_ptr<Vuforia::RenderingPrimitives> m_renderingPrimitives;

        // Cached pointer to device resources.
        std::shared_ptr<DX::DeviceResources> m_deviceResources;

        // Ground Plane UI Control
        GroundPlaneUIControl^ m_groundPlaneUIControl;

        // Video background
        std::shared_ptr<SampleCommon::VideoBackground> m_videoBackground;

        // DX States for video background and augmentation rendering
        Microsoft::WRL::ComPtr<ID3D11RasterizerState>   m_augmentationRasterStateCullBack;
        Microsoft::WRL::ComPtr<ID3D11DepthStencilState> m_augmentationDepthStencilState;
        Microsoft::WRL::ComPtr<ID3D11BlendState>        m_augmentationBlendState;

        Microsoft::WRL::ComPtr<ID3D11DepthStencilState> m_reticleDepthStencilState;
        Microsoft::WRL::ComPtr<ID3D11BlendState>        m_reticleBlendState;

        // Direct3D resources for mesh rendering
        Microsoft::WRL::ComPtr<ID3D11InputLayout>    m_augmentationInputLayout;
        Microsoft::WRL::ComPtr<ID3D11VertexShader>    m_augmentationVertexShader;
        Microsoft::WRL::ComPtr<ID3D11PixelShader>    m_augmentationPixelShader;
        Microsoft::WRL::ComPtr<ID3D11Buffer>        m_augmentationConstantBuffer;

        // 3D mesh
        std::shared_ptr<SampleCommon::SampleApp3DModel> m_astroModel;
        std::shared_ptr<SampleCommon::SampleApp3DModel> m_droneModel;
        std::shared_ptr<SampleCommon::SampleApp3DModel> m_planeModel;

        // Textures
        std::shared_ptr<SampleCommon::Texture> m_textureAstronaut;
        std::shared_ptr<SampleCommon::Texture> m_textureDrone;
        std::shared_ptr<SampleCommon::Texture> m_texture3DReticle;
        std::shared_ptr<SampleCommon::Texture> m_texture2DReticle;
        std::shared_ptr<SampleCommon::Texture> m_textureMidAirReticle;

        // System resources for model-view projection.
        SampleCommon::ModelViewProjectionConstantBuffer    m_augmentationConstantBufferData;

        // Variables used with the rendering loop.
        std::atomic<bool> m_rendererInitialized;
        std::atomic<bool> m_vuforiaInitialized;
        std::atomic<bool> m_vuforiaStarted;
        std::atomic<bool> m_deviceTrackerEnabled;
        std::atomic<bool> m_createNewAnchor;

        // Device and smart terrain poses
        Vuforia::Matrix34F  m_devicePoseMatrix34F;
        DirectX::XMFLOAT4X4 m_devicePoseMatrix;
        DirectX::XMFLOAT4X4 m_hitTestPoseMatrix;
        DirectX::XMFLOAT4X4 m_midAirPoseMatrix;
        DirectX::XMFLOAT4X4 m_reticlePose;

        // Anchor for registering content with latest hit test result
        Vuforia::Anchor* m_hitTestAnchor;
        Vuforia::Anchor* m_midAirAnchor;

        // Near and Far clipping planes
        const float m_near = 0.01f;
        const float m_far = 100.0f;

        SampleAppMode m_currentMode = SampleAppMode::SAMPLE_APP_INTERACTIVE_MODE;
        bool m_targetCurrentlyTracked = false;

        // Anchors ids
        static const char* MID_AIR_ANCHOR_NAME;
        static const char* HIT_TEST_ANCHOR_NAME;

        // Log tag
        Platform::String^ LOGTAG = "GroundPlaneRenderer";
    };
}
