/*===============================================================================
Copyright (c) 2020 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/
#include "pch.h"
#include "Common/DirectXHelper.h"
#include <Vuforia/UWP/Vuforia_UWP.h>
#include "GroundPlaneMain.h"

using namespace GroundPlane;
using namespace Windows::Foundation;
using namespace Windows::System::Threading;
using namespace Concurrency;

using namespace VuforiaSamples;

namespace
{
    Platform::String^ LOGTAG = "GroundPlaneMain";
}

// Loads and initializes application assets when the application is loaded.
GroundPlaneMain::GroundPlaneMain(
    const std::shared_ptr<DX::DeviceResources>& deviceResources,
    const std::shared_ptr<AppSession>& appSession,
    GroundPlaneUIControl^ groundPlaneUIControl) :
    m_deviceResources(deviceResources),
    m_appSession(appSession),
    m_groundPlaneUIControl(groundPlaneUIControl),
    m_ResetStateAndTrackers(false)
{
    LOGC(LOGTAG, "GroundPlaneMain");

    // Register to be notified if the Device is lost or recreated
    m_deviceResources->RegisterDeviceNotify(this);

    // Init the scene renderer
    m_renderer = std::make_unique<GroundPlaneRenderer>(m_deviceResources, groundPlaneUIControl);

    // We set the desired frame rate here
    float fps = 60;
    m_timer.SetFixedTimeStep(true);
    m_timer.SetTargetElapsedSeconds(1.0 / fps);
}

GroundPlaneMain::~GroundPlaneMain()
{
    LOGC(LOGTAG, "~GroundPlaneMain");

    // Deregister device notification
    m_deviceResources->RegisterDeviceNotify(nullptr);
    m_deviceResources.reset();
    m_renderer.reset();
}

// Updates application state when the window size changes (e.g. device orientation change)
void GroundPlaneMain::CreateWindowSizeDependentResources()
{
    LOGC(LOGTAG, "CreateWindowSizeDependentResources");

    // Only call Vuforia API after initialization
    if (m_appSession->VuforiaInitialized())
    {
        m_appSession->ConfigureDisplay(
            m_deviceResources->GetOutputSize(),
            m_deviceResources->GetCurrentOrientation()
        );

        if (m_renderer->IsVuforiaStarted())
        {
            m_appSession->ConfigureVideoBackground(
                m_deviceResources->GetOutputSize(),
                m_deviceResources->GetCurrentOrientation()
            );
        }
    }
    else
    {
        LOG("Failed to configure display. Vuforia not initialized yet.");
    }

    m_renderer->CreateWindowSizeDependentResources();
}

void GroundPlaneMain::StartRenderLoop()
{
    LOGC(LOGTAG, "StartRenderLoop");

    // If the animation render loop is already running then do not start another thread.
    if (m_renderLoopWorker != nullptr && m_renderLoopWorker->Status == AsyncStatus::Started)
    {
        return;
    }

    // Create a task that will be run on a background thread.
    auto workItemHandler = ref new WorkItemHandler([this](IAsyncAction ^ action)
    {
        // Calculate the updated frame and render once per vertical blanking interval.
        while (action->Status == AsyncStatus::Started)
        {
            critical_section::scoped_lock lock(GetCriticalSection());
            Update();
            if (Render())
            {
                m_deviceResources->Present();
            }
        }
    });

    // Run task on a dedicated high priority background thread.
    m_renderLoopWorker = ThreadPool::RunAsync(
        workItemHandler,
        WorkItemPriority::High,
        WorkItemOptions::TimeSliced
    );
}

void GroundPlaneMain::StopRenderLoop()
{
    LOGC(LOGTAG, "StopRenderLoop");

    m_renderLoopWorker->Cancel();
}

// Updates the application state once per frame.
void GroundPlaneMain::Update()
{
    ProcessInput();

    // Update scene objects
    m_timer.Tick([&]()
    {
        if (m_renderer->IsRendererInitialized())
        {
            if (m_ResetStateAndTrackers)
            {
                m_renderer->ResetGroundPlaneStateAndAnchors();
                m_ResetStateAndTrackers = false;
            }

            m_renderer->Update(m_timer);
        }
    });
}

// Process all input from the user before updating game state
void GroundPlaneMain::ProcessInput()
{
    // Add per frame input handling here.

}

// Renders the current frame according to the current application state.
// Returns true if the frame was rendered and is ready to be displayed.
bool GroundPlaneMain::Render()
{
    // Don't try to render anything before the first Update.
    if (m_timer.GetFrameCount() == 0)
    {
        return false;
    }

    // Don't render before we finish loading renderer resources
    // (textures, meshes, shaders,...).
    if (!m_renderer->IsRendererInitialized())
    {
        return false;
    }

    auto context = m_deviceResources->GetD3DDeviceContext();

    // Reset the viewport to target the whole screen.
    auto viewport = m_deviceResources->GetScreenViewport();
    context->RSSetViewports(1, &viewport);


    // Reset render targets to the screen.
    ID3D11RenderTargetView *const targets[1] = { m_deviceResources->GetBackBufferRenderTargetView() };
    context->OMSetRenderTargets(1, targets, m_deviceResources->GetDepthStencilView());

    // Clear the back buffer and depth stencil view.
    context->ClearRenderTargetView(m_deviceResources->GetBackBufferRenderTargetView(), DirectX::Colors::Black);
    context->ClearDepthStencilView(m_deviceResources->GetDepthStencilView(), D3D11_CLEAR_DEPTH | D3D11_CLEAR_STENCIL, 1.0f, 0);

    // Render the scene objects.
    m_renderer->Render();

    return true;
}

// Notifies renderers that device resources need to be released.
void GroundPlaneMain::OnDeviceLost()
{
    LOGC(LOGTAG, "OnDeviceLost");

    m_renderer->ReleaseDeviceDependentResources();
}

// Notifies renderers that device resources may now be recreated.
void GroundPlaneMain::OnDeviceRestored()
{
    LOGC(LOGTAG, "OnDeviceRestored");

    m_renderer->CreateDeviceDependentResources();
    CreateWindowSizeDependentResources();
}

// Set flag to reset app state and anchors on next update cycle
void GroundPlaneMain::Reset()
{
    m_ResetStateAndTrackers = true;
}

void GroundPlaneMain::OnTapGesture()
{
    if (m_renderer->IsRendererInitialized())
    {
        m_renderer->SetNewAnchor(0.5f, 0.5f);
    }
}

void GroundPlaneMain::OnPlacementModeChanged(bool setMidAirMode)
{
    if (m_renderer->IsRendererInitialized())
    {
        GroundPlaneRenderer::SampleAppMode modeToSwitch = GroundPlaneRenderer::SampleAppMode::SAMPLE_APP_INTERACTIVE_MODE;

        if (setMidAirMode)
        {
            modeToSwitch = GroundPlaneRenderer::SampleAppMode::SAMPLE_APP_MIDAIR_MODE;
        }

        m_renderer->SetPlacementMode(modeToSwitch);
    }
}
