/*===============================================================================
Copyright (c) 2020 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/
#pragma once

#include "Common/StepTimer.h"
#include "Common/DeviceResources.h"
#include "SampleApplication/AppSession.h"
#include "Features/GroundPlane/GroundPlaneRenderer.h"

// Renders Direct2D and 3D content on the screen.
namespace GroundPlane
{
    class GroundPlaneMain : public DX::IDeviceNotify
    {
    public:
        GroundPlaneMain(
            const std::shared_ptr<DX::DeviceResources>& deviceResources,
            const std::shared_ptr<VuforiaSamples::AppSession>& appSession,
            GroundPlaneUIControl^ groundPlaneUIControl
        );
        ~GroundPlaneMain();
        void CreateWindowSizeDependentResources();
        void StartRenderLoop();
        void StopRenderLoop();
        Concurrency::critical_section& GetCriticalSection() { return m_criticalSection; }

        // IDeviceNotify
        virtual void OnDeviceLost();
        virtual void OnDeviceRestored();

        void OnTapGesture();
        void OnPlacementModeChanged(bool setMidAirMode);

        // Reset app state including anchors
        void Reset();

        SampleCommon::StepTimer& GetTimer() { return m_timer; }

        GroundPlaneRenderer* GetRenderer() { return m_renderer.get(); }

    private:
        void ProcessInput();
        void Update();
        bool Render();

        // Cached pointer to device resources.
        std::shared_ptr<DX::DeviceResources> m_deviceResources;

        // Sample App Session
        std::shared_ptr<VuforiaSamples::AppSession> m_appSession;
        const GroundPlaneUIControl^ m_groundPlaneUIControl;

        // Image Targets scene renderer
        std::shared_ptr<GroundPlaneRenderer> m_renderer;

        Windows::Foundation::IAsyncAction^ m_renderLoopWorker;
        Concurrency::critical_section m_criticalSection;

        // Rendering loop timer.
        SampleCommon::StepTimer m_timer;

        // Flag to reset trackers and anchors
        bool m_ResetStateAndTrackers;
    };
}
