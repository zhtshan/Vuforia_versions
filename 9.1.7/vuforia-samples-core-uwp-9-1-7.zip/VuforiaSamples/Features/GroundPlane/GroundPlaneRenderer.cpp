/*===============================================================================
Copyright (c) 2020 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

#include "pch.h"
#include "GroundPlaneRenderer.h"
#include "Common/DirectXHelper.h"
#include "Common/SampleAppMathUtils.h"
#include "Common/SampleUtil.h"
#include "Common/RenderUtil.h"

#include <Vuforia/Vuforia.h>
#include <Vuforia/UWP/Vuforia_UWP.h>
#include <Vuforia/AnchorResult.h>
#include <Vuforia/CameraDevice.h>
#include <Vuforia/Device.h>
#include <Vuforia/DeviceTrackableResult.h>
#include <Vuforia/DeviceTracker.h>
#include <Vuforia/UWP/DXRenderer.h>
#include <Vuforia/Renderer.h>
#include <Vuforia/Tool.h>
#include <Vuforia/VideoBackgroundConfig.h>
#include <Vuforia/VideoBackgroundTextureInfo.h>
#include <Vuforia/HitTestResult.h>
#include <Vuforia/PositionalDeviceTracker.h>
#include <Vuforia/SmartTerrain.h>
#include <Vuforia/TrackerManager.h>
#include <Vuforia/State.h>
#include <Vuforia/StateUpdater.h>
#include <Vuforia/Trackable.h>
#include <Vuforia/TrackableResult.h>
#include <Vuforia/Tracker.h>
#include <Vuforia/ImageTarget.h>

using namespace GroundPlane;
using namespace DirectX;
using namespace Windows::Foundation;
using namespace Microsoft::WRL;

namespace
{
    Platform::String^ LOGTAG = "GroundPlaneRenderer";

    static const float OBJECT_SCALE = 10.0f;
    static const float VIRTUAL_FOV_Y_DEGS = 85.0f;

    // Define a default, assumed device height above the plane where you'd like to place content.
    // The world coordinate system will be scaled accordingly to meet this device height value
    // once you create the first successful anchor from a HitTestResult. If your users are adults
    // to place something on the floor use appx. 1.4m. For a tabletop experience use appx. 0.5m.
    // In apps targeted for kids reduce the assumptions to ~80% of these values.
    static const float DEFAULT_HEIGHT_ABOVE_GROUND = 1.4f;

    const std::wstring RES_PATH_SHADER_TEXTURED_VS = L"TexturedVertexShader.cso";
    const std::wstring RES_PATH_SHADER_TEXTURED_PS = L"TexturedPixelShader.cso";
    const std::wstring RES_PATH_SHADER_VIDEO_BKGD_VS = L"VideoBackgroundVertexShader.cso";
    const std::wstring RES_PATH_SHADER_VIDEO_BKGD_PS = L"VideoBackgroundPixelShader.cso";

    const char RES_PATH_MODEL_ASTRONAUT[] = "Assets/GroundPlane/Model_Astronaut.txt";
    const char RES_PATH_MODEL_DRONE[] = "Assets/GroundPlane/Model_Drone.txt";
    const char RES_PATH_MODEL_PLANE[] = "Assets/GroundPlane/Model_Plane.txt";

    const wchar_t RES_PATH_TEXTURE_ASTRONAUT[] = L"Assets/GroundPlane/astronaut.png";
    const wchar_t RES_PATH_TEXTURE_DRONE[] = L"Assets/GroundPlane/drone.png";
    const wchar_t RES_PATH_TEXTURE_RETICLE_2D[] = L"Assets/GroundPlane/reticle_interactive_2d.png";
    const wchar_t RES_PATH_TEXTURE_RETICLE_3D[] = L"Assets/GroundPlane/reticle_interactive_3d.png";
    const wchar_t RES_PATH_TEXTURE_RETICLE_MIDAIR[] = L"Assets/GroundPlane/reticle_midair.png";
}

const char* GroundPlaneRenderer::MID_AIR_ANCHOR_NAME = "midAirAnchor";
const char* GroundPlaneRenderer::HIT_TEST_ANCHOR_NAME = "hitTestAnchor";


// Loads vertex and pixel shaders from files, create the teapot mesh and load the textures.
GroundPlaneRenderer::GroundPlaneRenderer(const std::shared_ptr<DX::DeviceResources>& deviceResources,
    GroundPlaneUIControl^ groundPlaneUIControl) :
    m_deviceResources(deviceResources),
    m_groundPlaneUIControl(groundPlaneUIControl),
    m_rendererInitialized(false),
    m_vuforiaInitialized(false),
    m_vuforiaStarted(false),
    m_createNewAnchor(false)
{
    CreateDeviceDependentResources();
    CreateWindowSizeDependentResources();

    XMStoreFloat4x4(&m_devicePoseMatrix, XMMatrixIdentity());
    XMStoreFloat4x4(&m_hitTestPoseMatrix, XMMatrixIdentity());
    XMStoreFloat4x4(&m_midAirPoseMatrix, XMMatrixIdentity());
    XMStoreFloat4x4(&m_reticlePose, XMMatrixIdentity());
}

void GroundPlaneRenderer::SetVuforiaStarted(bool started)
{
    m_vuforiaStarted = started;
    if (started) {
        UpdateRenderingPrimitives();
    }
    else
    {
        m_videoBackground->SetVideoBackgroundTexture();
    }
}

// Initializes view parameters when the window size changes.
void GroundPlaneRenderer::CreateWindowSizeDependentResources()
{
    if (m_vuforiaStarted)
    {
        UpdateRenderingPrimitives();
    }
}

void GroundPlaneRenderer::UpdateRenderingPrimitives()
{
    Concurrency::critical_section::scoped_lock lock(m_renderingPrimitivesLock);
    if (m_renderingPrimitives != nullptr)
    {
        m_renderingPrimitives.reset();
    }
    m_renderingPrimitives = std::shared_ptr<Vuforia::RenderingPrimitives>(
        new Vuforia::RenderingPrimitives(Vuforia::Device::getInstance().getRenderingPrimitives())
        );

    m_videoBackground->ResetForNewRenderingPrimitives();
}

// Set flag to create a new anchor
void GroundPlaneRenderer::SetNewAnchor(float normalizedTouchPointX, float normalizedTouchPointY)
{
    m_createNewAnchor = true;
}

bool GroundPlaneRenderer::PerformHitTest(
    float normalizedTouchPointX,
    float normalizedTouchPointY,
    float deviceHeightInMeters,
    bool createAnchor,
    const Vuforia::State& state)
{
    Vuforia::TrackerManager& trackerManager = Vuforia::TrackerManager::getInstance();
    Vuforia::PositionalDeviceTracker* deviceTracker = static_cast<Vuforia::PositionalDeviceTracker*>
        (trackerManager.getTracker(Vuforia::PositionalDeviceTracker::getClassType()));
    Vuforia::SmartTerrain* smartTerrain = static_cast<Vuforia::SmartTerrain*>
        (trackerManager.getTracker(Vuforia::SmartTerrain::getClassType()));

    if (deviceTracker == nullptr || smartTerrain == nullptr)
    {
        SampleCommon::SampleUtil::Log(LOGTAG, "Failed to perform hit test, trackers not initialized");
        return false;
    }

    Vuforia::Vec2F hitTestPoint(normalizedTouchPointX, normalizedTouchPointY);
    Vuforia::SmartTerrain::HITTEST_HINT hitTestHint = Vuforia::SmartTerrain::HITTEST_HINT_NONE; // hit test hint is currently unused

    // A hit test is performed for a given State at normalized screen coordinates.
    // The deviceHeight is an developer provided assumption as explained on
    // definition of DEFAULT_HEIGHT_ABOVE_GROUND.
    const auto& hitTestResults = smartTerrain->hitTest(hitTestPoint, hitTestHint, state, deviceHeightInMeters);
    if (!hitTestResults.empty())
    {
        // Use first HitTestResult
        const Vuforia::HitTestResult* hitTestResult = hitTestResults.at(0);

        if (createAnchor && m_currentMode == SampleAppMode::SAMPLE_APP_INTERACTIVE_MODE)
        {
            // Destroy previous hit test anchor if needed
            if (m_hitTestAnchor != nullptr)
            {
                SampleCommon::SampleUtil::Log(LOGTAG, "Destroying anchor with name '" + SampleCommon::SampleUtil::ToPlatformString(HIT_TEST_ANCHOR_NAME) + "'");
                bool result = deviceTracker->destroyAnchor(m_hitTestAnchor);
                SampleCommon::SampleUtil::Log(LOGTAG, SampleCommon::SampleUtil::ToPlatformString(result ? "Successfully destroyed" : "Failed to destroy") + " hit test anchor");
            }

            m_hitTestAnchor = deviceTracker->createAnchor(HIT_TEST_ANCHOR_NAME, *hitTestResult);
            if (m_hitTestAnchor != nullptr)
            {
                SampleCommon::SampleUtil::Log(LOGTAG, "Successfully created hit test anchor with name '" + SampleCommon::SampleUtil::ToPlatformString(m_hitTestAnchor->getName()) + "'");

                m_groundPlaneUIControl->SetMidAirModeEnabled(true);
            }
            else
            {
                SampleCommon::SampleUtil::Log(LOGTAG, "Failed to create hit test anchor");
            }
        }

        auto poseGL = Vuforia::Tool::convertPose2GLMatrix(hitTestResult->getPose());
        XMFLOAT4X4 poseDX;
        memcpy(poseDX.m, poseGL.data, sizeof(float) * 16);
        XMStoreFloat4x4(&m_reticlePose, XMMatrixTranspose(XMLoadFloat4x4(&poseDX)));
        return true;
    }
    else
    {
        return false;
    }
}

void GroundPlaneRenderer::ResetGroundPlaneStateAndAnchors()
{
    m_currentMode = SampleAppMode::SAMPLE_APP_INTERACTIVE_MODE;
    XMStoreFloat4x4(&m_devicePoseMatrix, XMMatrixIdentity());
    XMStoreFloat4x4(&m_hitTestPoseMatrix, XMMatrixIdentity());
    XMStoreFloat4x4(&m_midAirPoseMatrix, XMMatrixIdentity());
    XMStoreFloat4x4(&m_reticlePose, XMMatrixIdentity());

    ResetTrackers();

    m_groundPlaneUIControl->SetMidAirModeEnabled(false);
}

void GroundPlaneRenderer::ResetTrackers()
{
    Vuforia::TrackerManager& trackerManager = Vuforia::TrackerManager::getInstance();
    Vuforia::PositionalDeviceTracker* deviceTracker = static_cast<Vuforia::PositionalDeviceTracker*>
        (trackerManager.getTracker(Vuforia::PositionalDeviceTracker::getClassType()));
    Vuforia::SmartTerrain* smartTerrain = static_cast<Vuforia::SmartTerrain*>
        (trackerManager.getTracker(Vuforia::SmartTerrain::getClassType()));

    if (deviceTracker == nullptr || smartTerrain == nullptr)
    {
        SampleCommon::SampleUtil::Log(LOGTAG, "Failed to reset trackers, trackers not initialized");
        return;
    }

    // Anchor not valid anymore after stop() call, anchor poses should be discarded
    if (m_hitTestAnchor != nullptr)
    {
        deviceTracker->destroyAnchor(m_hitTestAnchor);
        m_hitTestAnchor = nullptr;
    }

    if (m_midAirAnchor != nullptr)
    {
        deviceTracker->destroyAnchor(m_midAirAnchor);
        m_midAirAnchor = nullptr;
    }

    smartTerrain->stop();
    smartTerrain->start();
    deviceTracker->reset();
}

void GroundPlaneRenderer::SetPlacementMode(SampleAppMode newPlacementMode)
{
    m_currentMode = newPlacementMode;
}


void GroundPlaneRenderer::SetTrackingStatus(const Vuforia::List<const Vuforia::TrackableResult> trackableResultList)
{
    // Check if any targets are being tracked
    for (const auto& result : trackableResultList)
    {
        if (!result->isOfType(Vuforia::DeviceTrackableResult::getClassType()))
        {
            int trackingStatus = result->getStatus();
            int trackingStatusInfo = result->getStatusInfo();

            if (trackingStatus == Vuforia::TrackableResult::STATUS::TRACKED ||
                trackingStatusInfo == Vuforia::TrackableResult::STATUS_INFO::NORMAL)
            {
                m_targetCurrentlyTracked = true;
                return;
            }
        }
    }

    m_targetCurrentlyTracked = false;
}

bool GroundPlaneRenderer::IsTargetCurrentlyTracked()
{
    return m_targetCurrentlyTracked;
}

// Called once per frame
void GroundPlaneRenderer::Update(SampleCommon::StepTimer const& timer)
{
}

// Renders one frame using the vertex and pixel shaders.
void GroundPlaneRenderer::Render()
{
    // Vuforia initialization and data loading is asynchronous.
    // Only starts rendering after Vuforia init/loading is complete.
    if (!m_rendererInitialized || !m_vuforiaStarted)
    {
        return;
    }

    // Get the state from Vuforia and mark the beginning of a rendering section
    Vuforia::DXRenderData dxRenderData(m_deviceResources->GetD3DDevice());
    const Vuforia::State state = Vuforia::TrackerManager::getInstance().getStateUpdater().updateState();

    Vuforia::Renderer &vuforiaRenderer = Vuforia::Renderer::getInstance();
    vuforiaRenderer.begin(state, &dxRenderData);

    if (m_createNewAnchor)
    {
        Vuforia::TrackableResult::STATUS deviceTrackerStatus = Vuforia::TrackableResult::NO_POSE;
        Vuforia::TrackableResult::STATUS_INFO deviceTrackerStatusInfo = Vuforia::TrackableResult::UNKNOWN;

        if (state.getDeviceTrackableResult() != nullptr)
        {
            deviceTrackerStatus = state.getDeviceTrackableResult()->getStatus();
            deviceTrackerStatusInfo = state.getDeviceTrackableResult()->getStatusInfo();
        }

        bool allowAnchorCreation = 
            (deviceTrackerStatus == Vuforia::DeviceTrackableResult::STATUS::TRACKED ||
                deviceTrackerStatus == Vuforia::DeviceTrackableResult::STATUS::EXTENDED_TRACKED) &&
                (deviceTrackerStatusInfo == Vuforia::DeviceTrackableResult::STATUS_INFO::NORMAL);
        bool allowMidAirAnchorCreation = allowAnchorCreation;

        if (m_currentMode == SampleAppMode::SAMPLE_APP_INTERACTIVE_MODE)
        {
            if (allowAnchorCreation)
            {
                PerformHitTest(0.5f, 0.5f, DEFAULT_HEIGHT_ABOVE_GROUND, true, state);
            }
            else
            {
                SampleCommon::SampleUtil::Log(LOGTAG, "Ground anchor not created. Tracking requirements not met.");
                m_groundPlaneUIControl->UpdateInstructionText(GroundPlane::Instruction::MOVE_TO_PLACE_ANCHOR);
            }
        }
        else
        {
            if (allowMidAirAnchorCreation)
            {
                Vuforia::Matrix34F midAirPose = m_devicePoseMatrix34F;

                // Matrix to translate augmentation at a given distance in front of the camera
                Vuforia::Matrix34F translationMat;
                translationMat.data[0] = 1;
                translationMat.data[5] = 1;
                translationMat.data[10] = 1;
                Vuforia::Tool::setTranslation(translationMat, Vuforia::Vec3F(0, 0, -3));

                midAirPose = Vuforia::Tool::multiply(midAirPose, translationMat);

                // We remove the orientation from the device pose to create the anchor
                midAirPose.data[0] = 1;
                midAirPose.data[1] = 0;
                midAirPose.data[2] = 0;

                midAirPose.data[4] = 0;
                midAirPose.data[5] = 1;
                midAirPose.data[6] = 0;

                midAirPose.data[8] = 0;
                midAirPose.data[9] = 0;
                midAirPose.data[10] = 1;

                // Create mid air anchor
                CreateMidAirAnchorWithPose(midAirPose);
            }
            else
            {
                SampleCommon::SampleUtil::Log(LOGTAG, "Mid-Air anchor not created. Tracking requirements not met.");
                m_groundPlaneUIControl->UpdateInstructionText(GroundPlane::Instruction::MOVE_TO_PLACE_ANCHOR);
            }
        }
        m_createNewAnchor = false;
    }

    RenderScene(vuforiaRenderer, state);

    vuforiaRenderer.end();
}

void GroundPlaneRenderer::RenderScene(Vuforia::Renderer &renderer, const Vuforia::State &state)
{
    Concurrency::critical_section::scoped_lock lock(m_renderingPrimitivesLock);

    bool renderHitTestAugmentation = false;
    bool renderMidAirAugmentation = false;
    auto context = m_deviceResources->GetD3DDeviceContext();

    // Calculate the DX Projection matrix using the current Vuforia state
    auto projectionMatrix = Vuforia::Tool::convertPerspectiveProjection2GLMatrix(
        m_renderingPrimitives->getProjectionMatrix(Vuforia::VIEW_SINGULAR, state.getCameraCalibration()),
        m_near, m_far);

    XMFLOAT4X4 dxProjection;
    memcpy(dxProjection.m, projectionMatrix.data, sizeof(float) * 16);
    XMStoreFloat4x4(&dxProjection, XMMatrixTranspose(XMLoadFloat4x4(&dxProjection)));

    XMMATRIX xmProjectionMatrix = XMLoadFloat4x4(&dxProjection);

    // Render the camera video background
    m_videoBackground->Render(renderer, m_renderingPrimitives.get(), Vuforia::VIEW_SINGULAR, state);

    // Setup rendering pipeline for augmentation rendering
    context->RSSetState(m_augmentationRasterStateCullBack.Get()); // Typically when using the rear facing camera

    context->OMSetDepthStencilState(m_augmentationDepthStencilState.Get(), 1);
    context->OMSetBlendState(m_augmentationBlendState.Get(), NULL, 0xffffffff);

    Vuforia::Matrix44F devicePoseTemp;

    const auto& trackableResultList = state.getTrackableResults();

    SetTrackingStatus(trackableResultList);

    for (const auto& result : trackableResultList)
    {
        const Vuforia::Trackable &trackable = result->getTrackable();
        const char* trackableName = trackable.getName();

        Vuforia::Matrix44F modelViewMatrix = Vuforia::Tool::convertPose2GLMatrix(result->getPose());
        if (result->isOfType(Vuforia::DeviceTrackableResult::getClassType()))
        {
            m_devicePoseMatrix34F = result->getPose();
            devicePoseTemp = SampleAppMathUtils::Matrix44FTranspose(SampleAppMathUtils::Matrix44FInverse(modelViewMatrix));
            SampleAppMathUtils::convertPoseFromGLtoDX(devicePoseTemp, m_devicePoseMatrix);

            m_groundPlaneUIControl->UpdateTrackingStatusInfo(static_cast<int> (result->getStatusInfo()));
        }
        else if (result->isOfType(Vuforia::AnchorResult::getClassType()))
        {
            if (!strcmp(result->getTrackable().getName(), HIT_TEST_ANCHOR_NAME))
            {
                //SampleCommon::SampleUtil::Log(LOGTAG, "Hit test anchor tracked");
                SampleAppMathUtils::convertPoseFromGLtoDX(modelViewMatrix, m_hitTestPoseMatrix);

                renderHitTestAugmentation = true;
            }

            if (!strcmp(result->getTrackable().getName(), MID_AIR_ANCHOR_NAME))
            {
                //SampleCommon::SampleUtil::Log(LOGTAG, "Mid air anchor tracked");
                SampleAppMathUtils::convertPoseFromGLtoDX(modelViewMatrix, m_midAirPoseMatrix);

                renderMidAirAugmentation = true;
            }
        }
    }

    // Render reticle
    bool isHitTestAvailable = false;

    if (renderHitTestAugmentation)
    {
        std::shared_ptr<SampleCommon::Texture> texture = GetAugmentationTexture(GroundPlaneRenderer::HIT_TEST_ANCHOR_NAME);
        if (!texture->IsInitialized())
        {
            texture->Init();
        }

        XMMATRIX modelViewMatrix = DirectX::XMMatrixMultiply(XMLoadFloat4x4(&m_devicePoseMatrix), XMLoadFloat4x4(&m_hitTestPoseMatrix));

        // We rotate 90 degrees on X axis
        const XMFLOAT3 xAxis = { 1.0f, 0.0f, 0.0f };
        modelViewMatrix = XMMatrixMultiply(modelViewMatrix, XMMatrixRotationAxis(XMLoadFloat3(&xAxis), M_PI / 2));

        const auto scale = XMMatrixScaling(OBJECT_SCALE, OBJECT_SCALE, OBJECT_SCALE);
        const auto rotation = XMMatrixTranspose(XMMatrixRotationX(3.14159f / 2));
        modelViewMatrix = modelViewMatrix * rotation * scale;

        Render3DModel(modelViewMatrix, xmProjectionMatrix, texture, m_astroModel, false);
    }

    if (renderMidAirAugmentation)
    {
        std::shared_ptr<SampleCommon::Texture> texture = GetAugmentationTexture(GroundPlaneRenderer::MID_AIR_ANCHOR_NAME);
        if (!texture->IsInitialized())
        {
            texture->Init();
        }

        XMMATRIX modelViewMatrix = DirectX::XMMatrixMultiply(XMLoadFloat4x4(&m_devicePoseMatrix), XMLoadFloat4x4(&m_midAirPoseMatrix));

        // We rotate the teapot 90 degrees on X axis
        XMFLOAT3 xAxis = { 1.0f, 0.0f, 0.0f };
        modelViewMatrix = XMMatrixMultiply(modelViewMatrix, XMMatrixRotationAxis(XMLoadFloat3(&xAxis), M_PI / 2));

        auto scale = XMMatrixScaling(OBJECT_SCALE, OBJECT_SCALE, OBJECT_SCALE);
        auto rotation = XMMatrixTranspose(XMMatrixRotationX(3.14159f / 2));
        auto translation = XMMatrixTranspose(XMMatrixTranslation(0, -0.13f, 0));
        modelViewMatrix = modelViewMatrix * rotation * scale * translation;

        Render3DModel(modelViewMatrix, xmProjectionMatrix, texture, m_droneModel, false);
    }

    Vuforia::TrackableResult::STATUS deviceTrackerStatus = Vuforia::TrackableResult::NO_POSE;
    Vuforia::TrackableResult::STATUS_INFO deviceTrackerStatusInfo = Vuforia::TrackableResult::UNKNOWN;

    if (state.getDeviceTrackableResult() != nullptr)
    {
        deviceTrackerStatus = state.getDeviceTrackableResult()->getStatus();
        deviceTrackerStatusInfo = state.getDeviceTrackableResult()->getStatusInfo();
    }

    bool allowAnchorCreation =
         (deviceTrackerStatus == Vuforia::DeviceTrackableResult::STATUS::TRACKED ||
          deviceTrackerStatus == Vuforia::DeviceTrackableResult::STATUS::EXTENDED_TRACKED) &&
         (deviceTrackerStatusInfo == Vuforia::DeviceTrackableResult::STATUS_INFO::NORMAL);

    //Render 3D reticle when we have a hit test result
    if (m_currentMode == SampleAppMode::SAMPLE_APP_INTERACTIVE_MODE)
    {
        std::shared_ptr<SampleCommon::Texture> texture = m_texture3DReticle;
        if (!texture->IsInitialized())
        {
            texture->Init();
        }

        isHitTestAvailable = PerformHitTest(0.5f, 0.5f, DEFAULT_HEIGHT_ABOVE_GROUND, false, state);

        if (isHitTestAvailable)
        {
            XMMATRIX modelViewMatrix = DirectX::XMMatrixMultiply(XMLoadFloat4x4(&m_devicePoseMatrix), XMLoadFloat4x4(&m_reticlePose));

            // We rotate 90 degrees on X axis
            XMFLOAT3 xAxis = { 1.0f, 0.0f, 0.0f };
            modelViewMatrix = XMMatrixMultiply(modelViewMatrix, XMMatrixRotationAxis(XMLoadFloat3(&xAxis), M_PI / 2));

            Render3DModel(modelViewMatrix, xmProjectionMatrix, texture, m_planeModel, true);

            if (allowAnchorCreation)
            {
                m_groundPlaneUIControl->UpdateInstructionText(GroundPlane::Instruction::TAP_TO_PLACE);
            }
        }
    }

            // Draw 2D reticle if in mid air mode or if there is no hit test result
    if (m_currentMode == SampleAppMode::SAMPLE_APP_MIDAIR_MODE || !isHitTestAvailable)
    {
        std::shared_ptr<SampleCommon::Texture> texture = (m_currentMode == SampleAppMode::SAMPLE_APP_MIDAIR_MODE) ? m_textureMidAirReticle : m_texture2DReticle;
        if (!texture->IsInitialized())
        {
            texture->Init();
        }
        
        const float orthoScale = 1.0f;
        const float aspectRatio = m_deviceResources->GetOutputSize().Width / m_deviceResources->GetOutputSize().Height;
        const XMMATRIX orthoMatrix = XMMatrixOrthographicOffCenterLH(aspectRatio * -orthoScale, aspectRatio * orthoScale, -orthoScale, orthoScale, 1.0f, -1.0f);
        XMMATRIX modelViewMatrix = XMMatrixIdentity();

        if (m_currentMode == SampleAppMode::SAMPLE_APP_MIDAIR_MODE)
        {
            if (allowAnchorCreation)
            {
                m_groundPlaneUIControl->UpdateInstructionText(GroundPlane::Instruction::TAP_TO_PLACE);
            }
        }
        else if (!isHitTestAvailable)
        {
            m_groundPlaneUIControl->UpdateInstructionText(GroundPlane::Instruction::POINT_TO_GROUND);
        }

        Render3DModel(modelViewMatrix, orthoMatrix, texture, m_planeModel, true);
    }
}

void GroundPlaneRenderer::CreateMidAirAnchorWithPose(Vuforia::Matrix34F& anchorPoseMatrix)
{
    SampleCommon::SampleUtil::Log(LOGTAG, "createMidAirAnchor");

    Vuforia::TrackerManager& trackerManager = Vuforia::TrackerManager::getInstance();
    Vuforia::PositionalDeviceTracker* deviceTracker = static_cast<Vuforia::PositionalDeviceTracker*> (trackerManager.getTracker(Vuforia::PositionalDeviceTracker::getClassType()));

    if (m_midAirAnchor != nullptr)
    {
        Platform::String ^msgString = "Destroying anchor with name '" + SampleCommon::SampleUtil::ToPlatformString(MID_AIR_ANCHOR_NAME) + "'";
        SampleCommon::SampleUtil::Log(LOGTAG, msgString);
        bool result = deviceTracker->destroyAnchor(m_midAirAnchor);
        SampleCommon::SampleUtil::Log(LOGTAG, (result ? "Successfully destroyed" : "Failed to destroy") + " anchor");
    }

    m_midAirAnchor = deviceTracker->createAnchor(MID_AIR_ANCHOR_NAME, anchorPoseMatrix);

    if (m_midAirAnchor != nullptr)
    {
        SampleCommon::SampleUtil::Log(LOGTAG, "Successfully created anchor with name '" + SampleCommon::SampleUtil::ToPlatformString(m_midAirAnchor->getName()) + "'");
    }
    else
    {
        SampleCommon::SampleUtil::Log(LOGTAG, "Failed to create anchor");
    }
}

void GroundPlaneRenderer::Render3DModel(
    const XMMATRIX &poseMatrix,
    const XMMATRIX &projectionMatrix,
    const std::shared_ptr<SampleCommon::Texture> texture,
    const std::shared_ptr<SampleCommon::SampleApp3DModel> model,
    const bool enableTransparency
)
{
    auto context = m_deviceResources->GetD3DDeviceContext();

    // Set pose matrix (the 'view' part of the 'model-view' matrix)
    XMStoreFloat4x4(&m_augmentationConstantBufferData.view, poseMatrix);

    // Set model matrix (the 'model' part of the 'model-view' matrix)
    XMStoreFloat4x4(&m_augmentationConstantBufferData.model, XMMatrixIdentity());

    // Set projection matrix
    XMStoreFloat4x4(&m_augmentationConstantBufferData.projection, projectionMatrix);

    // Prepare the constant buffer to send it to the graphics device.
    context->UpdateSubresource1(
        m_augmentationConstantBuffer.Get(),
        0,
        NULL,
        &m_augmentationConstantBufferData,
        0,
        0,
        0
    );

    // Each vertex is one instance of the TexturedVertex struct.
    UINT stride = sizeof(SampleCommon::TexturedVertex);
    UINT offset = 0;
    context->IASetVertexBuffers(
        0,
        1,
        model->GetVertexBuffer().GetAddressOf(),
        &stride,
        &offset
    );

    context->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

    context->IASetInputLayout(m_augmentationInputLayout.Get());

    if (enableTransparency)
    {
        context->OMSetBlendState(m_reticleBlendState.Get(), NULL, 0xffffffff);
    }

    // Attach our vertex shader.
    context->VSSetShader(m_augmentationVertexShader.Get(), nullptr, 0);

    // Send the constant buffer to the graphics device.
    context->VSSetConstantBuffers1(
        0,
        1,
        m_augmentationConstantBuffer.GetAddressOf(),
        nullptr,
        nullptr
    );

    // Attach our pixel shader.
    context->PSSetShader(m_augmentationPixelShader.Get(), nullptr, 0);

    context->PSSetSamplers(0, 1, texture->GetD3DSamplerState().GetAddressOf());
    context->PSSetShaderResources(0, 1, texture->GetD3DTextureView().GetAddressOf());

    // Draw the objects.
    context->Draw(model->GetVertexCount(), 0);
}

const std::shared_ptr<SampleCommon::Texture> GroundPlaneRenderer::GetAugmentationTexture(const char *targetName)
{
    // Choose the texture based on the target name:
    if (strcmp(targetName, GroundPlaneRenderer::HIT_TEST_ANCHOR_NAME) == 0)
    {
        return m_textureAstronaut;
    }
    else
    {
        return m_textureDrone;
    }
}

void GroundPlaneRenderer::CreateDeviceDependentResources()
{
    m_rendererInitialized = false;

    m_videoBackground = std::shared_ptr<SampleCommon::VideoBackground>(
        new SampleCommon::VideoBackground(m_deviceResources));

    // Load shaders asynchronously.
    auto loadVSTask = DX::ReadDataAsync(RES_PATH_SHADER_TEXTURED_VS);
    auto loadPSTask = DX::ReadDataAsync(RES_PATH_SHADER_TEXTURED_PS);
    auto loadVideoBgVSTask = DX::ReadDataAsync(RES_PATH_SHADER_VIDEO_BKGD_VS);
    auto loadVideoBgPSTask = DX::ReadDataAsync(RES_PATH_SHADER_VIDEO_BKGD_PS);

    // After the vertex shader file is loaded, create the shader and input layout.
    auto createVSTask = loadVSTask.then([this](const std::vector<byte>& fileData) {
        DX::ThrowIfFailed(
            m_deviceResources->GetD3DDevice()->CreateVertexShader(
                &fileData[0],
                fileData.size(),
                nullptr,
                &m_augmentationVertexShader
            )
        );

        static const D3D11_INPUT_ELEMENT_DESC vertexDesc[] =
        {
            { "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 0, D3D11_INPUT_PER_VERTEX_DATA, 0 },
            { "TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT, 0, 12, D3D11_INPUT_PER_VERTEX_DATA, 0 },
        };

        DX::ThrowIfFailed(
            m_deviceResources->GetD3DDevice()->CreateInputLayout(
                vertexDesc,
                ARRAYSIZE(vertexDesc),
                &fileData[0],
                fileData.size(),
                &m_augmentationInputLayout
            )
        );
    });

    auto createVideoBgVSTask = loadVideoBgVSTask.then([this](const std::vector<byte>& fileData) {
        m_videoBackground->InitVertexShader(&fileData[0], fileData.size());
    });

    // After the pixel shader file is loaded, create the shader and constant buffer.
    auto createPSTask = loadPSTask.then([this](const std::vector<byte>& fileData) {
        DX::ThrowIfFailed(
            m_deviceResources->GetD3DDevice()->CreatePixelShader(
                &fileData[0],
                fileData.size(),
                nullptr,
                &m_augmentationPixelShader
            )
        );

        CD3D11_BUFFER_DESC constantBufferDesc(
            sizeof(SampleCommon::ModelViewProjectionConstantBuffer),
            D3D11_BIND_CONSTANT_BUFFER);

        DX::ThrowIfFailed(
            m_deviceResources->GetD3DDevice()->CreateBuffer(
                &constantBufferDesc,
                nullptr,
                &m_augmentationConstantBuffer
            )
        );
    });

    // After the pixel shader file is loaded, create the shader and constant buffer.
    auto createVideoBgPSTask = loadVideoBgPSTask.then([this](const std::vector<byte>& fileData) {
        m_videoBackground->InitFragmentShader(&fileData[0], fileData.size());
    });

    // Once both shaders are loaded, create the mesh.
    auto createAugmentationModelsTask = (
        createPSTask &&
        createVSTask &&
        createVideoBgPSTask &&
        createVideoBgVSTask).then([this]()
    {
        m_astroModel = std::make_shared<SampleCommon::SampleApp3DModel>(m_deviceResources, RES_PATH_MODEL_ASTRONAUT);
        m_droneModel = std::make_shared<SampleCommon::SampleApp3DModel>(m_deviceResources, RES_PATH_MODEL_DRONE);
        m_planeModel = std::make_shared<SampleCommon::SampleApp3DModel>(m_deviceResources, RES_PATH_MODEL_PLANE);

        m_astroModel->InitMesh();
        m_droneModel->InitMesh();
        m_planeModel->InitMesh();
    });

    auto createTextureTask = createAugmentationModelsTask.then([this]()
    {
        m_textureAstronaut = std::make_shared<SampleCommon::Texture>(m_deviceResources);
        m_textureDrone = std::make_shared<SampleCommon::Texture>(m_deviceResources);
        m_texture2DReticle = std::make_shared<SampleCommon::Texture>(m_deviceResources);
        m_texture3DReticle = std::make_shared<SampleCommon::Texture>(m_deviceResources);
        m_textureMidAirReticle = std::make_shared<SampleCommon::Texture>(m_deviceResources);

        m_textureAstronaut->CreateFromFile(RES_PATH_TEXTURE_ASTRONAUT);
        m_textureDrone->CreateFromFile(RES_PATH_TEXTURE_DRONE);
        m_texture2DReticle->CreateFromFile(RES_PATH_TEXTURE_RETICLE_2D);
        m_texture3DReticle->CreateFromFile(RES_PATH_TEXTURE_RETICLE_3D);
        m_textureMidAirReticle->CreateFromFile(RES_PATH_TEXTURE_RETICLE_MIDAIR);
    });

    auto setupRasterizersTask = createTextureTask.then([this]() {
        // setup the rasterizer
        auto context = m_deviceResources->GetD3DDeviceContext();

        ID3D11Device *device;
        context->GetDevice(&device);

        // Init rendering pipeline state for video background
        m_videoBackground->InitRenderState();

        // Create the rasterizer for augmentation rendering
        // with back-face culling
        D3D11_RASTERIZER_DESC augmentationRasterDescCullBack = SampleCommon::RenderUtil::CreateRasterizerDesc(
            D3D11_FILL_SOLID, // solid rendering
            D3D11_CULL_BACK, // culling
            true, // Counter clockwise front face
            true // depth clipping enabled
        );
        device->CreateRasterizerState(&augmentationRasterDescCullBack, m_augmentationRasterStateCullBack.GetAddressOf());

        // Create Depth-Stencil State with depth testing ON,
        // for augmentation rendering
        D3D11_DEPTH_STENCIL_DESC augmentDepthStencilDesc = SampleCommon::RenderUtil::CreateDepthStencilDesc(
            true,
            D3D11_DEPTH_WRITE_MASK_ALL,
            D3D11_COMPARISON_LESS
        );
        device->CreateDepthStencilState(&augmentDepthStencilDesc, m_augmentationDepthStencilState.GetAddressOf());

        // Create blend state for augmentation rendering
        bool translucentAugmentation = false;// set to TRUE for rendering translucent models
        D3D11_BLEND_DESC augmentationBlendDesc = SampleCommon::RenderUtil::CreateBlendDesc(translucentAugmentation);
        device->CreateBlendState(&augmentationBlendDesc, m_augmentationBlendState.GetAddressOf());

        D3D11_BLEND_DESC planeBlendDesc = SampleCommon::RenderUtil::CreateBlendDesc(true);
        device->CreateBlendState(&planeBlendDesc, m_reticleBlendState.GetAddressOf());
    });

    setupRasterizersTask.then([this](Concurrency::task<void> t) {
        try
        {
            // If any exceptions were thrown back in the async chain then
            // this call throws that exception here and we can catch it below
            t.get();

            // Now we are ready for rendering
            m_rendererInitialized = true;
        }
        catch (Platform::Exception ^ex) {
            SampleCommon::SampleUtil::ShowError(L"Renderer init error", ex->Message);
        }
    });
}

void GroundPlaneRenderer::ReleaseDeviceDependentResources()
{
    m_rendererInitialized = false;

    m_videoBackground->ReleaseResources();
    m_videoBackground.reset();

    m_augmentationInputLayout.Reset();
    m_augmentationVertexShader.Reset();
    m_augmentationPixelShader.Reset();
    m_augmentationConstantBuffer.Reset();

    m_droneModel->ReleaseResources();
    m_astroModel->ReleaseResources();
    m_planeModel->ReleaseResources();
    m_textureAstronaut->ReleaseResources();
    m_textureDrone->ReleaseResources();
    m_texture3DReticle->ReleaseResources();
    m_texture2DReticle->ReleaseResources();
    m_textureMidAirReticle->ReleaseResources();

    m_renderingPrimitives.reset();
}
