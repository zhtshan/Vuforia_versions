/*===============================================================================
Copyright (c) 2020 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

#include "pch.h"
#include "ImageTargetsRenderer.h"
#include "Common/DirectXHelper.h"
#include "Common/SampleAppMathUtils.h"
#include "Common/SampleUtil.h"
#include "Common/RenderUtil.h"

#include <Vuforia/Vuforia.h>
#include <Vuforia/UWP/Vuforia_UWP.h>
#include <Vuforia/CameraDevice.h>
#include <Vuforia/Device.h>
#include <Vuforia/UWP/DXRenderer.h>
#include <Vuforia/Renderer.h>
#include <Vuforia/Tool.h>
#include <Vuforia/VideoBackgroundConfig.h>
#include <Vuforia/VideoBackgroundTextureInfo.h>
#include <Vuforia/TrackerManager.h>
#include <Vuforia/State.h>
#include <Vuforia/StateUpdater.h>
#include <Vuforia/Trackable.h>
#include <Vuforia/TrackableResult.h>
#include <Vuforia/ImageTargetResult.h>
#include <Vuforia/DeviceTrackableResult.h>
#include <Vuforia/ImageTarget.h>

using namespace ImageTargets;
using namespace DirectX;
using namespace Windows::Foundation;
using namespace Microsoft::WRL;


namespace
{
    Platform::String^ LOGTAG = "ImageTargetsRenderer";

    const float TEAPOT_SCALE = 0.003f;
    const float TOWER_SCALE = 0.012f;
    const float VIRTUAL_FOV_Y_DEGS = 85.0f;

    const std::wstring RES_PATH_SHADER_TEXTURED_VS = L"TexturedVertexShader.cso";
    const std::wstring RES_PATH_SHADER_TEXTURED_PS = L"TexturedPixelShader.cso";
    const std::wstring RES_PATH_SHADER_VIDEO_BKGD_VS = L"VideoBackgroundVertexShader.cso";
    const std::wstring RES_PATH_SHADER_VIDEO_BKGD_PS = L"VideoBackgroundPixelShader.cso";

    const wchar_t RES_PATH_TEXTURE_TEAPOT_BLUE[] = L"Assets/ImageTargets/TextureTeapotBlue.png";
    const wchar_t RES_PATH_TEXTURE_TEAPOT_BRASS[] = L"Assets/ImageTargets/TextureTeapotBrass.png";
    const wchar_t RES_PATH_TEXTURE_TEAPOT_RED[] = L"Assets/ImageTargets/TextureTeapotRed.png";
    const wchar_t RES_PATH_TEXTURE_BUILDINGS[] = L"Assets/ImageTargets/Buildings.png";

    const char RES_PATH_MODEL_BUILDINGS[] = "Assets/ImageTargets/buildings.txt";
}



// Loads vertex and pixel shaders from files, create the teapot mesh and load the textures.
ImageTargetsRenderer::ImageTargetsRenderer(const std::shared_ptr<DX::DeviceResources>& deviceResources) :
    m_deviceResources(deviceResources),
    m_rendererInitialized(false),
    m_vuforiaInitialized(false),
    m_vuforiaStarted(false),
    m_deviceTrackerEnabled(false)
{
    LOGC(LOGTAG, "ImageTargetsRenderer");

    CreateDeviceDependentResources();
    CreateWindowSizeDependentResources();
}

ImageTargetsRenderer::~ImageTargetsRenderer()
{
    LOGC(LOGTAG, "~ImageTargetsRenderer");

    ReleaseDeviceDependentResources();
}

void ImageTargetsRenderer::SetVuforiaStarted(bool started)
{
    if (started)
    {
        LOG("ImageTargetsRenderer::SetVuforiaStarted(true) called.");
        m_vuforiaStarted = started;
        UpdateRenderingPrimitives();
    }
    else
    {
        LOG("ImageTargetsRenderer::SetVuforiaStarted(false) called.");
        m_videoBackground->SetVideoBackgroundTexture();
    }
}

// Initializes view parameters when the window size changes.
void ImageTargetsRenderer::CreateWindowSizeDependentResources()
{
    LOGC(LOGTAG, "CreateWindowSizeDependentResources");

    if (m_vuforiaStarted) {
        UpdateRenderingPrimitives();
    }
}

void ImageTargetsRenderer::UpdateRenderingPrimitives()
{
    Concurrency::critical_section::scoped_lock lock(m_renderingPrimitivesLock);

    LOGC(LOGTAG, "UpdateRenderingPrimitives");

    if (m_renderingPrimitives != nullptr)
    {
        m_renderingPrimitives.reset();
    }

    m_renderingPrimitives = std::make_unique<Vuforia::RenderingPrimitives>
        (Vuforia::Device::getInstance().getRenderingPrimitives());

    m_videoBackground->ResetForNewRenderingPrimitives();
}

// Called once per frame
void ImageTargetsRenderer::Update(SampleCommon::StepTimer const& timer)
{
}

// Renders one frame using the vertex and pixel shaders.
void ImageTargetsRenderer::Render()
{
    // Vuforia initialization and data loading is asynchronous.
    // Only starts rendering after Vuforia init/loading is complete.
    if (!m_rendererInitialized || !m_vuforiaStarted)
    {
        return;
    }

    // Get the state from Vuforia and mark the beginning of a rendering section
    Vuforia::DXRenderData dxRenderData(m_deviceResources->GetD3DDevice());
    const Vuforia::State state = Vuforia::TrackerManager::getInstance().getStateUpdater().updateState();

    Vuforia::Renderer &vuforiaRenderer = Vuforia::Renderer::getInstance();
    vuforiaRenderer.begin(state, &dxRenderData);

    RenderScene(vuforiaRenderer, state);

    vuforiaRenderer.end();
}

void ImageTargetsRenderer::RenderScene(Vuforia::Renderer &renderer, const Vuforia::State &state)
{
    Concurrency::critical_section::scoped_lock lock(m_renderingPrimitivesLock);

    auto context = m_deviceResources->GetD3DDeviceContext();

    // Calculate the DX Projection matrix using the current Vuforia state
    auto projectionMatrix =
        Vuforia::Tool::convertPerspectiveProjection2GLMatrix(
            m_renderingPrimitives->getProjectionMatrix(
                Vuforia::VIEW_SINGULAR, state.getCameraCalibration()
            ),
            m_near,
            m_far
        );

    XMFLOAT4X4 dxProjection;
    memcpy(dxProjection.m, projectionMatrix.data, sizeof(float) * 16);
    XMStoreFloat4x4(&dxProjection, XMMatrixTranspose(XMLoadFloat4x4(&dxProjection)));

    XMMATRIX xmProjectionMatrix = XMLoadFloat4x4(&dxProjection);

    // Render the camera video background
    m_videoBackground->Render(renderer, m_renderingPrimitives.get(), Vuforia::VIEW_SINGULAR, state);

    // Setup rendering pipeline for augmentation rendering
    context->RSSetState(m_augmentationRasterStateCullBack.Get()); // Typically when using the rear facing camera

    context->OMSetDepthStencilState(m_augmentationDepthStencilState.Get(), 1);
    context->OMSetBlendState(m_augmentationBlendState.Get(), NULL, 0xffffffff);

    DirectX::XMFLOAT4X4 devicePoseMatrixDX;
    XMStoreFloat4x4(&devicePoseMatrixDX, XMMatrixIdentity());
    Vuforia::Matrix44F devicePoseMatrix = SampleAppMathUtils::Matrix44FIdentity();
    
    // Get the device pose
    if (state.getDeviceTrackableResult() != nullptr &&
        state.getDeviceTrackableResult()->getStatus() != Vuforia::TrackableResult::NO_POSE)
    {
        Vuforia::Matrix44F modelMatrix =
            Vuforia::Tool::convertPose2GLMatrix(state.getDeviceTrackableResult()->getPose());

        devicePoseMatrix =
            SampleAppMathUtils::Matrix44FTranspose(SampleAppMathUtils::Matrix44FInverse(modelMatrix));

        SampleAppMathUtils::convertPoseFromGLtoDX(devicePoseMatrix, devicePoseMatrixDX);
    }

    ProcessTrackableResults(state, devicePoseMatrixDX, xmProjectionMatrix);
}

void ImageTargetsRenderer::ProcessTrackableResults(const Vuforia::State & state, DirectX::XMFLOAT4X4 &devicePoseMatrixDX, DirectX::XMMATRIX &projectionMatrix)
{
    const auto& trackableResultList = state.getTrackableResults();
    for (const auto& result : trackableResultList)
    {
        const Vuforia::Trackable &trackable = result->getTrackable();
        const char* trackableName = trackable.getName();

        if (!result->isOfType(Vuforia::ImageTargetResult::getClassType()) || result->getStatus() == Vuforia::TrackableResult::STATUS::LIMITED)
        {
            continue;
        }

        // Set up the modelview matrix
        auto poseGL = Vuforia::Tool::convertPose2GLMatrix(result->getPose());
        XMFLOAT4X4 poseDX;
        memcpy(poseDX.m, poseGL.data, sizeof(float) * 16);
        XMStoreFloat4x4(&poseDX, XMMatrixTranspose(XMLoadFloat4x4(&poseDX)));
        XMMATRIX poseMatrix = XMLoadFloat4x4(&poseDX);

        std::shared_ptr<SampleCommon::Texture> texture = GetAugmentationTexture(trackable.getName());
        if (!texture->IsInitialized()) {
            texture->Init();
        }

        if (m_deviceTrackerEnabled)
        {
            // Combine the device pose (view matrix) with the model matrix
            poseMatrix = DirectX::XMMatrixMultiply(XMLoadFloat4x4(&devicePoseMatrixDX), XMLoadFloat4x4(&poseDX));
            RenderTower(poseMatrix, projectionMatrix, texture);
        }
        else
        {
            RenderTeapot(poseMatrix, projectionMatrix, texture);
        }
    }
}

void ImageTargetsRenderer::RenderTeapot(
    const XMMATRIX &poseMatrix,
    const XMMATRIX &projectionMatrix,
    const std::shared_ptr<SampleCommon::Texture> texture
)
{
    auto context = m_deviceResources->GetD3DDeviceContext();

    auto scale = XMMatrixScaling(TEAPOT_SCALE, TEAPOT_SCALE, TEAPOT_SCALE);
    auto modelMatrix = XMMatrixIdentity() * scale;

    // Set the model matrix (the 'model' part of the 'model-view' matrix)
    XMStoreFloat4x4(&m_augmentationConstantBufferData.model, modelMatrix);

    // Set the pose matrix (the 'view' part of the 'model-view' matrix)
    XMStoreFloat4x4(&m_augmentationConstantBufferData.view, poseMatrix);

    // Set the projection matrix
    XMStoreFloat4x4(&m_augmentationConstantBufferData.projection, projectionMatrix);

    // Prepare the constant buffer to send it to the graphics device.
    context->UpdateSubresource1(
        m_augmentationConstantBuffer.Get(),
        0,
        NULL,
        &m_augmentationConstantBufferData,
        0,
        0,
        0
    );

    // Each vertex is one instance of the TexturedVertex struct.
    UINT stride = sizeof(SampleCommon::TexturedVertex);
    UINT offset = 0;
    context->IASetVertexBuffers(
        0,
        1,
        m_teapotMesh->GetVertexBuffer().GetAddressOf(),
        &stride,
        &offset
    );

    context->IASetIndexBuffer(
        m_teapotMesh->GetIndexBuffer().Get(),
        DXGI_FORMAT_R16_UINT, // Each index is one 16-bit unsigned integer (short).
        0
    );

    context->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

    context->IASetInputLayout(m_augmentationInputLayout.Get());

    // Attach our vertex shader.
    context->VSSetShader(m_augmentationVertexShader.Get(), nullptr, 0);

    // Send the constant buffer to the graphics device.
    context->VSSetConstantBuffers1(
        0,
        1,
        m_augmentationConstantBuffer.GetAddressOf(),
        nullptr,
        nullptr
    );

    // Attach our pixel shader.
    context->PSSetShader(m_augmentationPixelShader.Get(), nullptr, 0);

    context->PSSetSamplers(0, 1, texture->GetD3DSamplerState().GetAddressOf());
    context->PSSetShaderResources(0, 1, texture->GetD3DTextureView().GetAddressOf());

    // Draw the objects.
    context->DrawIndexed(m_teapotMesh->GetIndexCount(), 0, 0);
}

void ImageTargetsRenderer::RenderTower(
    const XMMATRIX &poseMatrix,
    const XMMATRIX &projectionMatrix,
    const std::shared_ptr<SampleCommon::Texture> texture
)
{
    auto context = m_deviceResources->GetD3DDeviceContext();

    // Set pose matrix (the 'view' part of the 'model-view' matrix)
    XMStoreFloat4x4(&m_augmentationConstantBufferData.view, poseMatrix);

    // Set model matrix (the 'model' part of the 'model-view' matrix)
    auto scale = XMMatrixScaling(TOWER_SCALE, TOWER_SCALE, TOWER_SCALE);
    auto rotation = XMMatrixTranspose(XMMatrixRotationX(3.14159f / 2));
    auto modelMatrix = XMMatrixIdentity() * rotation * scale;
    XMStoreFloat4x4(&m_augmentationConstantBufferData.model, modelMatrix);

    // Set projection matrix
    XMStoreFloat4x4(&m_augmentationConstantBufferData.projection, projectionMatrix);

    // Prepare the constant buffer to send it to the graphics device.
    context->UpdateSubresource1(
        m_augmentationConstantBuffer.Get(),
        0,
        NULL,
        &m_augmentationConstantBufferData,
        0,
        0,
        0
    );

    // Each vertex is one instance of the TexturedVertex struct.
    UINT stride = sizeof(SampleCommon::TexturedVertex);
    UINT offset = 0;
    context->IASetVertexBuffers(
        0,
        1,
        m_towerModel->GetVertexBuffer().GetAddressOf(),
        &stride,
        &offset
    );

    context->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

    context->IASetInputLayout(m_augmentationInputLayout.Get());

    // Attach our vertex shader.
    context->VSSetShader(m_augmentationVertexShader.Get(), nullptr, 0);

    // Send the constant buffer to the graphics device.
    context->VSSetConstantBuffers1(
        0,
        1,
        m_augmentationConstantBuffer.GetAddressOf(),
        nullptr,
        nullptr
    );

    // Attach our pixel shader.
    context->PSSetShader(m_augmentationPixelShader.Get(), nullptr, 0);

    context->PSSetSamplers(0, 1, texture->GetD3DSamplerState().GetAddressOf());
    context->PSSetShaderResources(0, 1, texture->GetD3DTextureView().GetAddressOf());

    // Draw the objects.
    context->Draw(m_towerModel->GetVertexCount(), 0);
}

const std::shared_ptr<SampleCommon::Texture> ImageTargetsRenderer::GetAugmentationTexture(const char *targetName)
{
    if (m_deviceTrackerEnabled) {
        return m_textureTower;
    }

    // Choose the texture based on the target name:
    if (strcmp(targetName, "chips") == 0)
    {
        return m_textureTeapotBrass;
    }
    else if (strcmp(targetName, "stones") == 0)
    {
        return m_textureTeapotBlue;
    }
    else
    {
        return m_textureTeapotRed;
    }
}

void ImageTargetsRenderer::CreateDeviceDependentResources()
{
    Concurrency::critical_section::scoped_lock lock(m_deviceDependentResourcesLock);

    LOGC(LOGTAG, "CreateDeviceDependentResources");

    m_rendererInitialized = false;

    m_videoBackground = std::make_shared<SampleCommon::VideoBackground>(m_deviceResources);

    // Load shaders asynchronously.
    auto loadVSTask = DX::ReadDataAsync(RES_PATH_SHADER_TEXTURED_VS);
    auto loadPSTask = DX::ReadDataAsync(RES_PATH_SHADER_TEXTURED_PS);
    auto loadVideoBgVSTask = DX::ReadDataAsync(RES_PATH_SHADER_VIDEO_BKGD_VS);
    auto loadVideoBgPSTask = DX::ReadDataAsync(RES_PATH_SHADER_VIDEO_BKGD_PS);

    // After the vertex shader file is loaded, create the shader and input layout.
    auto createVSTask = loadVSTask.then([this](const std::vector<byte>& fileData)
    {
        DX::ThrowIfFailed(
            m_deviceResources->GetD3DDevice()->CreateVertexShader(
                &fileData[0],
                fileData.size(),
                nullptr,
                &m_augmentationVertexShader
            )
        );

        static const D3D11_INPUT_ELEMENT_DESC vertexDesc[] =
        {
            { "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 0, D3D11_INPUT_PER_VERTEX_DATA, 0 },
            { "TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT, 0, 12, D3D11_INPUT_PER_VERTEX_DATA, 0 },
        };

        DX::ThrowIfFailed(
            m_deviceResources->GetD3DDevice()->CreateInputLayout(
                vertexDesc,
                ARRAYSIZE(vertexDesc),
                &fileData[0],
                fileData.size(),
                &m_augmentationInputLayout
            )
        );
    });

    auto createVideoBgVSTask = loadVideoBgVSTask.then([this](const std::vector<byte>& fileData)
    {
        m_videoBackground->InitVertexShader(&fileData[0], fileData.size());
    });

    // After the pixel shader file is loaded, create the shader and constant buffer.
    auto createPSTask = loadPSTask.then([this](const std::vector<byte>& fileData)
    {
        DX::ThrowIfFailed(
            m_deviceResources->GetD3DDevice()->CreatePixelShader(
                &fileData[0],
                fileData.size(),
                nullptr,
                &m_augmentationPixelShader
            )
        );

        CD3D11_BUFFER_DESC constantBufferDesc(
            sizeof(SampleCommon::ModelViewProjectionConstantBuffer),
            D3D11_BIND_CONSTANT_BUFFER);

        DX::ThrowIfFailed(
            m_deviceResources->GetD3DDevice()->CreateBuffer(
                &constantBufferDesc,
                nullptr,
                &m_augmentationConstantBuffer
            )
        );
    });

    // After the pixel shader file is loaded, create the shader and constant buffer.
    auto createVideoBgPSTask = loadVideoBgPSTask.then([this](const std::vector<byte>& fileData)
    {
        m_videoBackground->InitFragmentShader(&fileData[0], fileData.size());
    });

    // Once both shaders are loaded, create the mesh.
    auto createAugmentationModelsTask = (createPSTask && createVSTask && createVideoBgPSTask && createVideoBgVSTask).then([this]()
    {
        m_teapotMesh = std::make_shared<SampleCommon::TeapotMesh>(m_deviceResources);
        m_towerModel = std::make_shared<SampleCommon::SampleApp3DModel>(m_deviceResources, RES_PATH_MODEL_BUILDINGS);

        m_teapotMesh->InitMesh();
        m_towerModel->InitMesh();
    });

    auto createTextureTask = createAugmentationModelsTask.then([this]()
    {
        m_textureTeapotBlue = std::make_shared<SampleCommon::Texture>(m_deviceResources);
        m_textureTeapotBrass = std::make_shared<SampleCommon::Texture>(m_deviceResources);
        m_textureTeapotRed = std::make_shared<SampleCommon::Texture>(m_deviceResources);
        m_textureTower = std::make_shared<SampleCommon::Texture>(m_deviceResources);

        m_textureTeapotBlue->CreateFromFile(RES_PATH_TEXTURE_TEAPOT_BLUE);
        m_textureTeapotBrass->CreateFromFile(RES_PATH_TEXTURE_TEAPOT_BRASS);
        m_textureTeapotRed->CreateFromFile(RES_PATH_TEXTURE_TEAPOT_RED);
        m_textureTower->CreateFromFile(RES_PATH_TEXTURE_BUILDINGS);
    });

    auto setupRasterizersTask = createTextureTask.then([this]()
    {
        // setup the rasterizer
        auto context = m_deviceResources->GetD3DDeviceContext();

        ID3D11Device *device;
        context->GetDevice(&device);

        // Init rendering pipeline state for video background
        m_videoBackground->InitRenderState();

        // Create the rasterizer for augmentation rendering
        // with back-face culling
        D3D11_RASTERIZER_DESC augmentationRasterDescCullBack = SampleCommon::RenderUtil::CreateRasterizerDesc(
            D3D11_FILL_SOLID, // solid rendering
            D3D11_CULL_BACK, // culling
            true, // Counter clockwise front face
            true // depth clipping enabled
        );
        device->CreateRasterizerState(&augmentationRasterDescCullBack, m_augmentationRasterStateCullBack.GetAddressOf());

        // Create Depth-Stencil State with depth testing ON,
        // for augmentation rendering
        D3D11_DEPTH_STENCIL_DESC augmentDepthStencilDesc = SampleCommon::RenderUtil::CreateDepthStencilDesc(
            true,
            D3D11_DEPTH_WRITE_MASK_ALL,
            D3D11_COMPARISON_LESS
        );
        device->CreateDepthStencilState(&augmentDepthStencilDesc, m_augmentationDepthStencilState.GetAddressOf());

        // Create blend state for augmentation rendering
        bool translucentAugmentation = false;// set to TRUE for rendering translucent models
        D3D11_BLEND_DESC augmentationBlendDesc = SampleCommon::RenderUtil::CreateBlendDesc(translucentAugmentation);
        device->CreateBlendState(&augmentationBlendDesc, m_augmentationBlendState.GetAddressOf());
    });

    setupRasterizersTask.then([this](Concurrency::task<void> t)
    {
        try
        {
            // If any exceptions were thrown back in the async chain then
            // this call throws that exception here and we can catch it below
            t.get();

            // Now we are ready for rendering
            m_rendererInitialized = true;
        }
        catch (Platform::Exception ^ex) {
            SampleCommon::SampleUtil::ShowError(L"Renderer init error", ex->Message);
        }
    });
}

void ImageTargetsRenderer::ReleaseDeviceDependentResources()
{
    LOGC(LOGTAG, "ReleaseDeviceDependentResources");

    m_rendererInitialized = false;

    m_videoBackground.reset();
    m_deviceResources.reset();

    m_augmentationInputLayout.Reset();
    m_augmentationVertexShader.Reset();
    m_augmentationPixelShader.Reset();
    m_augmentationConstantBuffer.Reset();

    m_teapotMesh->ReleaseResources();
    m_teapotMesh.reset();
    m_towerModel->ReleaseResources();
    m_towerModel.reset();
    m_textureTeapotBlue->ReleaseResources();
    m_textureTeapotBlue.reset();
    m_textureTeapotBrass->ReleaseResources();
    m_textureTeapotBrass.reset();
    m_textureTeapotRed->ReleaseResources();
    m_textureTeapotRed.reset();
    m_textureTower->ReleaseResources();
    m_textureTower.reset();

    m_renderingPrimitives.reset();
}
