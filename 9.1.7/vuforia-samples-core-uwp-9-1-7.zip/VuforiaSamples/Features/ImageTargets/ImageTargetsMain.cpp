/*===============================================================================
Copyright (c) 2020 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/
#include "pch.h"
#include "Common/DirectXHelper.h"
#include <Vuforia/UWP/Vuforia_UWP.h>
#include "ImageTargetsMain.h"

using namespace ImageTargets;
using namespace Windows::Foundation;
using namespace Windows::System::Threading;
using namespace Concurrency;

using namespace VuforiaSamples;

namespace
{
    Platform::String^ LOGTAG = "ImageTargetsMain";
}

// Loads and initializes application assets when the application is loaded.
ImageTargetsMain::ImageTargetsMain(
    const std::shared_ptr<DX::DeviceResources>& deviceResources,
    const std::shared_ptr<AppSession>& appSession) :
    m_deviceResources(deviceResources),
    m_appSession(appSession)
{
    LOGC(LOGTAG, "ImageTargetsMain");

    // Register to be notified if the Device is lost or recreated
    m_deviceResources->RegisterDeviceNotify(this);

    // Init the scene renderer
    m_renderer = std::make_unique<ImageTargetsRenderer>(m_deviceResources);

    // We set the desired frame rate here
    float fps = 60;
    m_timer.SetFixedTimeStep(true);
    m_timer.SetTargetElapsedSeconds(1.0 / fps);
}

ImageTargetsMain::~ImageTargetsMain()
{
    LOGC(LOGTAG, "~ImageTargetsMain");

    // Deregister device notification
    m_deviceResources->RegisterDeviceNotify(nullptr);
    m_deviceResources.reset();
    m_appSession.reset();
    m_renderer.reset();
}

// Updates application state when the window size changes (e.g. device orientation change)
void ImageTargetsMain::CreateWindowSizeDependentResources()
{
    LOGC(LOGTAG, "CreateWindowSizeDependentResources");

    // Only call Vuforia API after initialization
    if (m_appSession->VuforiaInitialized())
    {
        m_appSession->ConfigureDisplay(
            m_deviceResources->GetOutputSize(),
            m_deviceResources->GetCurrentOrientation()
        );

        if (m_renderer->IsVuforiaStarted())
        {
            m_appSession->ConfigureVideoBackground(
                m_deviceResources->GetOutputSize(),
                m_deviceResources->GetCurrentOrientation()
            );
        }
    }
    else
    {
        LOG("Failed to configure display. Vuforia not initialized yet.");
    }

    m_renderer->CreateWindowSizeDependentResources();
}

void ImageTargetsMain::StartRenderLoop()
{
    LOGC(LOGTAG, "StartRenderLoop");

    // If the animation render loop is already running then do not start another thread.
    if (m_renderLoopWorker != nullptr && m_renderLoopWorker->Status == AsyncStatus::Started)
    {
        return;
    }

    // Create a task that will be run on a background thread.
    auto workItemHandler = ref new WorkItemHandler([this](IAsyncAction ^ action)
    {
        // Calculate the updated frame and render once per vertical blanking interval.
        while (action->Status == AsyncStatus::Started)
        {
            critical_section::scoped_lock lock(GetCriticalSection());
            Update();
            if (Render())
            {
                m_deviceResources->Present();
            }
        }
    });

    // Run task on a dedicated high priority background thread.
    m_renderLoopWorker = ThreadPool::RunAsync(
        workItemHandler,
        WorkItemPriority::High,
        WorkItemOptions::TimeSliced
    );
}

void ImageTargetsMain::StopRenderLoop()
{
    LOGC(LOGTAG, "StopRenderLoop");

    m_renderLoopWorker->Cancel();
}

// Updates the application state once per frame.
void ImageTargetsMain::Update()
{
    ProcessInput();

    // Update scene objects
    m_timer.Tick([&]()
    {
        if (m_renderer->IsRendererInitialized())
        {
            m_renderer->Update(m_timer);
        }
    });
}

// Process all input from the user before updating game state
void ImageTargetsMain::ProcessInput()
{
    // Add per frame input handling here.

}

// Renders the current frame according to the current application state.
// Returns true if the frame was rendered and is ready to be displayed.
bool ImageTargetsMain::Render()
{
    // Don't try to render anything before the first Update.
    if (m_timer.GetFrameCount() == 0)
    {
        return false;
    }

    // Don't render before we finish loading renderer resources
    // (textures, meshes, shaders,...).
    if (!m_renderer->IsRendererInitialized())
    {
        return false;
    }

    auto context = m_deviceResources->GetD3DDeviceContext();

    // Reset the viewport to target the whole screen.
    auto viewport = m_deviceResources->GetScreenViewport();
    context->RSSetViewports(1, &viewport);


    // Reset render targets to the screen.
    ID3D11RenderTargetView *const targets[1] = { m_deviceResources->GetBackBufferRenderTargetView() };
    context->OMSetRenderTargets(1, targets, m_deviceResources->GetDepthStencilView());

    // Clear the back buffer and depth stencil view.
    context->ClearRenderTargetView(m_deviceResources->GetBackBufferRenderTargetView(), DirectX::Colors::Black);
    context->ClearDepthStencilView(m_deviceResources->GetDepthStencilView(), D3D11_CLEAR_DEPTH | D3D11_CLEAR_STENCIL, 1.0f, 0);

    // Render the scene objects.
    m_renderer->Render();

    return true;
}

// Notifies renderers that device resources need to be released.
void ImageTargetsMain::OnDeviceLost()
{
    LOGC(LOGTAG, "OnDeviceLost");

    m_renderer->ReleaseDeviceDependentResources();
}

// Notifies renderers that device resources may now be recreated.
void ImageTargetsMain::OnDeviceRestored()
{
    LOGC(LOGTAG, "OnDeviceRestored");

    m_renderer->CreateDeviceDependentResources();
    CreateWindowSizeDependentResources();
}
