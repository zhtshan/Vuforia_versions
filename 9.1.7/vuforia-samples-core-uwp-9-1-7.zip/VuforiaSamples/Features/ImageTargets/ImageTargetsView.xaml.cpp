/*===============================================================================
Copyright (c) 2020 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/
#include "pch.h"

#include "ImageTargetsView.xaml.h"
#include "Common\SampleUtil.h"

#include <Vuforia\Vuforia.h>
#include <Vuforia\UWP\Vuforia_UWP.h>
#include <Vuforia\CameraDevice.h>
#include <Vuforia\State.h>
#include <Vuforia\TrackerManager.h>
#include <Vuforia\Tracker.h>
#include <Vuforia\ObjectTracker.h>
#include <Vuforia\PositionalDeviceTracker.h>
#include <Vuforia\ObjectTarget.h>
#include <Vuforia\StateUpdater.h>
#include <Vuforia\TrackableResult.h>
#include <Vuforia\DeviceTrackableResult.h>

using namespace Platform;
using namespace Windows::Foundation;
using namespace Windows::Foundation::Collections;
using namespace Windows::Graphics::Display;
using namespace Windows::Storage;
using namespace Windows::System::Threading;
using namespace Windows::UI::Core;
using namespace Windows::UI::Input;
using namespace Windows::UI::Xaml;
using namespace Windows::UI::Xaml::Controls;
using namespace Windows::UI::Xaml::Controls::Primitives;
using namespace Windows::UI::Xaml::Data;
using namespace Windows::UI::Xaml::Input;
using namespace Windows::UI::Xaml::Media;
using namespace Windows::UI::Xaml::Navigation;
using namespace concurrency;

using namespace VuforiaSamples;
using namespace ImageTargets;

namespace
{
    Platform::String^ LOGTAG = "ImageTargetsView";
}

ImageTargetsView::ImageTargetsView() :
    m_windowVisible(true),
    m_showingMenu(false),
    m_showingProgress(true),
    m_coreInput(nullptr),
    m_autofocusEnabled(true),
    m_deviceTracking(false),
    m_currentDataSet(nullptr),
    m_swapDataset(false),
    m_stonesDataSet(nullptr),
    m_tarmacDataSet(nullptr)
{
    LOGC(LOGTAG, "ImageTargetsView");

    InitializeComponent();

    Application^ app = Application::Current;
    suspendingToken =
        app->Suspending += ref new SuspendingEventHandler(this, &ImageTargetsView::OnSuspending);
    resumingToken =
        app->Resuming += ref new EventHandler<Object^>(this, &ImageTargetsView::OnResuming);

    // Register event handlers for page lifecycle.
    CoreWindow^ window = Window::Current->CoreWindow;

    visibilityChangedToken = window->VisibilityChanged +=
        ref new TypedEventHandler<CoreWindow^, VisibilityChangedEventArgs^>
        (this, &ImageTargetsView::OnVisibilityChanged);

    // Register DisplayInformation Events
    DisplayInformation^ currentDisplayInformation = DisplayInformation::GetForCurrentView();

    token1 = currentDisplayInformation->DpiChanged +=
        ref new TypedEventHandler<DisplayInformation^, Object^>
        (this, &ImageTargetsView::OnDpiChanged);

    token2 = currentDisplayInformation->OrientationChanged +=
        ref new TypedEventHandler<DisplayInformation^, Object^>
        (this, &ImageTargetsView::OnOrientationChanged);

    token3 = DisplayInformation::DisplayContentsInvalidated +=
        ref new TypedEventHandler<DisplayInformation^, Object^>
        (this, &ImageTargetsView::OnDisplayContentsInvalidated);

    // Register SwapChainPanel Events
    token4 = swapChainPanel->CompositionScaleChanged +=
        ref new TypedEventHandler<SwapChainPanel^, Object^>
        (this, &ImageTargetsView::OnCompositionScaleChanged);

    token5 = swapChainPanel->SizeChanged +=
        ref new SizeChangedEventHandler(this, &ImageTargetsView::OnSwapChainPanelSizeChanged);

    // At this point we have access to the device.
    // We can create the device-dependent resources.
    m_deviceResources = std::make_shared<DX::DeviceResources>();
    m_deviceResources->SetSwapChainPanel(swapChainPanel);

    // Register our SwapChainPanel to get independent input pointer events
    auto workItemHandler = ref new WorkItemHandler([this](IAsyncAction ^)
    {
        // The CoreIndependentInputSource will raise pointer events for the specified device types on whichever thread it's created on.
        m_coreInput = swapChainPanel->CreateCoreIndependentInputSource(
            Windows::UI::Core::CoreInputDeviceTypes::Mouse |
            Windows::UI::Core::CoreInputDeviceTypes::Touch |
            Windows::UI::Core::CoreInputDeviceTypes::Pen
        );

        // Register for pointer events, which will be raised on the background thread.
        token6 = m_coreInput->PointerPressed += ref new TypedEventHandler
            <Object^, PointerEventArgs^>(this, &ImageTargetsView::OnPointerPressed);
        token7 = m_coreInput->PointerMoved += ref new TypedEventHandler
            <Object^, PointerEventArgs^>(this, &ImageTargetsView::OnPointerMoved);
        token8 = m_coreInput->PointerReleased += ref new TypedEventHandler
            <Object^, PointerEventArgs^>(this, &ImageTargetsView::OnPointerReleased);

        // Begin processing input messages as they're delivered.
        m_coreInput->Dispatcher->ProcessEvents(CoreProcessEventsOption::ProcessUntilQuit);

    });

    // Run task on a dedicated high priority background thread.
    m_inputLoopWorker = ThreadPool::RunAsync(
        workItemHandler,
        WorkItemPriority::High,
        WorkItemOptions::TimeSliced
    );

    InitializeUI();

    // Init Vuforia App Session
    m_appSession = std::make_shared<AppSession>(this);
    m_appSession->InitAR(OBJECT_TRACKER | DEVICE_TRACKER);

    m_main = std::make_unique<ImageTargets::ImageTargetsMain>(m_deviceResources, m_appSession);

    m_main->StartRenderLoop();

    InitializeTimers();
}

ImageTargetsView::~ImageTargetsView()
{
    LOGC(LOGTAG, "~ImageTargetsView");

    m_dispatcherTimer->Tick -= timerToken1;
    m_relocalizationDelayTimer->Tick -= timerToken2;
    m_resetDeviceTrackerTimer->Tick -= timerToken3;

    Application^ app = Application::Current;
    app->Suspending -= suspendingToken;
    app->Resuming -= resumingToken;

    CoreWindow^ window = Window::Current->CoreWindow;
    window->VisibilityChanged -= visibilityChangedToken;

    DisplayInformation^ currentDisplayInformation = DisplayInformation::GetForCurrentView();
    currentDisplayInformation->DpiChanged -= token1;
    currentDisplayInformation->OrientationChanged -= token2;
    DisplayInformation::DisplayContentsInvalidated -= token3;

    swapChainPanel->CompositionScaleChanged -= token4;
    swapChainPanel->SizeChanged -= token5;

    m_appSession.reset();
    m_main.reset();
}

void ImageTargetsView::OnNavigatedFrom(Windows::UI::Xaml::Navigation::NavigationEventArgs^ e)
{
    LOGC(LOGTAG, "OnNavigatedFrom");
}

void ImageTargetsView::OnNavigatedTo(Windows::UI::Xaml::Navigation::NavigationEventArgs^ e)
{
    LOGC(LOGTAG, "OnNavigatedTo");
}

// Saves the current state of the app for suspend and terminate events.
void ImageTargetsView::SaveInternalState(IPropertySet^ state)
{
    LOGC(LOGTAG, "SaveInternalState");

    critical_section::scoped_lock lock(m_main->GetCriticalSection());
    m_deviceResources->Trim();

    // Stop rendering when the app is suspended.
    m_main->StopRenderLoop();

    // Put code to save app state here.
}

// Loads the current state of the app for resume events.
void ImageTargetsView::LoadInternalState(IPropertySet^ state)
{
    LOGC(LOGTAG, "LoadInternalState");

    // Put code to load app state here.

    // Start rendering when the app is resumed.
    m_main->StartRenderLoop();
}

// BEGIN: Window Event Handlers

void ImageTargetsView::OnSuspending(Platform::Object ^ sender, Windows::ApplicationModel::SuspendingEventArgs ^ e)
{
    LOGC(LOGTAG, "OnSuspending");

    SaveInternalState(ApplicationData::Current->LocalSettings->Values);
    OnPause();
}

void ImageTargetsView::OnResuming(Platform::Object ^ sender, Platform::Object ^ args)
{
    LOGC(LOGTAG, "OnResuming");

    LoadInternalState(ApplicationData::Current->LocalSettings->Values);
    OnResume();
}

void ImageTargetsView::OnPause()
{
    LOGC(LOGTAG, "OnPause");

    try
    {
        m_appSession->PauseAR();
    }
    catch (Platform::Exception^ ex)
    {
        SampleCommon::SampleUtil::Log(LOGTAG, ex->Message);
    }
}

void ImageTargetsView::OnResume()
{
    LOGC(LOGTAG, "OnResume");

    try
    {
        m_appSession->ResumeAR();
    }
    catch (Platform::Exception^ ex)
    {
        SampleCommon::SampleUtil::Log(LOGTAG, ex->Message);
    }
}

// END: Window Event Handlers


// CoreWindow Event Handler.

void ImageTargetsView::OnVisibilityChanged(CoreWindow^ sender, VisibilityChangedEventArgs^ args)
{
    LOGC(LOGTAG, "OnVisibilityChanged");

    m_windowVisible = args->Visible;
    if (m_windowVisible)
    {
        LOG("Window changed to Visible");
        m_appSession->ResumeAR();
        m_main->StartRenderLoop();
    }
    else
    {
        LOG("Window changed to Not Visible");
        m_main->StopRenderLoop();
        m_appSession->PauseAR();
    }
}

// DisplayInformation Event Handlers

void ImageTargetsView::OnDpiChanged(DisplayInformation^ sender, Object^ args)
{
    LOGC(LOGTAG, "OnDpiChanged");

    critical_section::scoped_lock lock(m_main->GetCriticalSection());
    // Note: The value for LogicalDpi retrieved here may not match the effective DPI of the app
    // if it is being scaled for high resolution devices. Once the DPI is set on DeviceResources,
    // you should always retrieve it using the GetDpi method.
    // See DeviceResources.cpp for more details.
    m_deviceResources->SetDpi(sender->LogicalDpi);
    m_main->CreateWindowSizeDependentResources();
}

void ImageTargetsView::OnOrientationChanged(DisplayInformation^ sender, Object^ args)
{
    LOGC(LOGTAG, "OnOrientationChanged");

    critical_section::scoped_lock lock(m_main->GetCriticalSection());
    m_deviceResources->SetCurrentOrientation(sender->CurrentOrientation);
    m_main->CreateWindowSizeDependentResources();
}

void ImageTargetsView::OnDisplayContentsInvalidated(DisplayInformation^ sender, Object^ args)
{
    LOGC(LOGTAG, "OnDisplayContentsInvalidated");

    critical_section::scoped_lock lock(m_main->GetCriticalSection());
    m_deviceResources->ValidateDevice();
}

// SwapChainPanel Event Handlers

void ImageTargetsView::OnCompositionScaleChanged(SwapChainPanel^ sender, Object^ args)
{
    LOGC(LOGTAG, "OnCompositionScaleChanged");

    critical_section::scoped_lock lock(m_main->GetCriticalSection());
    m_deviceResources->SetCompositionScale(sender->CompositionScaleX, sender->CompositionScaleY);
    m_main->CreateWindowSizeDependentResources();
}

void ImageTargetsView::OnSwapChainPanelSizeChanged(Object^ sender, SizeChangedEventArgs^ e)
{
    LOGC(LOGTAG, "OnSwapChainPanelSizeChanged");

    critical_section::scoped_lock lock(m_main->GetCriticalSection());
    m_deviceResources->SetLogicalSize(e->NewSize);
    m_main->CreateWindowSizeDependentResources();
}

// Pointer (touch) Handlers

void ImageTargetsView::OnPointerPressed(Object^ sender, PointerEventArgs^ e)
{
    static std::atomic<int> tapCount = 0;
    tapCount++;
    static double lastTime = 0;
    double currentTime = m_main->GetTimer().GetTotalSeconds();
    double dt = currentTime - lastTime;
    lastTime = currentTime;

    if (tapCount == 1)
    {
        // Run async task
        Concurrency::create_task([this]()
        {
            // Wait for half-second, if no second tap comes,
            // then we have confirmed a single-tap
            // else we have a double-tap
            WaitForSingleObjectEx(GetCurrentThread(), 500, FALSE);

            if (tapCount == 1)
            {
                // tapCount is still 1, nothing changed,
                // so we have confirmed a single-tap,
                // so we consume the single-tap event:
                tapCount = 0;

                HandleSingleTap();
            }
            else if (tapCount >= 2)
            {
                // We process the double-tap event
                tapCount = 0;

                HandleDoubleTap();
            }
        });
    }
}

void ImageTargetsView::OnPointerMoved(Object^ sender, PointerEventArgs^ e)
{
    // Move/drag event
}

void ImageTargetsView::OnPointerReleased(Object^ sender, PointerEventArgs^ e)
{
    // Touch released
}

void ImageTargetsView::HandleSingleTap()
{
    LOGC(LOGTAG, "HandleSingleTap");

    if (m_showingMenu)
    {
        // Hide menu (async on UI thread)
        Windows::ApplicationModel::Core::CoreApplication::MainView->CoreWindow->Dispatcher->RunAsync(
            Windows::UI::Core::CoreDispatcherPriority::Normal,
            ref new Windows::UI::Core::DispatchedHandler([=]()
        {
            ToggleMenu(false);
        }));
    }
    else
    {
        // Trigger an autofocus event
        Vuforia::CameraDevice::getInstance().setFocusMode(Vuforia::CameraDevice::FOCUS_MODE_TRIGGERAUTO);

        // Make sure original focus mode is restored after ~2 seconds
        WaitForSingleObjectEx(GetCurrentThread(), 2500, FALSE);

        if (m_autofocusEnabled)
        {
            // Restore continuous autofocus
            Vuforia::CameraDevice::getInstance().setFocusMode(
                Vuforia::CameraDevice::FOCUS_MODE_CONTINUOUSAUTO);
        }
        else
        {
            // Restore normal focus mode
            Vuforia::CameraDevice::getInstance().setFocusMode(
                Vuforia::CameraDevice::FOCUS_MODE_NORMAL);
        }
    }
}

void ImageTargetsView::HandleDoubleTap()
{
    LOGC(LOGTAG, "HandleDoubleTap");

    if (!m_showingMenu)
    {
        // Show the menu (async on UI thread)
        Windows::ApplicationModel::Core::CoreApplication::MainView->CoreWindow->Dispatcher->RunAsync(
            Windows::UI::Core::CoreDispatcherPriority::Normal,
            ref new Windows::UI::Core::DispatchedHandler([=]()
        {
            ToggleMenu(true);
        }));
    }
}


// ***** XAML Support Methods *****
/*
void ImageTargetsView::InitializeUI()
void ImageTargetsView::ToggleMenu(bool enable)
void ImageTargetsView::OnExitClick(Platform::Object^ sender, Windows::UI::Xaml::RoutedEventArgs^ e)
void ImageTargetsView::OnMenuAnimationDone(Platform::Object^ sender, Windows::UI::Xaml::RoutedEventArgs^ e)
void ImageTargetsView::HideProgressIndicator()
*/

void ImageTargets::ImageTargetsView::InitializeUI()
{
    // Hide elements at start
    this->StatusToast->Visibility = Windows::UI::Xaml::Visibility::Collapsed;
    this->OptionsMenu->Visibility = Windows::UI::Xaml::Visibility::Collapsed;

    ToggleMenu(false);

    VuforiaVersion->Text = "Vuforia " + SampleCommon::SampleUtil::ToPlatformString(Vuforia::getLibraryVersion());
}

void ImageTargetsView::ToggleMenu(bool enable)
{
    LOGC(LOGTAG, "ToggleMenu");

    if (enable)
    {
        this->OptionsMenu->Visibility = Windows::UI::Xaml::Visibility::Visible;
    }

    m_showingMenu = enable;

    if (enable)
        this->ShowMenuStoryboard->Begin();
    else
        this->HideMenuStoryboard->Begin();
}

void ImageTargetsView::OnExitClick(Platform::Object^ sender, Windows::UI::Xaml::RoutedEventArgs^ e)
{
    LOGC(LOGTAG, "OnExitClick");

    ToggleMenu(false);
}

void ImageTargetsView::OnMenuAnimationDone(Platform::Object^ sender, Windows::UI::Xaml::RoutedEventArgs^ e)
{
    LOGC(LOGTAG, "OnMenuAnimationDone");

    this->OptionsMenu->Visibility = m_showingMenu ?
        Windows::UI::Xaml::Visibility::Visible :
        Windows::UI::Xaml::Visibility::Collapsed;
}

void ImageTargetsView::HideProgressIndicator()
{
    LOGC(LOGTAG, "HideProgressIndicator");

    if (!m_showingProgress) {
        // Skip, as already hidden
        return;
    }

    auto dispatcher = Windows::ApplicationModel::Core::CoreApplication::MainView->CoreWindow->Dispatcher;
    dispatcher->RunAsync(
        Windows::UI::Core::CoreDispatcherPriority::High,
        ref new Windows::UI::Core::DispatchedHandler([this]()
    {
        this->InitProgressRing->IsActive = false;
        this->InitProgressRing->Visibility = Windows::UI::Xaml::Visibility::Collapsed;
        m_showingProgress = false;
    }));
}

// ***** Vuforia Camera Management Methods *****
/*
void ImageTargetsView::BeforeStartCamera()
void ImageTargetsView::BeforeStopCamera()
*/

void ImageTargetsView::BeforeStartCamera()
{
    LOGC(LOGTAG, "BeforeStartCamera");

    if (!Vuforia::CameraDevice::getInstance().selectVideoMode(
        Vuforia::CameraDevice::MODE_DEFAULT))
    {
        SampleCommon::SampleUtil::Log(LOGTAG, "Failed to set the camera video mode.");
    }

    m_appSession->ConfigureVideoBackground(
        m_deviceResources->GetOutputSize(),
        m_deviceResources->GetCurrentOrientation()
    );

    m_main->GetRenderer()->UpdateRenderingPrimitives();
}

void ImageTargetsView::BeforeStopCamera()
{
    LOGC(LOGTAG, "BeforeStopCamera");

    // Notify renderer, do this before stopping the camera
    m_main->GetRenderer()->SetVuforiaStarted(false);
}

// ***** Vuforia Tracker Management Methods *****
/*
bool ImageTargetsView::DoStartTrackers()
bool ImageTargetsView::DoStopTrackers()
bool ImageTargetsView::DoLoadTrackersData()
*/

bool ImageTargetsView::DoStartTrackers()
{
    LOGC(LOGTAG, "DoStartTrackers");

    if (m_deviceTracking)
    {
        m_appSession->StartTracker(Vuforia::PositionalDeviceTracker::getClassType());
    }

    return m_appSession->StartTracker(Vuforia::ObjectTracker::getClassType());
}

bool ImageTargetsView::DoStopTrackers()
{
    LOGC(LOGTAG, "DoStopTrackers");

    if (m_deviceTracking)
    {
        m_appSession->StopTracker(Vuforia::PositionalDeviceTracker::getClassType());
    }

    return m_appSession->StopTracker(Vuforia::ObjectTracker::getClassType());
}

bool ImageTargetsView::DoLoadTrackersData()
{
    LOGC(LOGTAG, "DoLoadTrackersData");

    std::unordered_map<std::string, std::string> datasetsInfo
    {
        {"StonesAndChips", "Assets\\ImageTargets\\StonesAndChips.xml"},
        {"Tarmac",         "Assets\\ImageTargets\\Tarmac.xml"},
    };

    m_stonesDataSet = m_appSession->CreateRuntimeImageTargetDataset({ 
        { "stones", "Assets\\ImageTargets\\stones.jpg" },
        { "chips", "Assets\\ImageTargets\\chips.jpg" }
    });
    m_tarmacDataSet = m_appSession->CreateDataSet(datasetsInfo.at("Tarmac").c_str());

    if (m_appSession->ActivateDataSet(m_stonesDataSet))
    {
        m_currentDataSet = m_stonesDataSet;
        return true;
    }
    return false;
}

// ***** Vuforia Event Methods *****
/*
void ImageTargetsView::OnInitARDone()
void ImageTargetsView::OnARStarted()
void ImageTargetsView::OnVuforiaUpdate(VuforiaState ^ vuforiaState)
*/

// This callback is called after the Vuforia initialization is complete,
// the trackers are initialized, their data loaded and
// tracking is ready to start
void ImageTargetsView::OnInitARDone()
{
    LOGC(LOGTAG, "OnInitARDone");

    m_main->GetRenderer()->SetVuforiaInitialized(true);

    m_appSession->ConfigureDisplay(
        m_deviceResources->GetOutputSize(),
        m_deviceResources->GetCurrentOrientation()
    );
}

void ImageTargetsView::OnARStarted()
{
    LOGC(LOGTAG, "OnARStarted");

    m_main->GetRenderer()->SetVuforiaStarted(true);

    m_appSession->ConfigureVideoBackground(
        m_deviceResources->GetOutputSize(),
        m_deviceResources->GetCurrentOrientation()
    );

    // Try enabling continuous autofocus after camera start
    EnableAutofocus();

    // Hide init progress indicator
    HideProgressIndicator();

    // You can set HINT_MAX_SIMULTANEOUS_IMAGE_TARGETS to 2 or more
    // if you wish to track multiple image targets simultaneously
    Vuforia::setHint(Vuforia::HINT_MAX_SIMULTANEOUS_IMAGE_TARGETS, 2);

    Vuforia::onSurfaceCreated();
}

void ImageTargetsView::EnableAutofocus()
{
    m_autofocusEnabled = Vuforia::CameraDevice::getInstance().setFocusMode(
        Vuforia::CameraDevice::FOCUS_MODE_CONTINUOUSAUTO);

    if (!m_autofocusEnabled)
    {
        // Failed, it means continuous autofocus is not supported by this device
        SampleCommon::SampleUtil::Log(LOGTAG, "Failed to enable autofocus.");

        // Fall back to normal focus mode
        Vuforia::CameraDevice::getInstance().setFocusMode(Vuforia::CameraDevice::FOCUS_MODE_NORMAL);

        // Update UI Toggle (switch it OFF)
        Windows::ApplicationModel::Core::CoreApplication::MainView->CoreWindow->Dispatcher->RunAsync(
            Windows::UI::Core::CoreDispatcherPriority::Normal,
            ref new Windows::UI::Core::DispatchedHandler([=]()
        {
            // Update the XAML UI control
            this->ToggleAutofocus->IsOn = false;
        }));
    }
}

// This callback is called every cycle
void ImageTargetsView::OnVuforiaUpdate(VuforiaState^ vuforiaState)
{
    Vuforia::State* state = vuforiaState->m_nativeState;

    // Activating/Deactivating a DataSet can be a blocking operation,
    // so we call the methods in the OnVuforiaUpdate() which
    // ensures that the ObjectTracker will be idle.
    if (m_swapDataset)
    {
        m_swapDataset = false;

        Vuforia::TrackerManager &trackerManager = Vuforia::TrackerManager::getInstance();
        Vuforia::ObjectTracker *objectTracker = static_cast<Vuforia::ObjectTracker*>
            (trackerManager.getTracker(Vuforia::ObjectTracker::getClassType()));

        if (objectTracker != nullptr) {
            Vuforia::DataSet* activeDataset = objectTracker->getActiveDataSets().at(0);
            Vuforia::DataSet* datasetToActivate = (activeDataset == m_stonesDataSet) ?
                m_tarmacDataSet : m_stonesDataSet;

            // Deactivate currently active dataset
            objectTracker->deactivateDataSet(activeDataset);

            // Activate the 'other' dataset
            if (!objectTracker->activateDataSet(datasetToActivate)) {
                SampleCommon::SampleUtil::Log(LOGTAG, "Failed to activate dataset.");
            }

            m_currentDataSet = datasetToActivate;
        }
    }
}

void ImageTargetsView::Stop()
{
    LOGC(LOGTAG, "Stop");

    // Stop rendering when the app is suspended.
    m_main->StopRenderLoop();

    // Notify renderer
    m_main->GetRenderer()->SetVuforiaInitialized(false);

    m_coreInput->Dispatcher->StopProcessEvents();

    // Stop and deinit Vuforia
    m_appSession->StopAR();
}

// ***** XAML UI Button Methods *****
/*
void ImageTargetsView::OnBackButtonClicked(Platform::Object ^ sender, Windows::UI::Xaml::RoutedEventArgs ^ e)
void ImageTargetsView::OnToggleDeviceTracking(Object^ sender, RoutedEventArgs^ e)
void ImageTargetsView::OnToggleAutofocus(Object^ sender, RoutedEventArgs^ e)
void ImageTargetsView::SwitchToDataSet()
*/

void ImageTargetsView::OnBackButtonClicked(Platform::Object ^ sender, Windows::UI::Xaml::RoutedEventArgs ^ e)
{
    LOGC(LOGTAG, "OnBackButtonClicked");

    Stop();

    while (m_appSession->VuforiaInitialized())
    {
        Concurrency::wait(500);
    }

    // Navigate back to Menu Page
    ((Windows::UI::Xaml::Controls::Frame ^)(Window::Current->Content))->Navigate(MenuPage::typeid);
}

void ImageTargetsView::OnToggleDeviceTracking(Object^ sender, RoutedEventArgs^ e)
{
    LOGC(LOGTAG, "OnToggleDeviceTracking");

    ToggleSwitch^ toggleSwitch = (ToggleSwitch^)sender;

    if (m_appSession != nullptr && m_appSession->VuforiaInitialized())
    {
        if (toggleSwitch->IsOn)
        {
            m_deviceTracking = m_appSession->StartTracker(Vuforia::PositionalDeviceTracker::getClassType());
        }
        else
        {
            m_appSession->StopTracker(Vuforia::PositionalDeviceTracker::getClassType());
            m_deviceTracking = false;
        }
        m_main->GetRenderer()->SetDeviceTrackerEnabled(m_deviceTracking);
    }
}

void ImageTargetsView::OnToggleAutofocus(Object^ sender, RoutedEventArgs^ e)
{
    LOGC(LOGTAG, "OnToggleAutofocus");

    ToggleSwitch^ toggleSwitch = (ToggleSwitch^)sender;

    if (m_appSession != nullptr && m_appSession->VuforiaInitialized())
    {
        if (toggleSwitch->IsOn)
        {
            // Try enabling continuous autofocus
            m_autofocusEnabled = Vuforia::CameraDevice::getInstance()
                .setFocusMode(Vuforia::CameraDevice::FOCUS_MODE_CONTINUOUSAUTO);

            if (!m_autofocusEnabled)
            {
                // Failed, it means continuous autofocus is not supported by this device
                SampleCommon::SampleUtil::Log(LOGTAG, "Failed to enabled autofocus.");

                // Fall back to normal focus mode
                Vuforia::CameraDevice::getInstance().setFocusMode(Vuforia::CameraDevice::FOCUS_MODE_NORMAL);

                // Update UI Toggle (switch it OFF)
                toggleSwitch->IsOn = false;
            }
        }
        else
        {
            m_autofocusEnabled = false;
            Vuforia::CameraDevice::getInstance().setFocusMode(Vuforia::CameraDevice::FOCUS_MODE_NORMAL);
        }
    }
}

void ImageTargetsView::ShowTrackingStatus(bool show)
{
    Windows::ApplicationModel::Core::CoreApplication::MainView->CoreWindow->Dispatcher->RunAsync(
        Windows::UI::Core::CoreDispatcherPriority::Normal,
        ref new Windows::UI::Core::DispatchedHandler([=]()
    {
        // Set debug to true if you want to see device tracking status'
        bool debug = false;
        if (debug)
        {
            m_currentTrackingStatusString = LogAndReturnStatusString();
            this->StatusMessage->Text = m_currentTrackingStatusString;
            this->StatusToast->Visibility = Windows::UI::Xaml::Visibility::Visible;
            return;
        }

        if (show)
        {
            this->StatusMessage->Text = m_currentTrackingStatusString;
            this->StatusToast->Visibility = Windows::UI::Xaml::Visibility::Visible;
        }
        else
        {
            this->StatusToast->Visibility = Windows::UI::Xaml::Visibility::Collapsed;
        }
    }));
}

// ***** Vuforia Tracking Timer Event Handlers *****
/*
void ImageTargetsView::InitializeTimers()
void ImageTargetsView::UpdateIntervalTimerTick(Platform::Object^ sender, Platform::Object^ e)
void ImageTargetsView::RelocalizationDelayTimerTick(Platform::Object^ sender, Platform::Object^ e)
void ImageTargetsView::ResetDeviceTrackerTimerTick(Platform::Object^ sender, Platform::Object^ e)
Platform::String^ ImageTargetsView::LogAndReturnStatusString()
*/

void ImageTargetsView::InitializeTimers()
{
    LOGC(LOGTAG, "InitializeTimers");

    const int64 OneSecond = 10'000'000; // One second = 10,000,000 ticks

    // Setup timer to check for tracking status changes at regular interval and update UI
    m_dispatcherTimer = ref new DispatcherTimer();
    timerToken1 = m_dispatcherTimer->Tick += ref new EventHandler<Object^>
        (this, &ImageTargetsView::UpdateIntervalTimerTick);
    m_dispatcherTimer->Interval = TimeSpan{ OneSecond / 2 };
    m_dispatcherTimer->Start();

    // Setup timer to wait for 1 second after receiving a RELOCALIZING tracking status event before proceeding
    m_relocalizationDelayTimer = ref new DispatcherTimer();
    timerToken2 = m_relocalizationDelayTimer->Tick += ref new EventHandler<Object^>
        (this, &ImageTargetsView::RelocalizationDelayTimerTick);
    m_relocalizationDelayTimer->Interval = TimeSpan{ OneSecond };

    // Setup timer to wait for 10 seconds after RELOCALIZING status has been constant for 1 second
    m_resetDeviceTrackerTimer = ref new DispatcherTimer();
    timerToken3 = m_resetDeviceTrackerTimer->Tick += ref new EventHandler<Object^>
        (this, &ImageTargetsView::ResetDeviceTrackerTimerTick);
    m_resetDeviceTrackerTimer->Interval = TimeSpan{ OneSecond * 10 };
}

void ImageTargetsView::UpdateIntervalTimerTick(Platform::Object^ sender, Platform::Object^ e)
{
    const Vuforia::State state = Vuforia::TrackerManager::getInstance().getStateUpdater().getLatestState();

    if (state.getDeviceTrackableResult() != nullptr)
    {
        m_enumStatus = state.getDeviceTrackableResult()->getStatus();
        m_enumStatusInfo = state.getDeviceTrackableResult()->getStatusInfo();
    }

    if (m_enumStatusInfo == Vuforia::TrackableResult::RELOCALIZING)
    {
        if (!m_relocalizationDelayTimer->IsEnabled)
        {
            m_relocalizationDelayTimer->Start();
        }
    }
    else
    {
        // Stop the relocalization and reset timers if they are active
        if (m_relocalizationDelayTimer->IsEnabled)
        {
            m_relocalizationDelayTimer->Stop();
        }

        if (m_resetDeviceTrackerTimer->IsEnabled)
        {
            m_resetDeviceTrackerTimer->Stop();
        }

        // Hide the on-screen status message if status is Normal
        if (m_enumStatusInfo == Vuforia::TrackableResult::NORMAL)
        {
            ShowTrackingStatus(false);
        }
    }
}

void ImageTargetsView::RelocalizationDelayTimerTick(Platform::Object^ sender, Platform::Object^ e)
{
    LOGC(LOGTAG, "RelocalizationDelayTimerTick");

    m_currentTrackingStatusString = "Point back to previously seen area and rescan to relocalize.";

    ShowTrackingStatus(true);

    if (!m_resetDeviceTrackerTimer->IsEnabled)
    {
        m_resetDeviceTrackerTimer->Start();
    }
}

void ImageTargetsView::ResetDeviceTrackerTimerTick(Platform::Object^ sender, Platform::Object^ e)
{
    LOGC(LOGTAG, "ResetDeviceTrackerTimerTick");

    // If timer reaches interval ticks, this method will stop and restart the device tracker
    m_appSession->StopTracker(Vuforia::PositionalDeviceTracker::getClassType());
    if (m_appSession->StartTracker(Vuforia::PositionalDeviceTracker::getClassType()))
    {
        // If DeviceTracker successfully started, then stop our timer
        m_resetDeviceTrackerTimer->Stop();
    }
}

// Status Reporting

Platform::String^ ImageTargetsView::LogAndReturnStatusString()
{
    /* STATUS:
    NO_POSE = No pose was delivered for the trackable.
    LIMITED = The trackable is being tracked in a limited form.
    DETECTED = The trackable was detected.
    TRACKED = The trackable is being tracked.
    EXTENDED_TRACKED = The trackable is being tracked using extended tracking.
    */

    /* STATUS_INFO
    NORMAL = Status is normal, ie not NO_POSE or LIMITED.
    UNKNOWN = Unknown reason for the tracking status.
    INITIALIZING = The tracking system is currently initializing.
    RELOCALIZING = The tracking system is currently relocalizing.
    EXCESSIVE_MOTION = The device is moving too fast.
    INSUFFICIENT_FEATURES = There are insufficient features available in the scene.
    */

    std::wstring status;
    std::wstring statusInfo;

    switch (this->m_enumStatus)
    {
    case Vuforia::TrackableResult::NO_POSE:
        status = L"NO_POSE";
        break;
    case Vuforia::TrackableResult::LIMITED:
        status = L"LIMITED";
        break;
    case Vuforia::TrackableResult::DETECTED:
        status = L"DETECTED";
        break;
    case Vuforia::TrackableResult::TRACKED:
        status = L"TRACKED";
        break;
    case Vuforia::TrackableResult::EXTENDED_TRACKED:
        status = L"EXTENDED_TRACKED";
        break;
    }

    switch (this->m_enumStatusInfo)
    {
    case Vuforia::TrackableResult::NORMAL:
        statusInfo = L"NORMAL";
        break;
    case Vuforia::TrackableResult::UNKNOWN:
        statusInfo = L"UNKNOWN";
        break;
    case Vuforia::TrackableResult::INITIALIZING:
        statusInfo = L"INITIALIZING";
        break;
    case Vuforia::TrackableResult::RELOCALIZING:
        statusInfo = L"RELOCALIZING";
        break;
    case Vuforia::TrackableResult::EXCESSIVE_MOTION:
        statusInfo = L"EXCESSIVE_MOTION";
        break;
    case Vuforia::TrackableResult::INSUFFICIENT_FEATURES:
        statusInfo = L"INSUFFICIENT_FEATURES";
        break;
    }

    // Report Status and StatusInfo Changes
    std::wstring combinedStatus = L"Status: " + status + L" -- StatusInfo: " + statusInfo;

    OutputDebugString((combinedStatus + L"\n").c_str());

    return ref new String(combinedStatus.c_str());
}

// ImageTarget Methods

void ImageTargetsView::OnSwitchDataSet(Object^ sender, RoutedEventArgs^ e)
{
    LOGC(LOGTAG, "OnSwitchDataSet");

    SwitchToDataSet();
}

void ImageTargetsView::OnSwapDataSet(Object^ sender, RoutedEventArgs^ e)
{
    LOGC(LOGTAG, "OnSwapDataset");

    if (m_appSession != nullptr && m_appSession->VuforiaInitialized())
    {
        // The swap will occur in the OnVuforiaUpdate() callback.
        m_swapDataset = true;
    }
}

void ImageTargetsView::SwitchToDataSet()
{
    LOGC(LOGTAG, "SwitchToDataSet");

    Vuforia::TrackerManager &trackerManager = Vuforia::TrackerManager::getInstance();
    Vuforia::ObjectTracker *objectTracker = static_cast<Vuforia::ObjectTracker*>
        (trackerManager.getTracker(Vuforia::ObjectTracker::getClassType()));

    if (objectTracker != nullptr) {
        Vuforia::DataSet* activeDataset = objectTracker->getActiveDataSets().at(0);
        Vuforia::DataSet* datasetToActivate = (activeDataset == m_stonesDataSet) ?
            m_tarmacDataSet : m_stonesDataSet;

        // Deactivate currently active dataset
        objectTracker->deactivateDataSet(activeDataset);

        // Activate the 'other' dataset
        if (!objectTracker->activateDataSet(datasetToActivate)) {
            SampleCommon::SampleUtil::Log(LOGTAG, "Failed to activate dataset.");
        }

        m_currentDataSet = datasetToActivate;
    }
}
