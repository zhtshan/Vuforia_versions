/*===============================================================================
Copyright (c) 2020 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

#pragma once

#include "pch.h"
#include <math.h>
#include <Vuforia/Vectors.h>
#include <Vuforia/Matrices.h>

static const float M_PI = 3.14159f;

/// Utility class for Math operations.
class SampleAppMathUtils
{
public:

    /// Return an identify 4x4 matrix
    static Vuforia::Matrix44F Matrix44FIdentity();

    /// Transpose a 4x4 matrix and return the result (result = transpose(m))
    static Vuforia::Matrix44F Matrix44FTranspose(const Vuforia::Matrix44F& m);

    /// Compute the determinate of a 4x4 matrix and return the result ( result = det(m) )
    static float Matrix44FDeterminate(const Vuforia::Matrix44F& m);

    /// Computer the inverse of the matrix and return the result ( result = inverse(m) )
    static Vuforia::Matrix44F Matrix44FInverse(const Vuforia::Matrix44F& m);

    static void makeRotationMatrix(float angle, const Vuforia::Vec3F& axis, Vuforia::Matrix44F& m);
    static void makeTranslationMatrix(const Vuforia::Vec3F& trans, Vuforia::Matrix44F& m);
    static void makeScalingMatrix(const Vuforia::Vec3F& scale, Vuforia::Matrix44F& m);
    static void multiplyMatrix(const Vuforia::Matrix44F& matrixA, const Vuforia::Matrix44F& matrixB, Vuforia::Matrix44F& matrixC);
    static void convertPoseBetweenWorldAndCamera(const Vuforia::Matrix44F& matrixIn, Vuforia::Matrix44F& matrixOut);

    static void convertPoseFromGLtoDX(const Vuforia::Matrix44F& poseGL, DirectX::XMFLOAT4X4& poseDX);
};
