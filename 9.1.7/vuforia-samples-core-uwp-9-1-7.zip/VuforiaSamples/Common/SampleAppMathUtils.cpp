/*===============================================================================
Copyright (c) 2020 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

#include "pch.h"

#include <math.h>

#include "SampleAppMathUtils.h"

Vuforia::Matrix44F SampleAppMathUtils::Matrix44FIdentity()
{
    Vuforia::Matrix44F r;

    for (int i = 0; i < 16; i++)
        r.data[i] = 0.0f;

    r.data[0] = 1.0f;
    r.data[5] = 1.0f;
    r.data[10] = 1.0f;
    r.data[15] = 1.0f;

    return r;
}

Vuforia::Matrix44F SampleAppMathUtils::Matrix44FTranspose(const Vuforia::Matrix44F& m)
{
    Vuforia::Matrix44F r;
    for (int i = 0; i < 4; i++)
        for (int j = 0; j < 4; j++)
            r.data[i * 4 + j] = m.data[i + 4 * j];
    return r;
}


float SampleAppMathUtils::Matrix44FDeterminate(const Vuforia::Matrix44F& m)
{
    return  m.data[12] * m.data[9] * m.data[6] * m.data[3] - m.data[8] * m.data[13] * m.data[6] * m.data[3] -
        m.data[12] * m.data[5] * m.data[10] * m.data[3] + m.data[4] * m.data[13] * m.data[10] * m.data[3] +
        m.data[8] * m.data[5] * m.data[14] * m.data[3] - m.data[4] * m.data[9] * m.data[14] * m.data[3] -
        m.data[12] * m.data[9] * m.data[2] * m.data[7] + m.data[8] * m.data[13] * m.data[2] * m.data[7] +
        m.data[12] * m.data[1] * m.data[10] * m.data[7] - m.data[0] * m.data[13] * m.data[10] * m.data[7] -
        m.data[8] * m.data[1] * m.data[14] * m.data[7] + m.data[0] * m.data[9] * m.data[14] * m.data[7] +
        m.data[12] * m.data[5] * m.data[2] * m.data[11] - m.data[4] * m.data[13] * m.data[2] * m.data[11] -
        m.data[12] * m.data[1] * m.data[6] * m.data[11] + m.data[0] * m.data[13] * m.data[6] * m.data[11] +
        m.data[4] * m.data[1] * m.data[14] * m.data[11] - m.data[0] * m.data[5] * m.data[14] * m.data[11] -
        m.data[8] * m.data[5] * m.data[2] * m.data[15] + m.data[4] * m.data[9] * m.data[2] * m.data[15] +
        m.data[8] * m.data[1] * m.data[6] * m.data[15] - m.data[0] * m.data[9] * m.data[6] * m.data[15] -
        m.data[4] * m.data[1] * m.data[10] * m.data[15] + m.data[0] * m.data[5] * m.data[10] * m.data[15];
}


Vuforia::Matrix44F SampleAppMathUtils::Matrix44FInverse(const Vuforia::Matrix44F& m)
{
    Vuforia::Matrix44F r;

    float det = 1.0f / Matrix44FDeterminate(m);

    r.data[0] = m.data[6] * m.data[11] * m.data[13] - m.data[7] * m.data[10] * m.data[13]
        + m.data[7] * m.data[9] * m.data[14] - m.data[5] * m.data[11] * m.data[14]
        - m.data[6] * m.data[9] * m.data[15] + m.data[5] * m.data[10] * m.data[15];

    r.data[4] = m.data[3] * m.data[10] * m.data[13] - m.data[2] * m.data[11] * m.data[13]
        - m.data[3] * m.data[9] * m.data[14] + m.data[1] * m.data[11] * m.data[14]
        + m.data[2] * m.data[9] * m.data[15] - m.data[1] * m.data[10] * m.data[15];

    r.data[8] = m.data[2] * m.data[7] * m.data[13] - m.data[3] * m.data[6] * m.data[13]
        + m.data[3] * m.data[5] * m.data[14] - m.data[1] * m.data[7] * m.data[14]
        - m.data[2] * m.data[5] * m.data[15] + m.data[1] * m.data[6] * m.data[15];

    r.data[12] = m.data[3] * m.data[6] * m.data[9] - m.data[2] * m.data[7] * m.data[9]
        - m.data[3] * m.data[5] * m.data[10] + m.data[1] * m.data[7] * m.data[10]
        + m.data[2] * m.data[5] * m.data[11] - m.data[1] * m.data[6] * m.data[11];

    r.data[1] = m.data[7] * m.data[10] * m.data[12] - m.data[6] * m.data[11] * m.data[12]
        - m.data[7] * m.data[8] * m.data[14] + m.data[4] * m.data[11] * m.data[14]
        + m.data[6] * m.data[8] * m.data[15] - m.data[4] * m.data[10] * m.data[15];

    r.data[5] = m.data[2] * m.data[11] * m.data[12] - m.data[3] * m.data[10] * m.data[12]
        + m.data[3] * m.data[8] * m.data[14] - m.data[0] * m.data[11] * m.data[14]
        - m.data[2] * m.data[8] * m.data[15] + m.data[0] * m.data[10] * m.data[15];

    r.data[9] = m.data[3] * m.data[6] * m.data[12] - m.data[2] * m.data[7] * m.data[12]
        - m.data[3] * m.data[4] * m.data[14] + m.data[0] * m.data[7] * m.data[14]
        + m.data[2] * m.data[4] * m.data[15] - m.data[0] * m.data[6] * m.data[15];

    r.data[13] = m.data[2] * m.data[7] * m.data[8] - m.data[3] * m.data[6] * m.data[8]
        + m.data[3] * m.data[4] * m.data[10] - m.data[0] * m.data[7] * m.data[10]
        - m.data[2] * m.data[4] * m.data[11] + m.data[0] * m.data[6] * m.data[11];

    r.data[2] = m.data[5] * m.data[11] * m.data[12] - m.data[7] * m.data[9] * m.data[12]
        + m.data[7] * m.data[8] * m.data[13] - m.data[4] * m.data[11] * m.data[13]
        - m.data[5] * m.data[8] * m.data[15] + m.data[4] * m.data[9] * m.data[15];

    r.data[6] = m.data[3] * m.data[9] * m.data[12] - m.data[1] * m.data[11] * m.data[12]
        - m.data[3] * m.data[8] * m.data[13] + m.data[0] * m.data[11] * m.data[13]
        + m.data[1] * m.data[8] * m.data[15] - m.data[0] * m.data[9] * m.data[15];

    r.data[10] = m.data[1] * m.data[7] * m.data[12] - m.data[3] * m.data[5] * m.data[12]
        + m.data[3] * m.data[4] * m.data[13] - m.data[0] * m.data[7] * m.data[13]
        - m.data[1] * m.data[4] * m.data[15] + m.data[0] * m.data[5] * m.data[15];

    r.data[14] = m.data[3] * m.data[5] * m.data[8] - m.data[1] * m.data[7] * m.data[8]
        - m.data[3] * m.data[4] * m.data[9] + m.data[0] * m.data[7] * m.data[9]
        + m.data[1] * m.data[4] * m.data[11] - m.data[0] * m.data[5] * m.data[11];

    r.data[3] = m.data[6] * m.data[9] * m.data[12] - m.data[5] * m.data[10] * m.data[12]
        - m.data[6] * m.data[8] * m.data[13] + m.data[4] * m.data[10] * m.data[13]
        + m.data[5] * m.data[8] * m.data[14] - m.data[4] * m.data[9] * m.data[14];

    r.data[7] = m.data[1] * m.data[10] * m.data[12] - m.data[2] * m.data[9] * m.data[12]
        + m.data[2] * m.data[8] * m.data[13] - m.data[0] * m.data[10] * m.data[13]
        - m.data[1] * m.data[8] * m.data[14] + m.data[0] * m.data[9] * m.data[14];

    r.data[11] = m.data[2] * m.data[5] * m.data[12] - m.data[1] * m.data[6] * m.data[12]
        - m.data[2] * m.data[4] * m.data[13] + m.data[0] * m.data[6] * m.data[13]
        + m.data[1] * m.data[4] * m.data[14] - m.data[0] * m.data[5] * m.data[14];

    r.data[15] = m.data[1] * m.data[6] * m.data[8] - m.data[2] * m.data[5] * m.data[8]
        + m.data[2] * m.data[4] * m.data[9] - m.data[0] * m.data[6] * m.data[9]
        - m.data[1] * m.data[4] * m.data[10] + m.data[0] * m.data[5] * m.data[10];

    for (int i = 0; i < 16; i++)
        r.data[i] *= det;

    return r;
}

void SampleAppMathUtils::makeRotationMatrix(float angle, const Vuforia::Vec3F& axis, Vuforia::Matrix44F& m)
{
    double radians, c, s, c1, u[3], length;
    int i, j;

    m = Matrix44FIdentity();

    radians = (angle * M_PI) / 180.0;

    c = cos(radians);
    s = sin(radians);

    c1 = 1.0 - cos(radians);

    length = sqrt(axis.data[0] * axis.data[0] + axis.data[1] * axis.data[1] + axis.data[2] * axis.data[2]);

    u[0] = axis.data[0] / length;
    u[1] = axis.data[1] / length;
    u[2] = axis.data[2] / length;

    for (i = 0; i < 16; i++)
        m.data[i] = 0.0;

    m.data[15] = 1.0;

    for (i = 0; i < 3; i++)
    {
        m.data[i * 4 + (i + 1) % 3] = (float)(u[(i + 2) % 3] * s);
        m.data[i * 4 + (i + 2) % 3] = (float)(-u[(i + 1) % 3] * s);
    }

    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 3; j++)
            m.data[i * 4 + j] += (float)(c1 * u[i] * u[j] + (i == j ? c : 0.0));
    }
}


void SampleAppMathUtils::makeTranslationMatrix(const Vuforia::Vec3F& trans, Vuforia::Matrix44F& m)
{
    m = Matrix44FIdentity();

    m.data[12] = trans.data[0];
    m.data[13] = trans.data[1];
    m.data[14] = trans.data[2];
}

void SampleAppMathUtils::makeScalingMatrix(const Vuforia::Vec3F& scale, Vuforia::Matrix44F& m)
{
    m = Matrix44FIdentity();

    m.data[0] = scale.data[0];
    m.data[5] = scale.data[1];
    m.data[10] = scale.data[2];
}

void SampleAppMathUtils::multiplyMatrix(const Vuforia::Matrix44F& matrixA, const Vuforia::Matrix44F& matrixB, Vuforia::Matrix44F& matrixC)
{
    int i, j, k;
    Vuforia::Matrix44F aTmp;

    // matrixC= matrixA * matrixB
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 4; j++)
        {
            aTmp.data[j * 4 + i] = 0.0;

            for (k = 0; k < 4; k++)
                aTmp.data[j * 4 + i] += matrixA.data[k * 4 + i] * matrixB.data[j * 4 + k];
        }
    }

    for (i = 0; i < 16; i++)
        matrixC.data[i] = aTmp.data[i];
}


void SampleAppMathUtils::convertPoseBetweenWorldAndCamera(const Vuforia::Matrix44F& matrixIn, Vuforia::Matrix44F& matrixOut)
{
    // Transform trackable pose from World Coordinate System to Camera Coordinate System
    // (180 degree rotation between both CS)
    Vuforia::Matrix44F convertCS;
    makeRotationMatrix(180.0f, Vuforia::Vec3F(1.0f, 0.0f, 0.0f), convertCS);

    Vuforia::Matrix44F tmp;
    multiplyMatrix(convertCS, matrixIn, tmp);

    for (int i = 0; i < 16; i++)
        matrixOut.data[i] = tmp.data[i];
}


void SampleAppMathUtils::convertPoseFromGLtoDX(const Vuforia::Matrix44F& poseGL, DirectX::XMFLOAT4X4& poseDX)
{
    // Set up the modelview matrix
    memcpy(poseDX.m, poseGL.data, sizeof(float) * 16);

    // Convert from Vuforia RH to DX LH
    XMStoreFloat4x4(&poseDX, XMMatrixTranspose(XMLoadFloat4x4(&poseDX)));
}
