/*===============================================================================
Copyright (c) 2020 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

#include "pch.h"
#include "DebugLog.h"

#include <cstdarg>
#include <cstdio>
#include <debugapi.h>

static const size_t MAX_LOG_MESSAGE = 200;

void LOG(const char* format, ...)
{
    char output[MAX_LOG_MESSAGE + 2]; // Add space for EOL and terminator
    std::va_list arg;
    va_start(arg, format);
    vsnprintf_s(output, MAX_LOG_MESSAGE, format, arg);
    va_end(arg);
    strcat_s(output, "\n");

    OutputDebugStringA(output);
}

void LOGC(Platform::String^ className, Platform::String^ funcName)
{
    Platform::String^ msg = className + "::" + funcName + "() called.\n";
    OutputDebugString(msg->Data());
}
