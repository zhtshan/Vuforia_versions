/*===============================================================================
Copyright (c) 2020 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

#pragma once

#include "Xaml/SplashPage.g.h"
#include "MenuPage.xaml.h"

using namespace Windows::UI::Xaml;

namespace VuforiaSamples
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    [Windows::Foundation::Metadata::WebHostHidden]
    public ref class SplashPage sealed
    {
    public:
        SplashPage();

    private:

        Platform::String^ LOGTAG = "SplashPage";

        void OnSuspending(Platform::Object^ sender, Windows::ApplicationModel::SuspendingEventArgs^ e);
        void OnResuming(Platform::Object ^sender, Platform::Object ^args);

        void SplashTimerTick(Platform::Object ^ sender, Platform::Object ^ e);

        DispatcherTimer^ dispatcherTimer;
    };
}
