/*===============================================================================
Copyright (c) 2020 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

#pragma once

#include "Xaml/AboutPage.g.h"

namespace VuforiaSamples
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    [Windows::Foundation::Metadata::WebHostHidden]
    public ref class AboutPage sealed
    {
    public:
        AboutPage();
        virtual ~AboutPage();


    private:

        Platform::String^ LOGTAG = "AboutPage";

        void OnSuspending(Platform::Object^ sender, Windows::ApplicationModel::SuspendingEventArgs^ e);

        void OnResuming(Platform::Object ^sender, Platform::Object ^args);

        void OnStartButtonClicked(Platform::Object^ sender, Windows::UI::Xaml::RoutedEventArgs^ e);

        void OnBackButtonClicked(Platform::Object^ sender, Windows::UI::Xaml::RoutedEventArgs^ e);

        Windows::Foundation::EventRegistrationToken m_suspendingToken;
        Windows::Foundation::EventRegistrationToken m_resumingToken;

    protected:
        void OnNavigatedFrom(Windows::UI::Xaml::Navigation::NavigationEventArgs^ e) override;
        void OnNavigatedTo(Windows::UI::Xaml::Navigation::NavigationEventArgs^ e) override;
    };
}
