/*===============================================================================
Copyright (c) 2020 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

#include "pch.h"
#include "AboutPage.xaml.h"

#include "Features/ImageTargets/ImageTargetsView.xaml.h"
#include "Features/GroundPlane/GroundPlaneView.xaml.h"
#include "Features/VuMarks/VuMarksView.xaml.h"

using namespace VuforiaSamples;

using namespace Platform;
using namespace Windows::Foundation;
using namespace Windows::Foundation::Collections;
using namespace Windows::UI::Xaml;
using namespace Windows::UI::Xaml::Controls;
using namespace Windows::UI::Xaml::Controls::Primitives;
using namespace Windows::UI::Xaml::Data;
using namespace Windows::UI::Xaml::Input;
using namespace Windows::UI::Xaml::Media;
using namespace Windows::UI::Xaml::Navigation;


AboutPage::AboutPage()
{
    LOGC(LOGTAG, "AboutPage");

    InitializeComponent();

    Application^ app = Application::Current;
    m_suspendingToken =
        app->Suspending += ref new SuspendingEventHandler(this, &AboutPage::OnSuspending);
    m_resumingToken =
        app->Resuming += ref new EventHandler<Object^>(this, &AboutPage::OnResuming);
}

AboutPage::~AboutPage()
{
    LOGC(LOGTAG, "~AboutPage");

    Application^ app = Application::Current;
    app->Suspending -= m_suspendingToken;
    app->Resuming -= m_resumingToken;
}

void AboutPage::OnSuspending(Platform::Object ^ sender, Windows::ApplicationModel::SuspendingEventArgs ^ e)
{
    LOGC(LOGTAG, "OnSuspending");
}

void AboutPage::OnResuming(Platform::Object ^ sender, Platform::Object ^ args)
{
    LOGC(LOGTAG, "OnResuming");
}

void AboutPage::OnNavigatedFrom(Windows::UI::Xaml::Navigation::NavigationEventArgs^ e)
{
    LOGC(LOGTAG, "OnNavigatedFrom");
}

void AboutPage::OnNavigatedTo(Windows::UI::Xaml::Navigation::NavigationEventArgs^ e)
{
    LOGC(LOGTAG, "OnNavigatedTo");

    Title->Text = (String^)e->Parameter;

    Platform::Collections::UnorderedMap<String^, String^> htmlContent
    {
        {"ImageTargets", "ms-appx-web:///Assets/ImageTargets/IT_about.html"},
        {"VuMarks", "ms-appx-web:///Assets/VuMarks/VM_about.html"},
        {"GroundPlane", "ms-appx-web:///Assets/GroundPlane/GP_about.html"}
    };

    String^ HTMLContent = htmlContent.Lookup(Title->Text);

    // In apps compiled for Windows 10, WebView uses the Microsoft Edge rendering engine
    // to display HTML content. In apps compiled for Windows 8 or Windows 8.1, WebView
    // uses Internet Explorer 11 in document mode. It does not support any Microsoft
    // ActiveX controls or plugins like Microsoft Silverlight or Portable Document Format
    // (PDF) files.
    // Source: https://docs.microsoft.com/en-us/uwp/api/windows.ui.xaml.controls.webview

    // The HTML file's Content property must be True for file to successfully load.
    Uri^ aboutPageHtml = ref new Uri(HTMLContent);

    aboutText->Navigate(aboutPageHtml);
}


void AboutPage::OnStartButtonClicked(Platform::Object ^ sender, Windows::UI::Xaml::RoutedEventArgs ^ e)
{
    if (Title->Text == "ImageTargets")
    {
        ((Windows::UI::Xaml::Controls::Frame ^)(Window::Current->Content))->Navigate(ImageTargets::ImageTargetsView::typeid);
    }

    if (Title->Text == "VuMarks")
    {
        ((Windows::UI::Xaml::Controls::Frame ^)(Window::Current->Content))->Navigate(VuMarks::VuMarksView::typeid);
    }

    if (Title->Text == "GroundPlane")
    {
        ((Windows::UI::Xaml::Controls::Frame ^)(Window::Current->Content))->Navigate(GroundPlane::GroundPlaneView::typeid);
    }
}

void AboutPage::OnBackButtonClicked(Platform::Object ^ sender, Windows::UI::Xaml::RoutedEventArgs ^ e)
{
    ((Windows::UI::Xaml::Controls::Frame ^)(Window::Current->Content))->Navigate(MenuPage::typeid);
}
