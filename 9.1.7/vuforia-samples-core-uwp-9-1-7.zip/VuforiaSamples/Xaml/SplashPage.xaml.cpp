/*===============================================================================
Copyright (c) 2020 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

#include "pch.h"
#include "SplashPage.xaml.h"

using namespace VuforiaSamples;

using namespace Platform;
using namespace Windows::Foundation;
using namespace Windows::Foundation::Collections;
using namespace Windows::UI::Xaml;
using namespace Windows::UI::Xaml::Controls;
using namespace Windows::UI::Xaml::Controls::Primitives;
using namespace Windows::UI::Xaml::Data;
using namespace Windows::UI::Xaml::Input;
using namespace Windows::UI::Xaml::Media;
using namespace Windows::UI::Xaml::Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

SplashPage::SplashPage()
{
    LOGC(LOGTAG, "SplashPage");

    InitializeComponent();

    // TimeSpan value is the number of 100-nanosecond intervals
    // A value of 10,000,000 equals 1 second
    TimeSpan splashPageDuration = { 10'000'000 * 2 };
    dispatcherTimer = ref new DispatcherTimer();
    dispatcherTimer->Tick += ref new EventHandler<Object^>(this, &SplashPage::SplashTimerTick);
    dispatcherTimer->Interval = splashPageDuration;
    dispatcherTimer->Start();
}

void SplashPage::OnSuspending(Platform::Object ^ sender, Windows::ApplicationModel::SuspendingEventArgs ^ e)
{
    LOGC(LOGTAG, "OnSuspending");
}

void SplashPage::OnResuming(Platform::Object ^ sender, Platform::Object ^ args)
{
    LOGC(LOGTAG, "OnResuming");
}

void SplashPage::SplashTimerTick(Platform::Object ^ sender, Platform::Object ^ e)
{
    LOGC(LOGTAG, "SplashTimerTick");

    dispatcherTimer->Stop();

    ((Windows::UI::Xaml::Controls::Frame ^)(Window::Current->Content))->Navigate(MenuPage::typeid);
}
