/*===============================================================================
Copyright (c) 2020 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

#pragma once

#include "Xaml/MenuPage.g.h"
#include "AboutPage.xaml.h"

namespace VuforiaSamples
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    [Windows::Foundation::Metadata::WebHostHidden]
    public ref class MenuPage sealed
    {
    public:
        MenuPage();
        virtual ~MenuPage();


    private:

        Platform::String^ LOGTAG = "MenuPage";

        void OnMenuButtonClicked(Platform::Object^ sender, Windows::UI::Xaml::RoutedEventArgs^ e);

    protected:
        void OnNavigatedFrom(Windows::UI::Xaml::Navigation::NavigationEventArgs^ e) override;
        void OnNavigatedTo(Windows::UI::Xaml::Navigation::NavigationEventArgs^ e) override;
    };
}
