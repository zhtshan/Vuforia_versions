/*===============================================================================
Copyright (c) 2020 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

#include "pch.h"
#include "MenuPage.xaml.h"

using namespace VuforiaSamples;

using namespace Platform;
using namespace Windows::Foundation;
using namespace Windows::Foundation::Collections;
using namespace Windows::UI::Xaml;
using namespace Windows::UI::Xaml::Controls;
using namespace Windows::UI::Xaml::Controls::Primitives;
using namespace Windows::UI::Xaml::Data;
using namespace Windows::UI::Xaml::Input;
using namespace Windows::UI::Xaml::Media;
using namespace Windows::UI::Xaml::Navigation;


MenuPage::MenuPage()
{
    LOGC(LOGTAG, "MenuPage");

    InitializeComponent();
}

MenuPage::~MenuPage()
{
    LOGC(LOGTAG, "~MenuPage");
}

void MenuPage::OnMenuButtonClicked(Platform::Object^ sender, Windows::UI::Xaml::RoutedEventArgs^ e)
{
    LOGC(LOGTAG, "OnMenuButtonClicked");

    if ((((Button^)(sender))->Content) != nullptr)
    {
        ((Windows::UI::Xaml::Controls::Frame ^)(Window::Current->Content))->Navigate(AboutPage::typeid, (((Button^)(sender))->Name));
    }
}

void MenuPage::OnNavigatedFrom(Windows::UI::Xaml::Navigation::NavigationEventArgs^ e)
{
    LOGC(LOGTAG, "OnNavigatedFrom");
}

void MenuPage::OnNavigatedTo(Windows::UI::Xaml::Navigation::NavigationEventArgs^ e)
{
    LOGC(LOGTAG, "OnNavigatedTo");
}
