# Vuforia Samples

The Vuforia Samples native UWP application demonstrates the following features of the Vuforia SDK:

* Image Targets
* VuMarks
* Ground Plane

### Image Targets

The Image Targets sample shows how to detect multiple image targets and render 3d content at their locations.

### VuMarks

The VuMarks sample shows how to detect and track multiple instances of a VuMark.

### Ground Plane

The Ground Plane sample demonstrates how to place content on surfaces and in mid-air using anchor points.


#### Using the Samples

Each sample has a help screen with instructions. For further details about native UWP development with Vuforia, please see our online Vuforia Library.

https://library.vuforia.com/getting-started/overview.html
