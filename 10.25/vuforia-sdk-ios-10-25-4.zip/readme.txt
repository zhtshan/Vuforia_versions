=================================================================
Vuforia Augmented Reality SDK v10.25.4 Release Package
=================================================================

This package has the following structure:

    build\                            Vuforia SDK
      lib\
        arm64\
          VuforiaEngine.framework     iOS Framework
    licenses\                         License agreements
    samples\                          Destination folder for sample applications
      readme.txt                      Instructions for downloading and installing the sample applications
    readme.txt                        This document


To get started, go to https://developer.vuforia.com/, where you will find detailed 
documentation on developing AR apps using the Vuforia SDK and a brief description 
of the online Target Manager.

To view the SDK license agreement, go to https://developer.vuforia.com/legal/vuforia-developer-agreement

To view the release notes, go to https://library.vuforia.com/articles/Release_Notes/Vuforia-SDK-Release-Notes.html


/*============================================================================

Copyright (c) 2010-2024 PTC Inc. and/or Its Subsidiary Companies.
All Rights Reserved.

Copyright for PTC software products is with PTC Inc. and its subsidiary
companies (collectively "PTC"), and their respective licensors. This software
is provided under written license or other agreement, contains valuable trade
secrets and proprietary information, and is protected by the copyright laws of
the United States and other countries. It may not be copied or distributed in
any form or medium, disclosed to third parties, or used in any manner not
provided for in the applicable agreement except with written prior approval
from PTC. More information regarding third party copyrights and trademarks and
a list of PTC's registered copyrights, trademarks, and patents can be viewed
here: www.ptc.com/support/go/copyright-and-trademarks 

  ============================================================================*/
