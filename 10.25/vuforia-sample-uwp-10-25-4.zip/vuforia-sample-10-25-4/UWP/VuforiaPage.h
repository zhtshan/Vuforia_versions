/*===============================================================================
Copyright (c) 2023 PTC Inc. and/or Its Subsidiary Companies. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

#pragma once

#include "VuforiaPage.g.h"

#include "Rendering/DXRenderer.h"
#include "Rendering/DeviceResources.h"
#include "Rendering/StepTimer.h"
#include <AppController.h>

#include <winrt/Windows.Foundation.h>

#include <atomic>
#include <future>
#include <mutex>


namespace winrt::VuforiaSample::implementation
{
struct VuforiaPage : VuforiaPageT<VuforiaPage>, public DX::IDeviceNotify
{
    VuforiaPage();
    ~VuforiaPage();

    void OnNavigatedTo(Windows::UI::Xaml::Navigation::NavigationEventArgs const& e);
    void OnNavigatingFrom(Windows::UI::Xaml::Navigation::NavigatingCancelEventArgs const& e);

    void OnBackButtonClicked(Windows::Foundation::IInspectable const& sender, Windows::UI::Xaml::RoutedEventArgs const& args);
    void OnPointerPressed(Windows::UI::Xaml::Input::PointerRoutedEventArgs const& args);

    // IDeviceNotify
    void OnDeviceLost();
    void OnDeviceRestored();

private: // methods
    winrt::fire_and_forget InitVuforia(int32_t target);
    winrt::fire_and_forget DeinitVuforiaAndGoBack();

    void OnSuspending(Windows::Foundation::IInspectable const& sender, Windows::ApplicationModel::SuspendingEventArgs const& e);
    void OnResuming(Windows::Foundation::IInspectable const& sender, Windows::Foundation::IInspectable const& args);
    void OnVisibilityChanged(Windows::UI::Core::CoreWindow const& sender, Windows::UI::Core::VisibilityChangedEventArgs const& args);

    winrt::fire_and_forget HandleSizeChanged(Windows::UI::Xaml::SizeChangedEventArgs const& args);
    winrt::fire_and_forget HandleTap();

    /// Performs application lifecycle change tasks ensuring overlapping suspend/resume notifications are handled
    /*
     * This method does not support concurrent invocations. It is expected that it is only called from the single 'main' (aka UI) thread of
     * the App.
     *
     * \param appShouldRun   Bool flag indicating the desired outcome of the lifecycle operation.
     * \param deferral       Optional UWP app suspend deferral token. Will be release when the operation is completed.
     */
    void TriggerLifecycleOperation(bool appShouldRun, winrt::Windows::ApplicationModel::SuspendingDeferral deferral = nullptr);

    /// Callback from AppController when an error occurs
    winrt::fire_and_forget PresentError(const char* error);
    /// Callback from AppController when Vuforia initialization completes
    winrt::fire_and_forget InitDone();

    // DirectX rendering
    void CreateWindowSizeDependentResources();
    void StartRenderLoop();
    void StopRenderLoop();
    /// Updates the application state once per frame.
    void Update();
    /// Process all input from the user before updating game state.
    void ProcessInput();
    /// Render content each frame.
    bool Render();

private: // data members
    event_token mSuspendingToken;
    event_token mResumingToken;
    event_token mVisibilityChangedToken;

    event_token mDpiChangedToken;
    event_token mOrientationChangedToken;
    event_token mDisplayContentsInvalidatedToken;

    /// Mutex to manage interaction between UI and render thread
    std::mutex mCriticalSection;

    /// Resources used to render the DirectX content in the XAML page background.
    std::shared_ptr<winrt::DX::DeviceResources> mDeviceResources;

    AppController mController;
    bool mVuforiaInitializing = false;
    std::atomic<bool> mVuforiaStarted = false;

    /// Flag to tell the render loop when to update Vuforia with a new rendering configuration
    std::atomic<bool> mRenderingConfigurationChanged{ true };

    Windows::Graphics::Display::DisplayOrientations mOrientation;
    /// Flag to record when an orientation change notification has been received, reset when applied
    std::atomic<bool> mOrientationChanged{ false };
    /// The number of update loops for which mOrientationChanged has been true
    int mOrientationChangePendingCount{ 0 };
    /// The number of update loops to wait before applying an orientation change
    static constexpr int PENDING_ORIENTATION_CHANGE_THRESHOLD = 10;

    Windows::Foundation::Size mSwapChainPanelSize;
    /// Flag to record when a size change notification has been received, reset when applied
    std::atomic<bool> mSwapChainPanelSizeChanged{ true };

    // DirectX renderer
    std::unique_ptr<DXRenderer> mRenderer;

    /// Render loop worker task
    Windows::Foundation::IAsyncAction mRenderLoopWorker;
    /// Rendering loop timer
    SampleCommon::StepTimer mTimer;


    /* For suspending and resuming we use asynchronous tasks.
     * This is necessary because pausing and resuming Vuforia takes
     * too long to run on the UI thread and the platform doesn't allow this.
     * We need to ensure that these don't end up running concurrently and
     * that we always end up in the desired state even if the user
     * repeatedly suspend/resumes the app.
     *
     * For every lifecycle event (suspend/resume/visibility changed) another
     * asynchronous continuation task is queued. This chain of lifecycle operations
     * continues to change the application state until the expected state is reached.
     * If the expected state has been reached, all pending tasks will skip their
     * state change and exit quickly.
     */

    /// Expected lifecycle state of the application
    std::atomic<bool> mAppShouldBeRunning{ false };

    /// Count of app lifecycle events
    /*
     * This is used to detect if asynchronous events happened,
     * while another lifecycle operation was in progress.
     */
    std::atomic<size_t> mLifecycleEventCount{ 0 };

    /// Reference to any ongoing lifecycle operation
    /*
     * The result of this task represents the current application state (true if app is running; false otherwise).
     */
    concurrency::task<bool> mLifecycleOperation = concurrency::task_from_result(false);
};
}

namespace winrt::VuforiaSample::factory_implementation
{
struct VuforiaPage : VuforiaPageT<VuforiaPage, implementation::VuforiaPage>
{
};
}
