﻿/*===============================================================================
Copyright (c) 2020 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/
#include "RefDriverImpl.h"
#include "Platform.h"
#include "RefDriverImplData.h"
#include "RefImplSequencePlayer.h"

#include <stdlib.h>

/*-------------------------------------------------------------------------------------------------------------------*/
// C APIs to init and deinit the Vuforia driver Impl.
/*-------------------------------------------------------------------------------------------------------------------*/
namespace
{
RefDriverImpl* g_RefDriverImplInstance = nullptr;
}
extern "C"
{
VuforiaDriver::Driver*
vuforiaDriver_init(VuforiaDriver::PlatformData* platformData, void* userdata)
{
    if (g_RefDriverImplInstance == nullptr)
    {
        g_RefDriverImplInstance = new RefDriverImpl(platformData, userdata);
        return g_RefDriverImplInstance;
    }
    // Attempting to init multiple instances is considered an error
    return nullptr;
}
void
vuforiaDriver_deinit(VuforiaDriver::Driver* instance)
{
    if (instance == g_RefDriverImplInstance)
    {
        delete static_cast<RefDriverImpl*>(instance);
        g_RefDriverImplInstance = nullptr;
    }
}
uint32_t
vuforiaDriver_getAPIVersion()
{
    return VuforiaDriver::VUFORIA_DRIVER_API_VERSION;
}
uint32_t
vuforiaDriver_getLibraryVersion(char* outString, const uint32_t maxLength)
{
    std::string versionCode = "RefDriverImpl-v1";
    uint32_t numBytes = static_cast<uint32_t>(versionCode.size() > maxLength ? maxLength : versionCode.size());
    memcpy(outString, versionCode.c_str(), numBytes);
    return numBytes;
}
} // extern "C"

static uint32_t cameraFrameId{ 0 };
static uint32_t poseId{ 0 };

// Structure to store camera frame properties.
struct CameraFrameProperties
{
    uint32_t numberOfImages{ 0 };
    int32_t playbackCount{ 0 };
    float extrinsics[12]{};
    VuforiaDriver::CameraMode cameraMode;
    VuforiaDriver::CameraIntrinsics cameraIntrinsics;
};
CameraFrameProperties mCameraFrameProperties;

/*-------------------------------------------------------------------------------------------------------------------*/
/* Implement DriverCamera */
/*-------------------------------------------------------------------------------------------------------------------*/
DriverCamera::DriverCamera(VuforiaDriver::PlatformData* platformData, void* userData)
{
    mPlatformData = platformData;
    mUserData = userData;
    // Initialize camera frame parameters. In real world driver implementation, these would be queried from underlying platform/device.
    mCameraFrameProperties.cameraMode.fps = FPS;
    mCameraFrameProperties.cameraMode.format = VuforiaDriver::PixelFormat::NV21;
    mCameraFrameProperties.cameraMode.width = 640;
    mCameraFrameProperties.cameraMode.height = 480;
    mCameraFrameProperties.cameraIntrinsics.principalPointX = 319.880646f;
    mCameraFrameProperties.cameraIntrinsics.principalPointY = 239.459396f;
    mCameraFrameProperties.cameraIntrinsics.focalLengthX = 506.724396f;
    mCameraFrameProperties.cameraIntrinsics.focalLengthY = 504.880859f;
    memcpy(mCameraFrameProperties.cameraIntrinsics.distortionCoefficients, DISTORTION_COEFF, sizeof(DISTORTION_COEFF));
    Platform::log("DriverCamera::DriverCamera");
}

DriverCamera::~DriverCamera()
{
    Platform::log("DriverCamera::~DriverCamera");
}

bool
DriverCamera::open()
{
    Platform::log("DriverCamera::open");
    return RefImplSequencePlayer::getInstance().open(this);
}

bool
DriverCamera::close()
{
    Platform::log("DriverCamera::close");
    return RefImplSequencePlayer::getInstance().close();
}
bool
DriverCamera::start(VuforiaDriver::CameraMode /* cameraMode */, VuforiaDriver::CameraCallback* cb)
{
    // Assign the callback that will be used to deliver the frames to Vuforia.
    mEngineCameraCallback = cb;
    Platform::log("DriverCamera::start");
    return RefImplSequencePlayer::getInstance().start();
}

bool
DriverCamera::stop()
{
    Platform::log("DriverCamera::stop");
    return RefImplSequencePlayer::getInstance().stop();
}

uint32_t
DriverCamera::getNumSupportedCameraModes()
{
    return 1;
}

bool
DriverCamera::getSupportedCameraMode(uint32_t /*index*/, VuforiaDriver::CameraMode* out)
{
    out->width = mCameraFrameProperties.cameraMode.width;
    out->height = mCameraFrameProperties.cameraMode.height;
    out->fps = mCameraFrameProperties.cameraMode.fps;
    out->format = mCameraFrameProperties.cameraMode.format;
    return true;
}

bool
DriverCamera::supportsExposureMode(VuforiaDriver::ExposureMode /* parameter */)
{
    return false;
}

VuforiaDriver::ExposureMode
DriverCamera::getExposureMode()
{
    return VuforiaDriver::ExposureMode::UNKNOWN;
}

bool
DriverCamera::setExposureMode(VuforiaDriver::ExposureMode /* mode */)
{
    return false;
}

bool
DriverCamera::supportsExposureValue()
{
    return false;
}

uint64_t
DriverCamera::getExposureValueMin()
{
    return 0;
}

uint64_t
DriverCamera::getExposureValueMax()
{
    return 0;
}

uint64_t
DriverCamera::getExposureValue()
{
    return 0;
}

bool
DriverCamera::setExposureValue(uint64_t /* exposureTime */)
{
    return false;
}

bool
DriverCamera::supportsFocusMode(VuforiaDriver::FocusMode /* parameter */)
{
    return false;
}

VuforiaDriver::FocusMode
DriverCamera::getFocusMode()
{
    return VuforiaDriver::FocusMode::UNKNOWN;
}

bool
DriverCamera::setFocusMode(VuforiaDriver::FocusMode /* mode */)
{
    return false;
}

bool
DriverCamera::supportsFocusValue()
{
    return false;
}

float
DriverCamera::getFocusValueMin()
{
    return 0.0f;
}

float
DriverCamera::getFocusValueMax()
{
    return 0.0f;
}

float
DriverCamera::getFocusValue()
{
    return 0.0f;
}

bool
DriverCamera::setFocusValue(float /* value */)
{
    return false;
}

void
DriverCamera::invokeEngineCameraCallback(VuforiaDriver::CameraFrame* inFrame)
{
    if (mEngineCameraCallback)
    {
        inFrame->timestamp = cameraFrameId * FRAME_DELTA;
        mEngineCameraCallback->onNewCameraFrame(inFrame);
    }
}
bool
DriverCamera::getCameraFrame(VuforiaDriver::CameraFrame& cameraFrame, std::vector<uint8_t>& frameBytes)
{
    uint32_t frameStride = 0;
    cameraFrameId++;

    if (frameBytes.size() != IMAGE_LENGTH)
    {
        frameBytes.resize(IMAGE_LENGTH);
    }
    memcpy(frameBytes.data(), IMAGE, IMAGE_LENGTH);
    cameraFrame.timestamp = cameraFrameId * FRAME_DELTA;
    cameraFrame.buffer = frameBytes.data();
    cameraFrame.bufferSize = static_cast<uint32_t>(frameBytes.size());
    cameraFrame.format = mCameraFrameProperties.cameraMode.format;
    cameraFrame.height = mCameraFrameProperties.cameraMode.height;
    cameraFrame.width = mCameraFrameProperties.cameraMode.width;
    cameraFrame.index = cameraFrameId;
    cameraFrame.intrinsics = mCameraFrameProperties.cameraIntrinsics;
    cameraFrame.stride = frameStride;
    // control the feed rate.
    if (mCameraFrameProperties.cameraMode.fps)
    {
        std::this_thread::sleep_for(std::chrono::milliseconds(1000 / mCameraFrameProperties.cameraMode.fps));
    }
    return true;
}

/*-------------------------------------------------------------------------------------------------------------------*/
/* Implement DriverPositionalDeviceTracker */
/*-------------------------------------------------------------------------------------------------------------------*/
DriverPositionalDeviceTracker::DriverPositionalDeviceTracker(VuforiaDriver::PlatformData* platformData, void* userData)
{
    mPlatformData = platformData;
    mUserData = userData;
    Platform::log("DriverPositionalDeviceTracker::DriverPositionalDeviceTracker");
}

DriverPositionalDeviceTracker::~DriverPositionalDeviceTracker() { }

bool
DriverPositionalDeviceTracker::open()
{
    Platform::log("DriverPositionalDeviceTracker::open");
    return RefImplSequencePlayer::getInstance().open(this);
}

bool
DriverPositionalDeviceTracker::close()
{
    Platform::log("DriverPositionalDeviceTracker::close");
    return RefImplSequencePlayer::getInstance().close();
}

bool
DriverPositionalDeviceTracker::start(VuforiaDriver::PoseCallback* cb, VuforiaDriver::AnchorCallback*)
{
    // Assign the callback that will be used to deliver poses to Vuforia.
    mEnginePoseCallback = cb;
    Platform::log("DriverPositionalDeviceTracker::start");
    return RefImplSequencePlayer::getInstance().start();
}

bool
DriverPositionalDeviceTracker::stop()
{
    Platform::log("DriverPositionalDeviceTracker::stop");
    return RefImplSequencePlayer::getInstance().stop();
}
bool
DriverPositionalDeviceTracker::resetTracking()
{
    return false;
}

void
DriverPositionalDeviceTracker::invokeEnginePoseCallback(VuforiaDriver::Pose* pose)
{
    if (mEnginePoseCallback)
    {
        pose->timestamp = poseId * FRAME_DELTA;
        mEnginePoseCallback->onNewPose(pose);
    }
}
bool
DriverPositionalDeviceTracker::getPose(VuforiaDriver::Pose& pose)
{
    poseId++;
    memcpy(pose.translationData, POSE_TRANSLATION, sizeof(POSE_TRANSLATION));
    memcpy(pose.rotationData, POSE_ROTATION, sizeof(POSE_ROTATION));
    pose.timestamp = poseId * FRAME_DELTA;
    pose.coordinateSystem = VuforiaDriver::PoseCoordSystem::CAMERA;
    pose.reason = VuforiaDriver::PoseReason::VALID;
    pose.validity = VuforiaDriver::PoseValidity::VALID;
    return true;
}

/*-------------------------------------------------------------------------------------------------------------------*/
/* Implement RefDriverImpl */
/*-------------------------------------------------------------------------------------------------------------------*/
RefDriverImpl::RefDriverImpl(VuforiaDriver::PlatformData* platformData, void* userdata) :
    mPlatformData(platformData),
    mUserdata(userdata),
    mExternalCamera(nullptr),
    mExternalPDT(nullptr)
{
    Platform::log("RefDriverImpl::RefDriverImpl");
}

RefDriverImpl::~RefDriverImpl() { }

VuforiaDriver::ExternalCamera* VUFORIA_DRIVER_CALLING_CONVENTION
RefDriverImpl::createExternalCamera()
{
    if (mExternalCamera == nullptr)
    {
        mExternalCamera = new DriverCamera(mPlatformData, mUserdata);
        Platform::log("createExternalCamera");
        return mExternalCamera;
    }

    // Creating multiple cameras considered an error
    return nullptr;
}

void VUFORIA_DRIVER_CALLING_CONVENTION
RefDriverImpl::destroyExternalCamera(VuforiaDriver::ExternalCamera* instance)
{
    if (instance == mExternalCamera)
    {
        delete static_cast<DriverCamera*>(instance);
        mExternalCamera = nullptr;
        Platform::log("destroyExternalCamera");
    }
}
VuforiaDriver::ExternalPositionalDeviceTracker* VUFORIA_DRIVER_CALLING_CONVENTION
RefDriverImpl::createExternalPositionalDeviceTracker()
{
    if (mExternalPDT == nullptr)
    {
        mExternalPDT = new DriverPositionalDeviceTracker(mPlatformData, mUserdata);
        Platform::log("createExternalPositionalDeviceTracker");
        return mExternalPDT;
    }
    // Creating multiple external positional device trackers is considered as an error.
    return nullptr;
}
void VUFORIA_DRIVER_CALLING_CONVENTION
RefDriverImpl::destroyExternalPositionalDeviceTracker(VuforiaDriver::ExternalPositionalDeviceTracker* instance)
{
    if (instance == mExternalPDT)
    {
        delete static_cast<DriverPositionalDeviceTracker*>(instance);
        mExternalPDT = nullptr;
        Platform::log("destroyExternalPositionalDeviceTracker");
    }
}

uint32_t VUFORIA_DRIVER_CALLING_CONVENTION
RefDriverImpl::getCapabilities()
{
    Platform::log("RefDriverImpl::getCapabilities");
    return (uint32_t)(VuforiaDriver::Capability::CAMERA_IMAGE | VuforiaDriver::Capability::CAMERA_POSE);
}
