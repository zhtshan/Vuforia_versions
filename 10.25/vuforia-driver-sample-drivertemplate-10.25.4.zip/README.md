# Driver Template
Implements a simple Vuforia Driver to feed camera frame and pose into Vuforia Engine.

# Building
Output binaries are placed in build/bin by default.

## Prerequisites

* A working development environment for your chosen platform. Depending on your preferred platform you will need:

|Platform|Tools|
|-|-|
|Android|Android NDK version r26+|
|iOS|XCode 15.0.1 or later|
|UWP|Visual Studio 2022 (17.8+) with the Universal Windows Platform workload and C++/WinRT Extension installed|

* Python 3.10+
* CMake 3.9+

## Android
```
python build.py android
```
## UWP
```
python build.py uwp
```
Note that this step will also generate an MS Visual Studio solution file in
the build/uwp/[architecture] directory ([architecture]: 'x64' or 'ARM64').
## IOS
```
python build.py ios
```
Note that this step will also generate an Xcode project file in the
build/ios/arm64 directory.
## Set directory with Vuforia header
If you put this sample into the "samples" directory of your Vuforia SDK (such
that the directory is a sub-directory, that is: samples/DriverTemplate), the
Vuforia headers will be found automatically. If your SDK is located elsewhere
then you need to specify where. There are two ways to do this. For iOS, use the
-vf flag, and pass it the path to the directory that contains
Vuforia.framework. For other target platforms, use the -vh flag and pass it the
path to the SDK's "include" directory.

Ex: 
```
python build.py ios -vf '[vuforia-sdk-directory]/build'
python build.py android -vh '[vuforia-sdk-directory]/build/include'
```

# Usage
## Android
1. Add libRefDriverImpl.so from build/bin into your Android-app project.

    libRefDriverImpl.so can be added to an app by two ways depending on your build system: Using Android.mk or using Gradle. Please note that you need to substitute '[path-in-your-filesystem]' with the correct path.

    **Using Android.mk (e.g. ImageTargetsNative sample app)**

    Add libRefDriver-prebuilt definition to your Android.mk:
    ```
    include $(CLEAR_VARS)
    LOCAL_MODULE := libRefDriver-prebuilt
    LOCAL_SRC_FILES = [path-in-your-filesystem]/DriverTemplate/build/bin/Android/$(TARGET_ARCH_ABI)/libRefDriverImpl.so
    include $(PREBUILT_SHARED_LIBRARY)
    ```
    When defining your local module in the same Android.mk add libRefDriver-prebuilt as a dependency to your LOCAL_SHARED_LIBRARIES:
    ```
    LOCAL_SHARED_LIBRARIES := Vuforia-prebuilt libRefDriver-prebuilt
    ```

    **Using Gradle (e.g. VuforiaSamples sample app)**

    This can be done in your app/build.gradle with the following:
    ```
    android {
        sourceSets.main {
            jniLibs.srcDirs += '[path-in-your-filesystem]/DriverTemplate/build/bin/Android/'
        }
    }
    ```

2. Add following call to your source code before calling Vuforia::init();

    **Java**:
    ```
    Vuforia.setDriverLibrary("libRefDriverImpl.so");
    ```

    **C++**:
    ```
    Vuforia::setDriverLibrary("libRefDriverImpl.so", nullptr);
    ```

## UWP
1. Add DriverTemplate.dll from build/bin/uwp into your Visual Studio UWP-app project.
    - Import the DriverTemplate.dll to the root of your project. Remember to use a dll that matches your architecture (x64/ARM64) and build type (Debug/Release) configurations.
    - Click DriverTemplate.dll from the project file list and set property "Content" to True.

2. Add following call before calling Vuforia::init();
    ```
    Vuforia::setDriverLibrary("DriverTemplate.dll", nullptr);
    ```

# Copyright

```
Copyright (c) 2024 PTC Inc. and/or Its Subsidiary Companies.
All Rights Reserved.

Copyright for PTC software products is with PTC Inc. and its subsidiary
companies (collectively "PTC"), and their respective licensors. This software
is provided under written license or other agreement, contains valuable trade
secrets and proprietary information, and is protected by the copyright laws of
the United States and other countries. It may not be copied or distributed in
any form or medium, disclosed to third parties, or used in any manner not
provided for in the applicable agreement except with written prior approval
from PTC. More information regarding third party copyrights and trademarks and
a list of PTC's registered copyrights, trademarks, and patents can be viewed
here: www.ptc.com/support/go/copyright-and-trademarks 
```
