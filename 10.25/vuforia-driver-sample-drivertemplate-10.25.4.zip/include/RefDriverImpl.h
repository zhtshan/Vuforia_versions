﻿/*===============================================================================
Copyright (c) 2020 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/
#ifndef _REF_DRIVER_IMPL_H_
#define _REF_DRIVER_IMPL_H_

#include <VuforiaEngine/Driver/Driver.h>
#include <string>
#include <vector>

/*-------------------------------------------------------------------------------------------------------------------*/
// Implement DriverCamera by deriving from VuforiaDriver::ExternalCamera to feed camera frames into Vuforia Engine.
/*-------------------------------------------------------------------------------------------------------------------*/
class DriverCamera final : public VuforiaDriver::ExternalCamera
{
public:
    DriverCamera(VuforiaDriver::PlatformData* platformData, void* userData);
    virtual ~DriverCamera();

    // Override VuforiaDriver::ExternalCamera members.
    bool VUFORIA_DRIVER_CALLING_CONVENTION open() override;
    bool VUFORIA_DRIVER_CALLING_CONVENTION close() override;
    bool VUFORIA_DRIVER_CALLING_CONVENTION start(VuforiaDriver::CameraMode /* cameraMode */, VuforiaDriver::CameraCallback* cb) override;
    bool VUFORIA_DRIVER_CALLING_CONVENTION stop() override;
    uint32_t VUFORIA_DRIVER_CALLING_CONVENTION getNumSupportedCameraModes() override;
    bool VUFORIA_DRIVER_CALLING_CONVENTION getSupportedCameraMode(uint32_t index, VuforiaDriver::CameraMode* out) override;
    bool VUFORIA_DRIVER_CALLING_CONVENTION supportsExposureMode(VuforiaDriver::ExposureMode /* parameter */) override;
    VuforiaDriver::ExposureMode VUFORIA_DRIVER_CALLING_CONVENTION getExposureMode() override;
    bool VUFORIA_DRIVER_CALLING_CONVENTION setExposureMode(VuforiaDriver::ExposureMode /* mode */) override;
    bool VUFORIA_DRIVER_CALLING_CONVENTION supportsExposureValue() override;
    uint64_t VUFORIA_DRIVER_CALLING_CONVENTION getExposureValueMin() override;
    uint64_t VUFORIA_DRIVER_CALLING_CONVENTION getExposureValueMax() override;
    uint64_t VUFORIA_DRIVER_CALLING_CONVENTION getExposureValue() override;
    bool VUFORIA_DRIVER_CALLING_CONVENTION setExposureValue(uint64_t /* exposureTime */) override;
    bool VUFORIA_DRIVER_CALLING_CONVENTION supportsFocusMode(VuforiaDriver::FocusMode /* parameter */) override;
    VuforiaDriver::FocusMode VUFORIA_DRIVER_CALLING_CONVENTION getFocusMode() override;
    bool VUFORIA_DRIVER_CALLING_CONVENTION setFocusMode(VuforiaDriver::FocusMode /* mode */) override;
    bool VUFORIA_DRIVER_CALLING_CONVENTION supportsFocusValue() override;
    float VUFORIA_DRIVER_CALLING_CONVENTION getFocusValueMin() override;
    float VUFORIA_DRIVER_CALLING_CONVENTION getFocusValueMax() override;
    float VUFORIA_DRIVER_CALLING_CONVENTION getFocusValue() override;
    bool VUFORIA_DRIVER_CALLING_CONVENTION setFocusValue(float /* value */) override;
    // Invokes engine callback to feed camera frames.
    void invokeEngineCameraCallback(VuforiaDriver::CameraFrame* inFrame);
    // Returns the next camera frame.
    bool getCameraFrame(VuforiaDriver::CameraFrame&, std::vector<uint8_t>&);

private:
    VuforiaDriver::CameraCallback* mEngineCameraCallback{ nullptr };
    VuforiaDriver::PlatformData* mPlatformData{ nullptr };
    void* mUserData{ nullptr };
};

/*---------------------------------------------------------------------------------------------------------------------------------------------*/
// Implement DriverPositionalDeviceTracker by deriving from VuforiaDriver::ExternalPositionalDeviceTracker to feed poses into Vuforia
// Engine.
/*---------------------------------------------------------------------------------------------------------------------------------------------*/
class DriverPositionalDeviceTracker final : public VuforiaDriver::ExternalPositionalDeviceTracker
{
public:
    DriverPositionalDeviceTracker(VuforiaDriver::PlatformData* platformData, void* userData);
    virtual ~DriverPositionalDeviceTracker();

    // Override VuforiaDriver::ExternalPositionalDeviceTracker members.
    bool VUFORIA_DRIVER_CALLING_CONVENTION open() override;
    bool VUFORIA_DRIVER_CALLING_CONVENTION close() override;
    bool VUFORIA_DRIVER_CALLING_CONVENTION start(VuforiaDriver::PoseCallback* cb, VuforiaDriver::AnchorCallback* acb = nullptr) override;
    bool VUFORIA_DRIVER_CALLING_CONVENTION stop() override;
    bool VUFORIA_DRIVER_CALLING_CONVENTION resetTracking() override;
    // Invokes engine callback to feed poses.
    void invokeEnginePoseCallback(VuforiaDriver::Pose* pose);
    // Returns the next pose.
    bool getPose(VuforiaDriver::Pose&);

private:
    VuforiaDriver::PoseCallback* mEnginePoseCallback{ nullptr };
    VuforiaDriver::PlatformData* mPlatformData{ nullptr };
    void* mUserData{ nullptr };
};

/*-------------------------------------------------------------------------------------------------------------------*/
// RefDriverImpl implements the VuforiaDriver base class.
// This class is used for constructing and destroying the ExternalCamera and ExternalPositionalDeviceTracker source objects.
// The documentation of the public methods can be found in VuforiaEngine/Driver/Driver.h header.
/*-------------------------------------------------------------------------------------------------------------------*/
class RefDriverImpl final : public VuforiaDriver::Driver
{
public:
    RefDriverImpl(VuforiaDriver::PlatformData* platformData, void* userdata);
    virtual ~RefDriverImpl();

    // Override VuforiaDriver::Driver members.
    VuforiaDriver::ExternalCamera* VUFORIA_DRIVER_CALLING_CONVENTION createExternalCamera() override;
    void VUFORIA_DRIVER_CALLING_CONVENTION destroyExternalCamera(VuforiaDriver::ExternalCamera* instance) override;
    VuforiaDriver::ExternalPositionalDeviceTracker* VUFORIA_DRIVER_CALLING_CONVENTION createExternalPositionalDeviceTracker() override;
    void VUFORIA_DRIVER_CALLING_CONVENTION
    destroyExternalPositionalDeviceTracker(VuforiaDriver::ExternalPositionalDeviceTracker* instance) override;
    uint32_t VUFORIA_DRIVER_CALLING_CONVENTION getCapabilities() override;

private:
    VuforiaDriver::PlatformData* mPlatformData{ nullptr };
    void* mUserdata{ nullptr };
    DriverCamera* mExternalCamera{ nullptr };
    DriverPositionalDeviceTracker* mExternalPDT{ nullptr };
};

#endif // _REF_DRIVER_IMPL_H_
