/*===============================================================================
Copyright (c) 2021 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

#include "MP4SampleDeserializer.h"
#include "Platform/Platform.h"

using namespace Platform;

// This is a separate enum from VuforiaDriver::PoseReason/PoseValidity
// to ensure the values are always the same in the binary format.
// Do not change the values of existing enum entries here!
enum class Mp4SamplePoseReason : uint8_t
{
    INVALID = 0x00,
    VALID = 0x01,
    INITIALIZING = 0x02,
    EXCESSIVE_MOTION = 0x03,
    INSUFFICIENT_FEATURES = 0x04,
    INSUFFICIENT_LIGHT = 0x05,
    RELOCALIZING = 0x06,
    CAMERA_UNAVAILABLE = 0x07,
    UNKNOWN = 0xFF,
};


enum class Mp4SamplePoseValidity : uint8_t
{
    INVALID = 0x00,
    VALID = 0x01,
    UNRELIABLE = 0x02,
    UNKNOWN = 0xFF,
};


enum class Mp4SampleCoordinateSystem : uint8_t
{
    CAMERA = 0x01,
    WORLD = 0x02,
    DEVICE = 0x03,
    UNKNOWN = 0xFF,
};

namespace
{

float
readFloat(const uint8_t* buffer)
{
    // Floats are serialized as IEEE 754 in big-endian order
    static_assert(std::numeric_limits<float>::is_iec559);
    static_assert(sizeof(uint32_t) == sizeof(float));

    uint32_t intValue = buffer[0] << 24 | buffer[1] << 16 | buffer[2] << 8 | buffer[3];
    float floatValue = 0.0f;
    memcpy(&floatValue, &intValue, sizeof(uint32_t));
    return floatValue;
}


template <int EXPECTED_SIZE, int SIZE>
void
readFloatArray(const uint8_t* buffer, float (&value)[SIZE])
{
    static_assert(EXPECTED_SIZE == SIZE);
    for (int i = 0; i < SIZE; ++i)
    {
        value[i] = readFloat(buffer + (i * sizeof(float)));
    }
}


int64_t
readInt64(const uint8_t* buffer)
{
    return static_cast<int64_t>(buffer[0]) << 56 | static_cast<int64_t>(buffer[1]) << 48 | static_cast<int64_t>(buffer[2]) << 40 |
        static_cast<int64_t>(buffer[3]) << 32 | static_cast<int64_t>(buffer[4]) << 24 | static_cast<int64_t>(buffer[5]) << 16 |
        static_cast<int64_t>(buffer[6]) << 8 | static_cast<int64_t>(buffer[7]);
}


VuforiaDriver::CameraIntrinsics
readIntrinsicsInternal(const uint8_t* buffer)
{
    VuforiaDriver::CameraIntrinsics intrinsics;

    // Skip first 8 bytes: width, height
    intrinsics.focalLengthX = readFloat(&buffer[8]);
    intrinsics.focalLengthY = readFloat(&buffer[12]);
    intrinsics.principalPointX = readFloat(&buffer[16]);
    intrinsics.principalPointY = readFloat(&buffer[20]);

    for (int i = 0; i < 8; ++i)
    {
        intrinsics.distortionCoefficients[i] = readFloat(&buffer[24 + (i * 4)]);
    }

    return intrinsics;
}

}


std::optional<VuforiaDriver::CameraIntrinsics>
MP4SampleDeserializer::readIntrinsics(const std::vector<uint8_t>& buffer)
{
    if (buffer.size() != 56)
    {
        return {};
    }

    return readIntrinsicsInternal(buffer.data());
}


std::optional<FrameMetadata>
MP4SampleDeserializer::readFrameMetadata(const std::vector<uint8_t>& buffer)
{
    if (buffer.size() != 120)
    {
        return {};
    }

    FrameMetadata data;
    data.mTimestamp = readInt64(&buffer[0]);
    data.mPresentationTimestamp = readInt64(&buffer[8]);
    data.mPublishTimestamp = readInt64(&buffer[16]);
    data.mExposureTime = readInt64(&buffer[24]);
    data.mIsoValue = readFloat(&buffer[32]);
    data.mIntrinsics = readIntrinsicsInternal(&buffer[36]);
    return data;
}

std::optional<VuforiaDriver::Pose>
MP4SampleDeserializer::readDevicePose(const std::vector<uint8_t>& buffer, int version)
{
    if ((version == 1 && buffer.size() != 74) || (version == 2 && buffer.size() != 91))
    {
        return {};
    }

    if (version == 2)
    {
        if (static_cast<Mp4SampleCoordinateSystem>(buffer[90]) != Mp4SampleCoordinateSystem::CAMERA)
        {
            return {};
        }
    }

    VuforiaDriver::Pose pose;
    pose.coordinateSystem = VuforiaDriver::PoseCoordSystem::CAMERA;
    pose.timestamp = static_cast<uint64_t>(readInt64(&buffer[0]));
    readFloatArray<3>(&buffer[24], pose.translationData);
    readFloatArray<9>(&buffer[36], pose.rotationData);

    if (buffer[72] == static_cast<uint8_t>(Mp4SamplePoseValidity::VALID))
    {
        pose.validity = VuforiaDriver::PoseValidity::VALID;
    }
    else
    {
        pose.validity = VuforiaDriver::PoseValidity::UNRELIABLE;
    }

    // Explicit mapping instead of cast to prevent it from breaking should the
    // VuforiaDriver::PoseReason enum change.
    switch (buffer[73])
    {
        case static_cast<uint8_t>(Mp4SamplePoseReason::VALID):
            pose.reason = VuforiaDriver::PoseReason::VALID;
            break;
        case static_cast<uint8_t>(Mp4SamplePoseReason::INITIALIZING):
            pose.reason = VuforiaDriver::PoseReason::INITIALIZING;
            break;
        case static_cast<uint8_t>(Mp4SamplePoseReason::EXCESSIVE_MOTION):
            pose.reason = VuforiaDriver::PoseReason::EXCESSIVE_MOTION;
            break;
        case static_cast<uint8_t>(Mp4SamplePoseReason::INSUFFICIENT_FEATURES):
            pose.reason = VuforiaDriver::PoseReason::INSUFFICIENT_FEATURES;
            break;
        case static_cast<uint8_t>(Mp4SamplePoseReason::INSUFFICIENT_LIGHT):
            pose.reason = VuforiaDriver::PoseReason::INSUFFICIENT_LIGHT;
            break;
        case static_cast<uint8_t>(Mp4SamplePoseReason::RELOCALIZING):
            pose.reason = VuforiaDriver::PoseReason::RELOCALIZING;
            break;
        case static_cast<uint8_t>(Mp4SamplePoseReason::INVALID):
        case static_cast<uint8_t>(Mp4SamplePoseReason::CAMERA_UNAVAILABLE):
        case static_cast<uint8_t>(Mp4SamplePoseReason::UNKNOWN):
        default:
            pose.reason = VuforiaDriver::PoseReason::INITIALIZING;
            break;
    }

    return pose;
}
