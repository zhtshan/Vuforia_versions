/*===============================================================================
Copyright (c) 2021 PTC Inc. All Rights Reserved.

Confidential and Proprietary - Protected under copyright and other laws.
Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

#include "FileCamera.h"
#include "Platform/Platform.h"
#include "Player.h"
#include <algorithm>
#include <sstream>


FileCamera::FileCamera(Player* player) : mPlayer(player)
{
    Platform::log("FileCamera::FileCamera");
}

bool
FileCamera::open()
{
    Platform::log("FileCamera::open");
    if (mPlayer == nullptr)
    {
        Platform::log("Failed to open camera, player not initialized");
        return false;
    }
    return mPlayer->open([this](VuforiaDriver::CameraFrame* frame) { framesPlayerCallback(frame); });
}

bool
FileCamera::close()
{
    Platform::log("FileCamera::close");
    if (mPlayer == nullptr)
    {
        Platform::log("Failed to close camera, player not initialized");
        return false;
    }
    mPlayer->close();
    return true;
}

bool
FileCamera::start(VuforiaDriver::CameraMode /* cameraMode */, VuforiaDriver::CameraCallback* cb)
{
    Platform::log("FileCamera::start");
    if (mPlayer == nullptr)
    {
        Platform::log("Failed to start camera, player not initialized");
        return false;
    }

    // Assign the callback that will be used to deliver the frames to Vuforia.
    mCallback = cb;

    return mPlayer->start();
}

bool
FileCamera::stop()
{
    Platform::log("FileCamera::stop");
    if (mPlayer == nullptr)
    {
        Platform::log("Failed to stop camera, player not initialized");
        return false;
    }
    return mPlayer->stop();
}

uint32_t
FileCamera::getNumSupportedCameraModes()
{
    Platform::log("FileCamera::getNumSupportedCameraModes");
    return 1;
}

bool
FileCamera::getSupportedCameraMode(uint32_t /* index */, VuforiaDriver::CameraMode* out)
{
    Platform::log("FileCamera::getSupportedCameraMode");

    if (mPlayer == nullptr)
    {
        Platform::log("Failed to get camera mode, player not initialized");
        return false;
    }

    auto& properties = mPlayer->getRecordingProperties();
    out->width = properties.cameraMode.width;
    out->height = properties.cameraMode.height;
    out->fps = properties.cameraMode.fps;
    out->format = properties.cameraMode.format;
    return true;
}

bool
FileCamera::supportsExposureMode(VuforiaDriver::ExposureMode /* parameter */)
{
    Platform::log("FileCamera::supportsExposureMode");
    return false;
}

VuforiaDriver::ExposureMode
FileCamera::getExposureMode()
{
    Platform::log("FileCamera::getExposureMode");
    return VuforiaDriver::ExposureMode::UNKNOWN;
}

bool
FileCamera::setExposureMode(VuforiaDriver::ExposureMode /* mode */)
{
    Platform::log("FileCamera::setExposureMode");
    return false;
}

bool
FileCamera::supportsExposureValue()
{
    Platform::log("FileCamera::supportsExposureValue");
    return false;
}

uint64_t
FileCamera::getExposureValueMin()
{
    Platform::log("FileCamera::getExposureValueMin");
    return 0;
}

uint64_t
FileCamera::getExposureValueMax()
{
    Platform::log("FileCamera::getExposureValueMax");
    return 0;
}

uint64_t
FileCamera::getExposureValue()
{
    Platform::log("FileCamera::getExposureValue");
    return 0;
}

bool
FileCamera::setExposureValue(uint64_t /* exposureTime */)
{
    Platform::log("FileCamera::setExposureValue");
    return false;
}

bool
FileCamera::supportsFocusMode(VuforiaDriver::FocusMode /* parameter */)
{
    Platform::log("FileCamera::supportsFocusMode");
    return false;
}

VuforiaDriver::FocusMode
FileCamera::getFocusMode()
{
    Platform::log("FileCamera::getFocusMode");
    return VuforiaDriver::FocusMode::UNKNOWN;
}

bool
FileCamera::setFocusMode(VuforiaDriver::FocusMode /* mode */)
{
    Platform::log("FileCamera::setFocusMode");
    return false;
}

bool
FileCamera::supportsFocusValue()
{
    Platform::log("FileCamera::supportsFocusValue");
    return false;
}

float
FileCamera::getFocusValueMin()
{
    Platform::log("FileCamera::getFocusValueMin");
    return 0.0f;
}

float
FileCamera::getFocusValueMax()
{
    Platform::log("FileCamera::getFocusValueMax");
    return 0.0f;
}

float
FileCamera::getFocusValue()
{
    Platform::log("FileCamera::getFocusValue");
    return 0.0f;
}

bool
FileCamera::setFocusValue(float /* value */)
{
    Platform::log("FileCamera::setFocusValue");
    return false;
}

bool
FileCamera::processFramesOnThread()
{
    // If playback mode is RESPECT, tell engine to process camera frames
    // on a separate thread. Frames will be dropped if engine cannot keep up with processing them.
    return mPlayer == nullptr ? false : (mPlayer->getRecordingProperties().playbackMode == FILEDRIVER_PLAYBACK_MODE_RESPECT);
}

void
FileCamera::framesPlayerCallback(VuforiaDriver::CameraFrame* inFrame)
{
    if (mCallback)
    {
        mCallback->onNewCameraFrame(inFrame);
    }
    else
    {
        Platform::log("Camera frame callback to Vuforia not found.");
    }
}
