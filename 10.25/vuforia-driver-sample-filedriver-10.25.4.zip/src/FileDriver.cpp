/*===============================================================================
Copyright (c) 2021 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/
#include "FileDriver.h"
#include "FileDriverPlaybackController.h"
#include "FileDriverUserData.h"
#include "MP4Player.h"
#include "Platform/Platform.h"

#include <string>

namespace
{

constexpr uint64_t NANOSECONDS_PER_MILLISECOND = 1000000;

FileDriver* g_fileDriverInstance = nullptr;

}

//=============================================================================
// VUFORIA EXTERNAL PROVIDER-API IMPLEMENTATION
//=============================================================================
extern "C"
{
VuforiaDriver::Driver*
vuforiaDriver_init(VuforiaDriver::PlatformData* platformData, void* userdata)
{
    if (g_fileDriverInstance == nullptr)
    {
        auto* fdUserData = static_cast<FileDriverUserData*>(userdata);
        g_fileDriverInstance = new FileDriver(platformData, fdUserData);
        return g_fileDriverInstance;
    }

    // Attempting to init multiple instances is considered an error
    return nullptr;
}

void
vuforiaDriver_deinit(VuforiaDriver::Driver* instance)
{
    if (instance == g_fileDriverInstance)
    {
        delete static_cast<FileDriver*>(instance);
        g_fileDriverInstance = nullptr;
    }
}

uint32_t
vuforiaDriver_getAPIVersion()
{
    return VuforiaDriver::VUFORIA_DRIVER_API_VERSION;
}

uint32_t
vuforiaDriver_getLibraryVersion(char* outString, const uint32_t maxLength)
{
    // FileDriver-v4.x -> FileDriver version number
    // (mp4-v1, mp4-v2) -> The supported MP4 recording versions
    std::string versionCode = "FileDriver-v4.0 (mp4-v1, mp4-v2)";
    uint32_t numBytes = static_cast<uint32_t>(versionCode.size() > maxLength ? maxLength : versionCode.size());
    memcpy(outString, versionCode.c_str(), numBytes);
    return numBytes;
}
} // extern "C"


//=============================================================================
// FILE DRIVER API IMPLEMENTATION
//=============================================================================
extern "C"
{

bool
fileDriverSetPlaybackStartTime(uint64_t timestampMs)
{
    return g_fileDriverInstance == nullptr ? false : g_fileDriverInstance->setPlaybackStartTime(timestampMs);
}


bool
fileDriverSetPlaybackEndTime(uint64_t timestampMs)
{
    return g_fileDriverInstance == nullptr ? false : g_fileDriverInstance->setPlaybackEndTime(timestampMs);
}


bool
fileDriverSetPlaybackLoop(uint32_t loopCount)
{
    return g_fileDriverInstance == nullptr ? false : g_fileDriverInstance->setPlaybackLoop(loopCount);
}


bool
fileDriverSetPlaybackMode(FileDriverPlaybackMode mode)
{
    return g_fileDriverInstance == nullptr ? false : g_fileDriverInstance->setPlaybackMode(mode);
}

uint64_t
fileDriverGetSequenceDuration()
{
    return g_fileDriverInstance == nullptr ? 0 : g_fileDriverInstance->getSequenceDuration();
}


uint64_t
fileDriverGetPlaybackPosition()
{
    return g_fileDriverInstance == nullptr ? 0 : g_fileDriverInstance->getPlaybackPosition();
}

} // extern "C"


//=============================================================================
// PUBLIC INTERFACE IMPLEMENTATION (GENERAL)
//=============================================================================

FileDriver::FileDriver(VuforiaDriver::PlatformData* platformData, FileDriverUserData* userData)
{
    initializePlayer(platformData, userData);
}

FileDriver::~FileDriver() { }

VuforiaDriver::ExternalCamera*
FileDriver::createExternalCamera()
{
    if (mExternalCamera == nullptr)
    {
        mExternalCamera = std::make_unique<FileCamera>(mPlayer.get());
        return mExternalCamera.get();
    }

    // Creating multiple cameras considered an error
    return nullptr;
}

void
FileDriver::destroyExternalCamera(VuforiaDriver::ExternalCamera* instance)
{
    if (instance == mExternalCamera.get())
    {
        mExternalCamera.reset();
    }
}

VuforiaDriver::ExternalPositionalDeviceTracker*
FileDriver::createExternalPositionalDeviceTracker()
{
    if (mExternalPDT == nullptr)
    {
        mExternalPDT = std::make_unique<FilePositionalDeviceTracker>(mPlayer.get());
        return mExternalPDT.get();
    }

    // Creating multiple external positional device trackers is considered as an error.
    return nullptr;
}

void
FileDriver::destroyExternalPositionalDeviceTracker(VuforiaDriver::ExternalPositionalDeviceTracker* instance)
{
    if (instance == mExternalPDT.get())
    {
        mExternalPDT.reset();
    }
}

uint32_t
FileDriver::getCapabilities()
{
    if (mPlayer == nullptr)
    {
        return 0;
    }

    // By default, driver supports at least CAMERA_IMAGE capability.
    uint32_t capability = VuforiaDriver::Capability::CAMERA_IMAGE;

    if (mPlayer->getRecordingProperties().hasDevicePoses)
    {
        capability |= VuforiaDriver::Capability::CAMERA_POSE;
    }

    return (uint32_t)capability;
}

uint32_t
FileDriver::getCameraOrientation(uint32_t deviceOrientationInDegrees)
{
    // Default value to return if not supported:
    uint32_t cameraOrientationInDegrees{ VuforiaDriver::Driver::getCameraOrientation(deviceOrientationInDegrees) };

    if (mPlayer == nullptr)
    {
        return cameraOrientationInDegrees;
    }

    auto& properties = mPlayer->getRecordingProperties();
    if (properties.supportsCameraOrientation)
    {
        // Note: using <360 - value> for subtraction, as all variables are unsigned degree values.
        cameraOrientationInDegrees =
            (properties.recCamOrientInDegrees + (360 - properties.recDevOrientInDegrees) + deviceOrientationInDegrees) % 360;
    }
    else
    {
        Platform::log("FileDriver::getCameraOrientation : Could not compute the camera orientation - possibly the recording version"
                      " does not support it. Returning the default value " +
                      std::to_string(cameraOrientationInDegrees) + " degrees.");
    }

    return cameraOrientationInDegrees;
}


bool
FileDriver::setPlaybackStartTime(uint64_t timestamp)
{
    Platform::log("Setting playback start time to: " + std::to_string(timestamp));
    return mPlayer == nullptr ? false : mPlayer->setPlaybackStartTime(timestamp * NANOSECONDS_PER_MILLISECOND);
}


bool
FileDriver::setPlaybackEndTime(uint64_t timestamp)
{
    Platform::log("Setting playback end time to: " + std::to_string(timestamp));
    return mPlayer == nullptr ? false : mPlayer->setPlaybackEndTime(timestamp * NANOSECONDS_PER_MILLISECOND);
}


bool
FileDriver::setPlaybackLoop(uint32_t loopCount)
{
    if (mPlayer == nullptr)
    {
        return false;
    }

    Platform::log("Setting playback loop count to: " + std::to_string(loopCount));
    mPlayer->setPlaybackLoop(loopCount);
    return true;
}


bool
FileDriver::setPlaybackMode(FileDriverPlaybackMode mode)
{
    if (mPlayer == nullptr)
    {
        return false;
    }

    if (mode != FILEDRIVER_PLAYBACK_MODE_RESPECT && mode != FILEDRIVER_PLAYBACK_MODE_WAIT)
    {
        Platform::log("Invalid playback mode");
        return false;
    }

    Platform::log("Setting playback mode to " + std::string(mode == FILEDRIVER_PLAYBACK_MODE_RESPECT ? "RESPECT" : "WAIT"));
    mPlayer->setPlaybackMode(mode);
    return true;
}


uint64_t
FileDriver::getSequenceDuration()
{
    if (mPlayer == nullptr)
    {
        return 0;
    }

    auto& recordingProperties = mPlayer->getRecordingProperties();
    return (recordingProperties.lastCameraTimestamp - recordingProperties.firstCameraTimestamp) / NANOSECONDS_PER_MILLISECOND;
}


uint64_t
FileDriver::getPlaybackPosition()
{
    if (mPlayer == nullptr)
    {
        return 0;
    }

    return mPlayer->getPlaybackPosition() / NANOSECONDS_PER_MILLISECOND;
}


void
FileDriver::initializePlayer(VuforiaDriver::PlatformData* platformData, FileDriverUserData* userData)
{
    mPlayer = std::make_unique<MP4Player>();
    if (!mPlayer->init(platformData, userData))
    {
        Platform::log("Failed to initialize player. Playback will not start.");
        mPlayer.reset();
    }
}
