/*===============================================================================
Copyright (c) 2021 PTC Inc., Its Subsidiary Companies, and /or its Partners.
All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

#include "Platform/MP4Reader.h"
#include "Platform/Platform.h"
#include "Platform/VideoDecoder.h"

#include <cassert>
#include <chrono>
#include <mp4v2/mp4v2.h>

#ifdef __ANDROID__
#include <android/asset_manager.h>
#endif

using namespace Platform;

namespace
{

std::vector<MP4Reader::TrackInfo>
readTrackInfo(MP4FileHandle file, const char* typeFilter)
{
    uint16_t numTracks = static_cast<uint16_t>(MP4GetNumberOfTracks(file, typeFilter));

    std::vector<MP4Reader::TrackInfo> tracks;
    for (uint16_t i = 0; i < numTracks; ++i)
    {
        MP4Reader::TrackInfo& track = tracks.emplace_back();
        track.mId = MP4FindTrackId(file, i, typeFilter);
        track.mType = MP4GetTrackType(file, track.mId);
        track.mNumSamples = MP4GetTrackNumberOfSamples(file, track.mId);
        track.mMaxSampleSize = MP4GetTrackMaxSampleSize(file, track.mId);
        track.mDuration = MP4ConvertFromTrackDuration(file, track.mId, MP4GetTrackDuration(file, track.mId), MP4_USECS_TIME_SCALE);

        char* name = nullptr;
        if (MP4GetTrackName(file, track.mId, &name) && name != nullptr)
        {
            track.mName = name;
            MP4FreeTrackName(name);
        }

        if (track.mType == MP4_TRACK_TYPE_VIDEO)
        {
            track.mVideoHeight = MP4GetTrackVideoHeight(file, track.mId);
            track.mVideoWidth = MP4GetTrackVideoWidth(file, track.mId);
            track.mVideoBitrate = MP4GetTrackBitRate(file, track.mId);
        }
    }

    return tracks;
}


void
readMetadataTag(MP4FileHandle file, const std::string& key, MP4ItmfBasicType type, std::function<void(const MP4ItmfData&)> reader)
{
    MP4ItmfItemList* tagList = MP4ItmfGetItemsByMeaning(file, key.c_str(), key.c_str());

    if (tagList == nullptr || tagList->size == 0 || tagList->elements[0].dataList.size == 0)
    {
        MP4ItmfItemListFree(tagList);
        return;
    }

    auto& value = tagList->elements[0].dataList.elements[0];
    if (value.typeCode != type || value.valueSize == 0 || value.value == nullptr)
    {
        MP4ItmfItemListFree(tagList);
        return;
    }

    reader(value);

    MP4ItmfItemListFree(tagList);
}


std::optional<VideoCodec>
getTrackVideoCodec(MP4FileHandle file, MP4TrackId track)
{
    // Try H.264
    uint8_t profile = 0;
    uint8_t level = 0;
    if (MP4GetTrackH264ProfileLevel(file, track, &profile, &level) && profile != 0 && level != 0)
    {
        // Check AVCC header
        uint32_t headerSize = 0;
        if (MP4GetTrackH264LengthSize(file, track, &headerSize) && headerSize == 4)
        {
            return VideoCodec::H264_AVCC;
        }
    }

    // No other codec supported
    return {};
}


VideoCodecConfigurationData
buildCodecConfigData(MP4FileHandle file, MP4TrackId track)
{
    VideoCodecConfigurationData configData;

    auto codec = getTrackVideoCodec(file, track);
    assert(codec.has_value());

    if (*codec == VideoCodec::H264_AVCC)
    {
        uint32_t *spsSize = nullptr, *ppsSize = nullptr;
        uint8_t **sps = nullptr, **pps = nullptr;
        if (MP4GetTrackH264SeqPictHeaders(file, track, &sps, &spsSize, &pps, &ppsSize))
        {
            configData[VideoCodecConfigurationDataType::H264_SPS] = std::vector<uint8_t>{ *sps, *sps + *spsSize };
            configData[VideoCodecConfigurationDataType::H264_PPS] = std::vector<uint8_t>{ *pps, *pps + *ppsSize };
            MP4FreeH264SeqPictHeaders(sps, spsSize, pps, ppsSize);
        }
    }
    else
    {
        assert(false);
    }

    return configData;
}


}


std::unique_ptr<MP4Reader>
MP4Reader::open(const std::string& file, VuforiaDriver::PlatformData* platformData)
{
    auto normalizedPath = normalizePath(file);
    if (!normalizedPath.has_value())
    {
        log("Failed to resolve path: " + file);
        return nullptr;
    }

    auto fileHandle = MP4Read(normalizedPath->c_str());
    if (fileHandle == nullptr)
    {
        log("Could not open file: " + file);
        return nullptr;
    }

    return std::unique_ptr<MP4Reader>(new MP4Reader(fileHandle, platformData));
}


std::unique_ptr<MP4Reader>
MP4Reader::openAsset(const std::string& file, const std::unique_ptr<Platform::AssetManager>& assetManager,
                     VuforiaDriver::PlatformData* platformData)
{
#ifdef __ANDROID__
    // This redirects all MP4 file operations to the Android Asset Manager instance.
    static std::mutex assetManagerMutex;
    static AAssetManager* ndkAssetManager{ nullptr };

    std::scoped_lock lock(assetManagerMutex);
    ndkAssetManager = static_cast<AAssetManager*>(assetManager->getAssetManager());
    if (ndkAssetManager == nullptr)
    {
        log("Could not retrieve AssertManager instance.");
        return nullptr;
    }

    MP4FileProvider fileProvider{ [](const char* name, MP4FileMode mode) -> void* // open()
                                  {
                                      assert(ndkAssetManager != nullptr);
                                      assert(mode == FILEMODE_READ);
                                      AAsset* asset = AAssetManager_open(ndkAssetManager, name, AASSET_MODE_RANDOM);
                                      ndkAssetManager = nullptr;
                                      return asset;
                                  },
                                  [](void* handle, int64_t pos) -> int // seek()
                                  { return AAsset_seek(static_cast<AAsset*>(handle), pos, SEEK_SET) == pos ? 0 : 1; },
                                  [](void* handle, void* buffer, int64_t size, int64_t* nin, int64_t maxChunkSize) -> int // read()
                                  {
                                      *nin = AAsset_read(static_cast<AAsset*>(handle), buffer, size);
                                      return *nin > 0 ? 0 : 1;
                                  },
                                  [](void* handle, const void* buffer, int64_t size, int64_t* nout, int64_t maxChunkSize) -> int // write()
                                  {
                                      assert(false);
                                      return 1;
                                  },
                                  [](void* handle) -> int // close()
                                  {
                                      AAsset_close(static_cast<AAsset*>(handle));
                                      return 0;
                                  },
                                  [](void* handle) -> int64_t // size()
                                  { return AAsset_getLength64(static_cast<AAsset*>(handle)); } };

    MP4FileHandle fileHandle = MP4ReadProvider(file.c_str(), &fileProvider);
    if (fileHandle == nullptr)
    {
        log("Could not open asset: " + file);
        return nullptr;
    }

    // open() was called and used the asset manager
    assert(ndkAssetManager == nullptr);

    return std::unique_ptr<MP4Reader>(new MP4Reader(fileHandle, platformData));
#else
    std::string path = file;

    auto assetDirectory = assetManager->getAssetDirectory();
    if (assetDirectory.has_value())
    {
        path = *assetDirectory + file;
    }

    return open(path, platformData);
#endif
}


MP4Reader::~MP4Reader()
{
    if (mFileHandle != nullptr)
    {
        close();
    }
}


std::vector<MP4Reader::TrackInfo>
MP4Reader::getTracks() const
{
    std::scoped_lock lock(mFileMutex);
    return readTrackInfo(mFileHandle, nullptr);
}


std::vector<MP4Reader::TrackInfo>
MP4Reader::getTracks(const std::string& type) const
{
    std::scoped_lock lock(mFileMutex);
    return readTrackInfo(mFileHandle, type.c_str());
}


bool
MP4Reader::selectTrack(TrackId trackId)
{
    if (mIsPaused)
    {
        log("Cannot select a new track while playback is paused.");
        return false;
    }

    const char* trackType = MP4GetTrackType(mFileHandle, trackId);
    if (trackType == nullptr)
    {
        log("Invalid track ID.");
        return false;
    }

    if (strcmp(MP4_TRACK_TYPE_VIDEO, trackType) != 0)
    {
        // custom data track
        std::scoped_lock lock(mFileMutex);
        mTracks[trackId] = TrackReaderData{ 1, // samples use 1-based indexing
                                            MP4GetTrackNumberOfSamples(mFileHandle, trackId), nullptr };
        return true;
    }

    std::scoped_lock lock(mFileMutex, mFrameOutputMutex);
    auto codec = getTrackVideoCodec(mFileHandle, trackId);
    if (!codec.has_value())
    {
        log("Video codec not supported.");
        return false;
    }

    auto decoder = VideoDecoder::create(*codec, mPlatformData);
    if (decoder == nullptr)
    {
        log("No decoder available for codec of track " + std::to_string(trackId));
        return false;
    }

    auto format = startVideoDecoder(trackId, decoder);
    if (!format.has_value())
    {
        log("Could not start decoder for track " + std::to_string(trackId));
        return false;
    }

    uint32_t maxSampleSize = MP4GetTrackMaxSampleSize(mFileHandle, trackId);
    if (maxSampleSize > mDecoderSampleBuffer.size())
    {
        mDecoderSampleBuffer.resize(maxSampleSize);
    }

    // update output color format from decoder.
    mVideoColorOutputFormat = *format;

    auto& trackData = mTracks[trackId];
    trackData.mReadLocation = 1; // samples use 1-based indexing
    trackData.mNumSamples = MP4GetTrackNumberOfSamples(mFileHandle, trackId);
    trackData.mDecoder = std::move(decoder);
    mFrameOutputs[trackId].mNumFramesInTrack = trackData.mNumSamples;


    // Fill the input queue of the decoder
    if (!queueMoreSamplesForDecoding(trackId))
    {
        log("Failed to queue first samples for decoding of track " + std::to_string(trackId));
        return false;
    }

    return true;
}


std::optional<MP4Reader::SampleInfo>
MP4Reader::readNextSample(TrackId trackId, std::vector<uint8_t>& sampleOut)
{
    if (mIsPaused)
    {
        log("Cannot read from track while playback is paused.");
        return {};
    }

    std::scoped_lock lock(mFileMutex);
    auto trackIt = mTracks.find(trackId);
    if (trackIt == mTracks.end())
    {
        log("Track has not been selected for playback.");
        return {};
    }

    TrackReaderData& trackData = trackIt->second;
    if (trackData.mDecoder != nullptr)
    {
        log("Cannot read raw samples from a video track.");
        return {};
    }
    if (trackData.mReadLocation > trackData.mNumSamples)
    {
        // End of track reached
        return {};
    }

    uint32_t size = MP4GetSampleSize(mFileHandle, trackId, trackData.mReadLocation);
    sampleOut.resize(size);

    MP4Timestamp timestamp{};
    MP4Duration duration{};
    uint8_t* data = sampleOut.data();

    if (!MP4ReadSample(mFileHandle, trackId, trackData.mReadLocation, &data, &size, &timestamp, &duration))
    {
        log("Failed to read sample from file.");
        return {};
    }

    SampleInfo info{};
    info.mPresentationTimestamp = MP4ConvertFromTrackTimestamp(mFileHandle, trackId, timestamp, MP4_USECS_TIME_SCALE);
    info.mDuration = MP4ConvertFromTrackDuration(mFileHandle, trackId, duration, MP4_USECS_TIME_SCALE);

    trackData.mReadLocation++;
    return info;
}


std::optional<MP4Reader::SampleInfo>
MP4Reader::readSample(TrackId trackId, uint32_t sampleIndex, std::vector<uint8_t>& sampleOut)
{
    std::scoped_lock lock(mFileMutex);

    // samples use 1-based indexing
    sampleIndex += 1;

    uint32_t size = MP4GetSampleSize(mFileHandle, trackId, sampleIndex);
    sampleOut.resize(size);

    MP4Timestamp timestamp{};
    MP4Duration duration{};
    uint8_t* data = sampleOut.data();

    if (!MP4ReadSample(mFileHandle, trackId, sampleIndex, &data, &size, &timestamp, &duration))
    {
        log("Failed to read sample from file.");
        return {};
    }

    SampleInfo info{};
    info.mPresentationTimestamp = MP4ConvertFromTrackTimestamp(mFileHandle, trackId, timestamp, MP4_USECS_TIME_SCALE);
    info.mDuration = MP4ConvertFromTrackDuration(mFileHandle, trackId, duration, MP4_USECS_TIME_SCALE);
    return info;
}


std::optional<MP4Reader::SampleInfo>
MP4Reader::readNextFrame(TrackId trackId, std::vector<uint8_t>& frameOut)
{
    if (mIsPaused)
    {
        log("Cannot read from track while playback is paused.");
        return {};
    }

    std::unique_lock outputLock(mFrameOutputMutex);
    auto outputIt = mFrameOutputs.find(trackId);
    if (outputIt == mFrameOutputs.end())
    {
        log("Video track has not been selected for playback.");
        return {};
    }

    auto& outputData = outputIt->second;

    if (outputData.mNumFramesDecoded >= outputData.mNumFramesInTrack)
    {
        // End of stream
        return {};
    }

    // Make sure the input queue is full
    {
        std::scoped_lock fileLock(mFileMutex);
        if (!queueMoreSamplesForDecoding(trackId))
        {
            log("Failed to queue more samples for decoding of track " + std::to_string(trackId));
            return {};
        }
    }

    assert(outputData.mFrameOutput == nullptr);
    outputData.mFrameOutput = &frameOut;

    // Notify decoder callback that we want the next frame
    outputData.mNextFrameOutputReady.notify_all();

    // Wait for decoder callback to copy frame to output
    do
    {
        bool receivedFrame = outputData.mNextFrameOutputReady.wait_for(outputLock, std::chrono::milliseconds(2),
                                                                       [&]() { return outputData.mFrameOutput == nullptr; });

        // Usually the decoder thread has a new frame ready immediately and the wait above is
        // canceled by the notify from that thread.
        //
        // However, on some devices (e.g. Galaxy S10, S10e) the queueMoreSamplesForDecoding() above was not able to
        // actually fill the input queue because the decoder returned too early that no more buffers are available.
        //
        // In such a case the output will be stuck as well, as the decoder (on Android) needs a bunch of samples
        // at once to even start processing them and produce output. The code below tries again to fill the input queue
        // to ensure the platform has enough samples to decode the next frame.
        //
        // (1 H.264 sample == 1 image frame, but the Android decoder seems to process samples in batches and
        // does nothing if it did not get a full batch)
        if (!receivedFrame)
        {
            std::scoped_lock fileLock(mFileMutex);
            if (!queueMoreSamplesForDecoding(trackId))
            {
                log("Failed to queue more samples for decoding of track %d " + std::to_string(trackId));
                return {};
            }
        }
    } while (outputData.mFrameOutput != nullptr);

    // Decoder thread resets pointer to null when it is done
    assert(outputData.mFrameOutput == nullptr);
    return outputData.mFrameInfo;
}


bool
MP4Reader::setPlaybackLocation(TrackId trackId, uint32_t sampleIndex)
{
    if (mIsPaused)
    {
        log("Cannot change playback location while playback is paused.");
        return false;
    }

    std::scoped_lock lock(mFileMutex);
    auto trackIt = mTracks.find(trackId);
    if (trackIt == mTracks.end())
    {
        log("Track " + std::to_string(trackId) + " has not been selected for playback.");
        return false;
    }

    TrackReaderData& trackData = trackIt->second;
    if (sampleIndex >= trackData.mNumSamples)
    {
        log("Track " + std::to_string(trackId) + " has only " + std::to_string(trackData.mNumSamples) + " samples. Sample index " +
            std::to_string(sampleIndex) + " is invalid.");
        return false;
    }

    auto sampleId = sampleIndex + 1; // + 1 due to mapping of 0-based index to mp4v2 SampleID
    if (trackData.mDecoder == nullptr)
    {
        // The track is just a data track, so this is easy:
        trackData.mReadLocation = sampleId;
        return true;
    }

    return seekVideoTrackTo(trackId, sampleId);
}


std::optional<uint32_t>
MP4Reader::getSampleIndexForTimestamp(TrackId trackId, uint64_t timestamp)
{
    std::scoped_lock lock(mFileMutex);
    auto trackIt = mTracks.find(trackId);
    if (trackIt == mTracks.end())
    {
        log("Track " + std::to_string(trackId) + " has not been selected for playback.");
        return {};
    }

    MP4Timestamp trackTimestamp = MP4ConvertToTrackTimestamp(mFileHandle, trackId, timestamp, MP4_USECS_TIME_SCALE);
    MP4SampleId sampleId = MP4GetSampleIdFromTime(mFileHandle, trackId, trackTimestamp);

    if (sampleId == MP4_INVALID_SAMPLE_ID)
    {
        return {};
    }

    return sampleId - 1; // convert to index
}


std::string
MP4Reader::getTitle() const
{
    std::string title;

    std::scoped_lock lock(mFileMutex);
    auto tags = MP4TagsAlloc();
    if (MP4TagsFetch(tags, mFileHandle))
    {
        title = tags->name;
    }
    MP4TagsFree(tags);

    return title;
}


bool
MP4Reader::hasTag(const std::string& key) const
{
    std::scoped_lock lock(mFileMutex);

    MP4ItmfItemList* tagList = MP4ItmfGetItemsByMeaning(mFileHandle, key.c_str(), key.c_str());

    if (tagList == nullptr)
    {
        return false;
    }

    bool found = tagList->size > 0;
    MP4ItmfItemListFree(tagList);
    return found;
}


std::optional<std::string>
MP4Reader::getStringTag(const std::string& key) const
{
    std::scoped_lock lock(mFileMutex);

    std::optional<std::string> value;
    readMetadataTag(mFileHandle, key, MP4_ITMF_BT_UTF8, [&value](const MP4ItmfData& rawValue) {
        const char* charValue = reinterpret_cast<char*>(rawValue.value);
        value = std::string{ charValue, charValue + rawValue.valueSize };
    });
    return value;
}


std::optional<int32_t>
MP4Reader::getInt32Tag(const std::string& key) const
{
    std::scoped_lock lock(mFileMutex);

    std::optional<int32_t> value;
    readMetadataTag(mFileHandle, key, MP4_ITMF_BT_INTEGER, [&value](const MP4ItmfData& rawValue) {
        if (rawValue.valueSize == 4)
        {
            value = (rawValue.value[0] << 24) + (rawValue.value[1] << 16) + (rawValue.value[2] << 8) + rawValue.value[3];
        }
    });
    return value;
}


std::optional<int64_t>
MP4Reader::getInt64Tag(const std::string& key) const
{
    std::scoped_lock lock(mFileMutex);

    std::optional<int64_t> value;
    readMetadataTag(mFileHandle, key, MP4_ITMF_BT_INTEGER, [&value](const MP4ItmfData& rawValue) {
        if (rawValue.valueSize == 8)
        {
            value = (static_cast<uint64_t>(rawValue.value[0]) << 56) + (static_cast<uint64_t>(rawValue.value[1]) << 48) +
                (static_cast<uint64_t>(rawValue.value[2]) << 40) + (static_cast<uint64_t>(rawValue.value[3]) << 32) +
                (static_cast<uint64_t>(rawValue.value[4]) << 24) + (static_cast<uint64_t>(rawValue.value[5]) << 16) +
                (static_cast<uint64_t>(rawValue.value[6]) << 8) + +rawValue.value[7];
        }
    });
    return value;
}


std::optional<std::vector<uint8_t>>
MP4Reader::getByteArrayTag(const std::string& key) const
{
    std::scoped_lock lock(mFileMutex);

    std::optional<std::vector<uint8_t>> value;
    readMetadataTag(mFileHandle, key, MP4_ITMF_BT_IMPLICIT, [&value](const MP4ItmfData& rawValue) {
        value = std::vector<uint8_t>{ rawValue.value, rawValue.value + rawValue.valueSize };
    });
    return value;
}


void
MP4Reader::reset()
{
    {
        // Unlock all blocked decoder threads
        std::unique_lock decoderLock(mFrameOutputMutex);
        for (auto& frameOutput : mFrameOutputs)
        {
            frameOutput.second.mProcessFrameOutput = false;
            frameOutput.second.mNextFrameOutputReady.notify_all();
        }
    }

    std::scoped_lock fileLock(mFileMutex);
    for (auto& track : mTracks)
    {
        if (track.second.mDecoder != nullptr)
        {
            track.second.mDecoder->stop();
        }
    }

    std::scoped_lock frameLock(mFrameOutputMutex);
    mTracks.clear();
    mFrameOutputs.clear();
    mIsPaused = false;
}


void
MP4Reader::close()
{
    reset();

    MP4Close(mFileHandle);
    mFileHandle = nullptr;
}

void
MP4Reader::pause()
{
    if (mIsPaused)
    {
        log("Playback is already paused.");
        return;
    }

    std::scoped_lock lock(mFileMutex);
    for (auto& track : mTracks)
    {
        if (track.second.mDecoder != nullptr)
        {
            {
                std::unique_lock decoderLock(mFrameOutputMutex);
                auto outputIt = mFrameOutputs.find(track.first);
                assert(outputIt != mFrameOutputs.end());

                // Rewind the read location to the last frame that was actually retrieved
                // (during an unfinished seek operation the seek target is stored for resume)
                track.second.mReadLocation =
                    outputIt->second.mSeekToFrame > 0 ? outputIt->second.mSeekToFrame : outputIt->second.mNumFramesDecoded + 1;

                outputIt->second.mProcessFrameOutput = false;
                outputIt->second.mNextFrameOutputReady.notify_all();
            }

            track.second.mDecoder->stop();
        }
    }

    mIsPaused = true;
}


bool
MP4Reader::resume()
{
    if (!mIsPaused)
    {
        // Already resumed
        return true;
    }

    std::scoped_lock lock(mFileMutex);
    for (auto& track : mTracks)
    {
        if (track.second.mDecoder != nullptr)
        {
            auto outputIt = mFrameOutputs.find(track.first);
            assert(outputIt != mFrameOutputs.end());
            outputIt->second.mProcessFrameOutput = true;

            auto format = startVideoDecoder(track.first, track.second.mDecoder);
            if (!format.has_value())
            {
                log("Failed to restart decoder of track " + std::to_string(track.first));
                return false;
            }

            if (!seekVideoTrackTo(track.first, track.second.mReadLocation))
            {
                log("Failed to set playback position during resume of track " + std::to_string(track.first));
                return false;
            }
        }
    }

    mIsPaused = false;
    return true;
}


MP4Reader::MP4Reader(void* fileHandle, VuforiaDriver::PlatformData* platformData) : mPlatformData(platformData), mFileHandle(fileHandle)
{
    assert(mFileHandle != nullptr);
}


void
MP4Reader::onFrameDecoded(TrackId trackId, const uint8_t* image, uint32_t bufferSize, uint32_t stride, uint64_t duration)
{
    std::unique_lock decoderLock(mFrameOutputMutex);

    auto outputIt = mFrameOutputs.find(trackId);
    assert(outputIt != mFrameOutputs.end());
    auto& outputData = outputIt->second;

    if (outputData.mSeekToFrame > 0)
    {
        if (outputData.mNumFramesDecoded < outputData.mSeekToFrame - 1)
        {
            // We are not yet at the seek destination. Discard decoded frame.
            outputData.mElapsedTrackTime += duration;
            outputData.mNumFramesDecoded++;
            return;
        }
        else
        {
            outputData.mSeekToFrame = 0;
        }
    }

    if (!outputData.mProcessFrameOutput)
    {
        return;
    }

    if (outputData.mFrameOutput == nullptr)
    {
        // Wait until readNextFrame() notifies that the next frame was requested
        outputData.mNextFrameOutputReady.wait(decoderLock);

        if (!outputData.mProcessFrameOutput || outputData.mSeekToFrame > 0)
        {
            return;
        }
    }

    assert(outputData.mFrameOutput != nullptr);

    outputData.mFrameInfo.mDuration = duration;
    outputData.mFrameInfo.mPresentationTimestamp = outputData.mElapsedTrackTime;
    outputData.mFrameInfo.mImageStride = stride;
    outputData.mElapsedTrackTime += duration;
    outputData.mNumFramesDecoded++;
    outputData.mFrameOutput->assign(image, image + bufferSize);

    // Indicate that this thread is done with that image
    outputData.mFrameOutput = nullptr;
    outputData.mNextFrameOutputReady.notify_all();
}


bool
MP4Reader::queueMoreSamplesForDecoding(TrackId trackId)
{
    auto trackIt = mTracks.find(trackId);
    assert(trackIt != mTracks.end());

    TrackReaderData& trackData = trackIt->second;
    assert(trackData.mDecoder != nullptr);

    // Fill the input queue of the decoder
    while (trackData.mReadLocation <= trackData.mNumSamples && trackData.mDecoder->canAcceptNewSample())
    {
        mDecoderSampleBuffer.resize(mDecoderSampleBuffer.capacity());
        uint8_t* data = mDecoderSampleBuffer.data();
        uint32_t size = static_cast<uint32_t>(mDecoderSampleBuffer.size());

        MP4Timestamp duration{};
        if (!MP4ReadSample(mFileHandle, trackId, trackData.mReadLocation, &data, &size, nullptr, &duration))
        {
            log("Failed to read sample from file.");
            return false;
        }

        mDecoderSampleBuffer.resize(size);
        uint64_t durationUs = MP4ConvertFromTrackDuration(mFileHandle, trackId, duration, MP4_USECS_TIME_SCALE);
        bool endOfStream = trackData.mReadLocation == trackData.mNumSamples;
        if (!trackData.mDecoder->decodeSample(mDecoderSampleBuffer, durationUs, endOfStream, 0))
        {
            log("Failed to queue sample for decoding.");
            return false;
        }

        trackData.mReadLocation++;
    }
    return true;
}

bool
MP4Reader::seekVideoTrackTo(TrackId trackId, uint32_t seekTargetSampleId)
{
    assert(seekTargetSampleId > 0); // 1-based index

    {
        // Stop processing decoded frames
        std::unique_lock outputLock(mFrameOutputMutex);
        auto outputIt = mFrameOutputs.find(trackId);
        assert(outputIt != mFrameOutputs.end());
        outputIt->second.mProcessFrameOutput = false;
        outputIt->second.mNextFrameOutputReady.notify_all();
    }

    // Playback of encoded video can only start at certain locations (sync samples, for H.264 -> I-frames)
    auto trackIt = mTracks.find(trackId);
    assert(trackIt != mTracks.end());

    TrackReaderData& trackData = trackIt->second;
    assert(trackData.mDecoder != nullptr);

    // index (1-based) of the closest sample at which playback can be started
    uint32_t seekStartSampleId = 0;
    for (uint32_t i = seekTargetSampleId; i > 0; --i)
    {
        if (MP4GetSampleSync(mFileHandle, trackId, i) == 1)
        {
            seekStartSampleId = i;
            break;
        }
    }

    if (seekStartSampleId == 0)
    {
        log("Seeking in track " + std::to_string(trackId) + " failed.");
        return false;
    }

    // Reset the file reader to the new start point
    trackData.mReadLocation = seekStartSampleId;

    // Compute the timestamp of the new start point
    uint64_t time = MP4GetSampleTime(mFileHandle, trackId, seekStartSampleId);
    uint64_t newElapsedTrackTime = MP4ConvertFromTrackDuration(mFileHandle, trackId, time, MP4_USECS_TIME_SCALE);

    if (!trackData.mDecoder->flush())
    {
        log("Failed to flush decoder while seeking in track " + std::to_string(trackId));
        return false;
    }

    {
        // Reset the state of the output data structure
        std::unique_lock outputLock(mFrameOutputMutex);
        auto outputIt = mFrameOutputs.find(trackId);
        assert(outputIt != mFrameOutputs.end());
        outputIt->second.mNumFramesDecoded = seekStartSampleId - 1;
        outputIt->second.mElapsedTrackTime = newElapsedTrackTime;
        outputIt->second.mSeekToFrame = seekTargetSampleId;
        outputIt->second.mProcessFrameOutput = true;
        outputIt->second.mNextFrameOutputReady.notify_all();
    }

    // Fill the queue until the read location is at least
    // at the target position. The decoder output callback
    // will discard any decoded frames that need to be skipped
    // to reach the target.
    while (trackData.mReadLocation <= seekTargetSampleId)
    {
        if (!queueMoreSamplesForDecoding(trackId))
        {
            log("Failed to queue more samples during seek operation in track " + std::to_string(trackId));
            return false;
        }
    }

    return true;
}


std::optional<VuforiaDriver::PixelFormat>
MP4Reader::startVideoDecoder(TrackId trackId, const std::unique_ptr<VideoDecoder>& decoder)
{
    uint16_t width = MP4GetTrackVideoWidth(mFileHandle, trackId);
    uint16_t height = MP4GetTrackVideoHeight(mFileHandle, trackId);

    auto codecConfigData = buildCodecConfigData(mFileHandle, trackId);
    auto callback = [this, trackId](const uint8_t* image, uint32_t size, uint32_t stride, uint64_t duration) {
        onFrameDecoded(trackId, image, size, stride, duration);
    };

    return decoder->start(width, height, codecConfigData, callback);
}
