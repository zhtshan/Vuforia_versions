/*===============================================================================
Copyright (c) 2021 PTC Inc., Its Subsidiary Companies, and /or its Partners.
All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

#include "Platform/Android/AndroidVideoDecoder.h"
#include "Platform/Android/ScopedJNIEnv.h"
#include "Platform/Platform.h"

#include <android/log.h>
#include <media/NdkMediaCodec.h>

#include <fstream>
using namespace Platform;

// Android SDK constants missing in NDK
constexpr int32_t COLOR_FormatYUV420SemiPlanar = 21; // NV12
constexpr int32_t COLOR_FormatYUV420Planar = 19;     // I420/YUV420p

constexpr auto NDK_AMEDIAFORMAT_KEY_SLICE_HEIGHT = "slice-height";

std::unique_ptr<VideoDecoder>
VideoDecoder::create(VideoCodec codecType, VuforiaDriver::PlatformData* platformData)
{
    switch (codecType)
    {
        case VideoCodec::H264_AVCC:
            return std::make_unique<AndroidVideoDecoder>(platformData);
        default:
            // Invalid type
            assert(false);
            return nullptr;
    }
}


AndroidVideoDecoder::AndroidVideoDecoder(VuforiaDriver::PlatformData* platformData) : mPlatformData(platformData) { }


AndroidVideoDecoder::~AndroidVideoDecoder()
{
    if (mCodec != nullptr)
    {
        mRunWorkerThread = false;
        reset();
    }
}


std::optional<VuforiaDriver::PixelFormat>
AndroidVideoDecoder::start(uint16_t width, uint16_t height, const VideoCodecConfigurationData& codecConfigurationData,
                           OutputCallback outputCallback)
{
    if (mCodec != nullptr)
    {
        Platform::log("Decoder already started");
        return {};
    }

    if (!isSupportedResolution(width, height))
    {
        Platform::log("Unsupported resolution for decoding");
        return {};
    }

    if (codecConfigurationData.find(VideoCodecConfigurationDataType::H264_SPS) == codecConfigurationData.end() ||
        codecConfigurationData.find(VideoCodecConfigurationDataType::H264_PPS) == codecConfigurationData.end())
    {
        Platform::log("Missing required codec configuration data");
        return {};
    }

    mCodecConfigurationData = codecConfigurationData;

    // Prepend Annex-B header to codec config data
    for (auto& data : mCodecConfigurationData)
    {
        prependAnnexBHeader(data.second);
    }

    auto& sps = mCodecConfigurationData.at(VideoCodecConfigurationDataType::H264_SPS);
    auto& pps = mCodecConfigurationData.at(VideoCodecConfigurationDataType::H264_PPS);

    auto codec = AMediaCodec_createDecoderByType("video/avc");
    if (codec == nullptr)
    {
        Platform::log("Failed to create native video decoder");
        return {};
    }

    auto format = AMediaFormat_new();
    AMediaFormat_setString(format, AMEDIAFORMAT_KEY_MIME, "video/avc");
    AMediaFormat_setInt32(format, AMEDIAFORMAT_KEY_WIDTH, width);
    AMediaFormat_setInt32(format, AMEDIAFORMAT_KEY_HEIGHT, height);
    AMediaFormat_setBuffer(format, "csd-0", sps.data(), sps.size());
    AMediaFormat_setBuffer(format, "csd-1", pps.data(), pps.size());

    media_status_t ok = AMediaCodec_configure(codec, format, nullptr, nullptr, 0);
    AMediaFormat_delete(format);

    if (ok != AMEDIA_OK)
    {
        Platform::log("Failed to configure native video decoder");
        AMediaCodec_delete(codec);
        return {};
    }

    auto outputFormat = AMediaCodec_getOutputFormat(codec);
    int32_t colorFormat;
    AMediaFormat_getInt32(outputFormat, AMEDIAFORMAT_KEY_COLOR_FORMAT, &colorFormat);
    AMediaFormat_delete(outputFormat);

    if (colorFormat == COLOR_FormatYUV420Planar)
    {
        mNativeColorOutputFormat = VuforiaDriver::PixelFormat::YUV420P;
    }
    else if (colorFormat == COLOR_FormatYUV420SemiPlanar)
    {
        mNativeColorOutputFormat = VuforiaDriver::PixelFormat::NV12;
    }
    else
    {
        Platform::log("Unsupported output image format= " + std::to_string(colorFormat));
        AMediaCodec_delete(codec);
        return {};
    }

    if (AMediaCodec_start(codec) != AMEDIA_OK)
    {
        Platform::log("Failed to start native video decoder");
        AMediaCodec_delete(codec);
        return {};
    }

    mCodec = codec;
    mOutputCallback = outputCallback;
    mOutputHeight = height;
    mOutputWidth = width;

    mRunWorkerThread = true;
    mOutputWorker = std::thread([this]() { consumeOutputBuffers(); });

    // Wait for the first input buffer, which indicates codec startup is complete
    mNextInputBuffer = AMediaCodec_dequeueInputBuffer(mCodec, -1);

    return mNativeColorOutputFormat;
}


bool
AndroidVideoDecoder::decodeSample(const std::vector<uint8_t>& sample, uint64_t presentationTimestampUs, bool endOfStream, int32_t timeoutUs)
{
    if (mCodec == nullptr)
    {
        Platform::log("Decoder not started");
        return false;
    }

    auto inputBuffer = getNextInputBuffer(timeoutUs);
    if (inputBuffer < 0)
    {
        Platform::log("No free buffer available");
        return false;
    }

    size_t bufferSize = 0;
    uint8_t* buffer = AMediaCodec_getInputBuffer(mCodec, inputBuffer, &bufferSize);
    if (bufferSize < sample.size())
    {
        Platform::log("Provided sample exceeds decoder buffer size");
        return false;
    }

    memcpy(buffer, sample.data(), sample.size());

    if (!convertAvccToAnnexB(buffer, sample.size()))
    {
        Platform::log("Failed to convert the sample to Annex B.");
        return false;
    }

    uint32_t flags = endOfStream ? AMEDIACODEC_BUFFER_FLAG_END_OF_STREAM : 0;
    if (AMediaCodec_queueInputBuffer(mCodec, inputBuffer, 0, sample.size(), presentationTimestampUs, flags) != AMEDIA_OK)
    {
        Platform::log("Failed to queue sample for decoding");
        return false;
    }

    mEndOfStreamWasSubmitted = endOfStream;
    mNextInputBuffer = -1;
    return true;
}


bool
AndroidVideoDecoder::canAcceptNewSample()
{
    if (mCodec == nullptr)
    {
        return false;
    }
    return getNextInputBuffer(0) >= 0;
}


void
AndroidVideoDecoder::stop()
{
    if (mCodec == nullptr)
    {
        return;
    }

    if (!mEndOfStreamWasSubmitted)
    {
        // Submit end of stream notification if it hasn't been done so far as part of decodeSample()
        auto inputBufferId = AMediaCodec_dequeueInputBuffer(mCodec, -1);
        if (AMediaCodec_queueInputBuffer(mCodec, inputBufferId, 0, 0, 0, AMEDIACODEC_BUFFER_FLAG_END_OF_STREAM) != AMEDIA_OK)
        {
            Platform::log("Failed to complete the decoding of queued frames. Stopping anyway.");
            mRunWorkerThread = false;
        }
    }

    reset();
}


void
AndroidVideoDecoder::reset()
{
    assert(mCodec != nullptr);

    // thread will exit either due to FLAG_END_OF_STREAM or mRunWorkerThread == false
    if (mOutputWorker.joinable())
    {
        mOutputWorker.join();
    }

    AMediaCodec_stop(mCodec);
    AMediaCodec_delete(mCodec);

    mCodec = nullptr;

    mOutputCallback = {};
    mOutputWidth = {};
    mOutputHeight = {};
    mCodecConfigurationData.clear();
    mNextInputBuffer = -1;
    mEndOfStreamWasSubmitted = false;
}


bool
AndroidVideoDecoder::flush()
{
    if (mCodec == nullptr)
    {
        return false;
    }

    // Ask the worker thread to flush
    std::unique_lock lock(mFlushMutex);
    mPendingFlush = true;
    mFlushCv.wait(lock, [&] { return !mPendingFlush; });

    if (mFlushResult)
    {
        Platform::log("Failed to flush the decoder pipeline.");
        return false;
    }

    mNextInputBuffer = -1;
    return true;
}


void
AndroidVideoDecoder::consumeOutputBuffers()
{
    Android::ScopedJNIEnv jniEnv(mPlatformData->javaVM, mPlatformData->jniVersion);
    if (jniEnv == nullptr)
    {
        Platform::log("No JNIEnv available");
        return;
    }

    while (mRunWorkerThread)
    {
        if (mPendingFlush)
        {
            std::unique_lock lock(mFlushMutex);
            mFlushResult = AMediaCodec_flush(mCodec) != AMEDIA_OK;
            mPendingFlush = false;
            mFlushCv.notify_all();
        }

        AMediaCodecBufferInfo info{};
        constexpr auto timeout10ms = 10000;
        auto outputBufferId = AMediaCodec_dequeueOutputBuffer(mCodec, &info, timeout10ms);

        if (outputBufferId == AMEDIACODEC_INFO_TRY_AGAIN_LATER || outputBufferId == AMEDIACODEC_INFO_OUTPUT_FORMAT_CHANGED ||
            outputBufferId == AMEDIACODEC_INFO_OUTPUT_BUFFERS_CHANGED)
        {
            continue;
        }

        if (outputBufferId < 0)
        {
            // The cause of this is most likely a bug in the underlying decoder implementation of the device.
            Platform::log("Android video decoder returned unexpected error code " + std::to_string(outputBufferId) + ". Cannot continue.");
            return;
        }

        size_t bufferSize = 0;
        uint8_t* buffer = AMediaCodec_getOutputBuffer(mCodec, outputBufferId, &bufferSize);

        if (info.size > 0)
        {
            int32_t horizontalStride = mOutputWidth;
            int32_t verticalStride = mOutputHeight;
            auto outputFormat = AMediaCodec_getOutputFormat(mCodec);
            AMediaFormat_getInt32(outputFormat, AMEDIAFORMAT_KEY_STRIDE, &horizontalStride);
            AMediaFormat_getInt32(outputFormat, NDK_AMEDIAFORMAT_KEY_SLICE_HEIGHT, &verticalStride);
            AMediaFormat_delete(outputFormat);

            auto trimmedSize =
                trimVerticalStride(buffer, info.size, horizontalStride, verticalStride, mOutputHeight, mNativeColorOutputFormat);
            mOutputCallback(buffer, trimmedSize, horizontalStride, static_cast<uint64_t>(info.presentationTimeUs));
        }

        if (AMediaCodec_releaseOutputBuffer(mCodec, outputBufferId, false) != AMEDIA_OK)
        {
            Platform::log("Failed to release output buffer");
        }

        if (info.flags & AMEDIACODEC_BUFFER_FLAG_END_OF_STREAM)
        {
            return;
        }
    }
}


ssize_t
AndroidVideoDecoder::getNextInputBuffer(int32_t timeoutUs)
{
    if (mNextInputBuffer < 0)
    {
        mNextInputBuffer = AMediaCodec_dequeueInputBuffer(mCodec, timeoutUs);
    }
    return mNextInputBuffer;
}
