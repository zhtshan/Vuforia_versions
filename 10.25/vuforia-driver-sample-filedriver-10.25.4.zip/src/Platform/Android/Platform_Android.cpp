/*===============================================================================
Copyright (c) 2021 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

#include "Platform/Android/ScopedJNIEnv.h"
#include "Platform/Platform.h"

#include <android/asset_manager.h>
#include <android/asset_manager_jni.h>
#include <android/log.h>

#include <limits.h>
#include <stdlib.h>

namespace Platform
{

struct AndroidAssetManagerImplData : public AssetManager::AssetManagerImplData
{
    jobject jniAssetManager{ nullptr };
};


void
log(const std::string& message)
{
    __android_log_print(ANDROID_LOG_DEBUG, "Vuforia-FileDriver", "%s", message.c_str());
}


std::optional<std::string>
normalizePath(const std::string& path)
{
    char buffer[PATH_MAX];
    auto result = realpath(path.c_str(), buffer);

    if (result == nullptr)
    {
        return std::nullopt;
    }

    return std::string(result);
}


AssetManager::AssetManager(VuforiaDriver::PlatformData* platformData) :
    mPlatformData(platformData),
    mImpl(std::make_unique<AndroidAssetManagerImplData>())
{
    Android::ScopedJNIEnv jniEnv(mPlatformData->javaVM, mPlatformData->jniVersion);
    if (jniEnv == nullptr)
    {
        log("No JNIEnv available");
        return;
    }

    jclass activityClass = jniEnv->GetObjectClass(mPlatformData->activity);
    jmethodID activityClassGetAssets = jniEnv->GetMethodID(activityClass, "getAssets", "()Landroid/content/res/AssetManager;");
    jniEnv->DeleteLocalRef(activityClass);

    jobject assetManager = jniEnv->CallObjectMethod(mPlatformData->activity, activityClassGetAssets);
    static_cast<AndroidAssetManagerImplData*>(mImpl.get())->jniAssetManager = jniEnv->NewGlobalRef(assetManager);
    jniEnv->DeleteLocalRef(assetManager);
}


AssetManager::~AssetManager()
{
    Android::ScopedJNIEnv jniEnv(mPlatformData->javaVM, mPlatformData->jniVersion);
    if (jniEnv == nullptr)
    {
        log("No JNIEnv available to cleanup global references");
        return;
    }

    auto data = static_cast<AndroidAssetManagerImplData*>(mImpl.get());
    if (data->jniAssetManager != nullptr)
    {
        jniEnv->DeleteGlobalRef(data->jniAssetManager);
        data->jniAssetManager = nullptr;
    }
}


std::optional<std::string>
AssetManager::getAssetDirectory()
{
    return {};
}


void*
AssetManager::getAssetManager()
{
    Android::ScopedJNIEnv jniEnv(mPlatformData->javaVM, mPlatformData->jniVersion);
    if (jniEnv == nullptr)
    {
        log("No JNIEnv available");
        return nullptr;
    }

    auto data = static_cast<AndroidAssetManagerImplData*>(mImpl.get());
    if (data->jniAssetManager == nullptr)
    {
        log("No Java AssetManager instance available");
        return nullptr;
    }

    return AAssetManager_fromJava(jniEnv.get(), data->jniAssetManager);
}

} // Platform
