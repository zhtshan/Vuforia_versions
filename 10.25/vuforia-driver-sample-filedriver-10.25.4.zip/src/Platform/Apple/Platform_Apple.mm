/*===============================================================================
Copyright (c) 2018 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/
#include "FileDriverUserData.h"
#include "Platform/Platform.h"

#import <Foundation/Foundation.h>

#include <limits.h>
#include <stdlib.h>

namespace Platform
{

void
log(const std::string& message)
{
    NSLog(@"[Vuforia-FileDriver] %s", message.c_str());
}


std::optional<std::string>
normalizePath(const std::string& path)
{
    char buffer[PATH_MAX];
    auto result = realpath(path.c_str(), buffer);

    if (result == nullptr)
    {
        return std::nullopt;
    }

    return std::string(result);
}


AssetManager::AssetManager(VuforiaDriver::PlatformData* platformData)
{
    (void)mPlatformData; // silence "unused private field" error
}


AssetManager::~AssetManager() { }


std::optional<std::string>
AssetManager::getAssetDirectory()
{
    return std::string([[[NSBundle mainBundle] resourcePath] UTF8String]) + "/";
}


void*
AssetManager::getAssetManager()
{
    return nullptr;
}

} // Platform
