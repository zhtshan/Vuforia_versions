/*===============================================================================
Copyright (c) 2021 PTC Inc., Its Subsidiary Companies, and /or its Partners.
All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

#include "Platform/Apple/AppleVideoDecoder.h"
#include "Platform/Platform.h"

#include <cassert>
#include <chrono>

using namespace Platform;

constexpr uint32_t NALU_HEADER_LENGTH = 4;
constexpr uint32_t MAX_SAMPLES_IN_QUEUE = 4;

std::unique_ptr<VideoDecoder>
VideoDecoder::create(VideoCodec codecType, VuforiaDriver::PlatformData*)
{
    switch (codecType)
    {
        case VideoCodec::H264_AVCC:
            return std::make_unique<AppleVideoDecoder>();
        default:
            // Invalid type
            assert(false);
            return nullptr;
    }
}


AppleVideoDecoder::~AppleVideoDecoder()
{
    if (mSession != nullptr)
    {
        reset();
    }
}


std::optional<VuforiaDriver::PixelFormat>
AppleVideoDecoder::start(uint16_t width, uint16_t height, const VideoCodecConfigurationData& codecConfigurationData,
                         OutputCallback outputCallback)
{
    if (mSession != nullptr)
    {
        Platform::log("Decoder already started");
        return {};
    }

    if (!isSupportedResolution(width, height))
    {
        Platform::log("Unsupported resolution for decoding");
        return {};
    }

    @autoreleasepool
    {
        NSDictionary* outputPixelBufferInfo =
            [NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithInt:kCVPixelFormatType_420YpCbCr8BiPlanarVideoRange],
                                                       kCVPixelBufferPixelFormatTypeKey, nil];

        // Configure codec
        auto spsIt = codecConfigurationData.find(VideoCodecConfigurationDataType::H264_SPS);
        auto ppsIt = codecConfigurationData.find(VideoCodecConfigurationDataType::H264_PPS);

        if (spsIt == codecConfigurationData.end() || ppsIt == codecConfigurationData.end())
        {
            Platform::log("Missing required codec configuration parameters");
            return {};
        }

        const uint8_t* parameterSets[]{ spsIt->second.data(), ppsIt->second.data() };
        const size_t parameterSetLengths[]{ spsIt->second.size(), ppsIt->second.size() };

        OSStatus result = CMVideoFormatDescriptionCreateFromH264ParameterSets(nullptr, 2, parameterSets, parameterSetLengths,
                                                                              NALU_HEADER_LENGTH, &mVideoFormatDescription);
        if (result != noErr)
        {
            Platform::log("Invalid codec configuration parameters.");
            return {};
        }

        VTDecompressionOutputCallbackRecord callBackRecord;
        callBackRecord.decompressionOutputRefCon = this;
        callBackRecord.decompressionOutputCallback = [](void* instance, void*, OSStatus status, VTDecodeInfoFlags infoFlags,
                                                        CVImageBufferRef imageBuffer, CMTime timestamp, CMTime duration) {
            static_cast<AppleVideoDecoder*>(instance)->onFrameDecoded(status, infoFlags, imageBuffer, timestamp, duration);
        };

        result = VTDecompressionSessionCreate(nullptr, mVideoFormatDescription, nullptr, (__bridge CFDictionaryRef)outputPixelBufferInfo,
                                              &callBackRecord, &mSession);

        if (result != noErr)
        {
            Platform::log("Failed to create native video decoder");
            CFRelease(mVideoFormatDescription);
            mVideoFormatDescription = nullptr;
            return {};
        }
    }

    mSampleBufferPool = CMMemoryPoolCreate(nullptr);
    mOutputCallback = outputCallback;
    mRunDecoderThread = true;
    mDecoderThread = std::thread([this]() { decoderThread(); });
    return VuforiaDriver::PixelFormat::NV12;
}


bool
AppleVideoDecoder::decodeSample(const std::vector<uint8_t>& sample, uint64_t presentationTimestampUs, bool endOfStream, int32_t timeoutUs)
{
    if (mSession == nullptr)
    {
        Platform::log("Decoder not started");
        return false;
    }

    std::unique_lock lock(mSampleQueueMutex);

    if (mEndOfStream)
    {
        Platform::log("Cannot queue more frame as end of stream has been signaled");
        return false;
    }

    if (mSampleQueue.size() >= MAX_SAMPLES_IN_QUEUE)
    {
        auto predicate = [&]() { return mSampleQueue.size() < MAX_SAMPLES_IN_QUEUE; };

        if (timeoutUs > 0)
        {
            auto timeout = std::chrono::microseconds(timeoutUs);
            if (!mSampleQueueCv.wait_for(lock, timeout, predicate))
            {
                return false;
            }
        }
        else if (timeoutUs < 0)
        {
            mSampleQueueCv.wait(lock, predicate);
        }
        else
        {
            return false;
        }
    }

    // Size of pool is limited because there will never be more than MAX_SAMPLES_IN_QUEUE buffers at the same time
    CFAllocatorRef blockAllocator = CMMemoryPoolGetAllocator(mSampleBufferPool);

    CMBlockBufferRef blockBuffer = nullptr;
    OSStatus result = CMBlockBufferCreateWithMemoryBlock(nullptr, nullptr, sample.size(), blockAllocator, nullptr, 0, sample.size(),
                                                         kCMBlockBufferAssureMemoryNowFlag, &blockBuffer);
    if (result != noErr)
    {
        Platform::log("Failed to create buffer for native video decoder");
        return false;
    }

    uint8_t* blockBufferData = nullptr;
    result = CMBlockBufferGetDataPointer(blockBuffer, 0, nullptr, nullptr, reinterpret_cast<char**>(&blockBufferData));
    if (result != noErr)
    {
        Platform::log("Failed to get data pointer for memory block");
        CFRelease(blockBuffer);
        return false;
    }

    memcpy(blockBufferData, sample.data(), sample.size());

    CMSampleTimingInfo timingInfo{};
    timingInfo.duration = kCMTimeInvalid;
    timingInfo.decodeTimeStamp = kCMTimeInvalid;
    timingInfo.presentationTimeStamp = CMTimeMake(presentationTimestampUs, USEC_PER_SEC);

    CMSampleBufferRef sampleBuffer = nullptr;
    result = CMSampleBufferCreate(nullptr, blockBuffer, true, nullptr, nullptr, mVideoFormatDescription, 1, 1, &timingInfo, 0, nullptr,
                                  &sampleBuffer);
    CFRelease(blockBuffer);

    if (result != noErr)
    {
        Platform::log("Failed to create native sample buffer");
        return false;
    }

    assert(mSampleQueue.size() < MAX_SAMPLES_IN_QUEUE);
    mSampleQueue.push_back(sampleBuffer);

    if (endOfStream)
    {
        mEndOfStream = true;
    }

    mSampleQueueCv.notify_all();
    return true;
}


bool
AppleVideoDecoder::canAcceptNewSample()
{
    if (mSession == nullptr)
    {
        return false;
    }
    std::scoped_lock lock(mSampleQueueMutex);
    return mSampleQueue.size() < MAX_SAMPLES_IN_QUEUE;
}


void
AppleVideoDecoder::decoderThread()
{
    while (mRunDecoderThread)
    {
        CMSampleBufferRef nextSample = nullptr;

        {
            std::unique_lock lock(mSampleQueueMutex);
            if (mSampleQueue.empty())
            {
                mSampleQueueCv.wait(lock, [&]() { return !mSampleQueue.empty() || !mRunDecoderThread || mPendingFlush; });
            }

            if (!mRunDecoderThread)
            {
                break;
            }

            if (mPendingFlush)
            {
                // Flushing the queue here on the worker thread ensures
                // that there in no frame being processed by the system
                // during flush (as this frame would be delivered to the output
                // after the flush() call completed)
                mSampleQueue.clear();
                mEndOfStream = false;
                mPendingFlush = false;
                mSampleQueueCv.notify_all();
                continue;
            }

            nextSample = mSampleQueue.front();
            mSampleQueue.pop_front();
            mSampleQueueCv.notify_all();
        }

        VTDecodeInfoFlags flagOut{};
        OSStatus result = VTDecompressionSessionDecodeFrame(mSession, nextSample, 0, nullptr, &flagOut);

        CFRelease(nextSample);

        if (result != noErr)
        {
            Platform::log("Native video decoder failed to decode frame");
        }

        if (flagOut & kVTEncodeInfo_FrameDropped)
        {
            Platform::log("Native video decoder dropped frame");
        }
    }
}

void
AppleVideoDecoder::onFrameDecoded(OSStatus status, VTDecodeInfoFlags infoFlags, CVImageBufferRef imageBuffer, CMTime presentationTimeStamp,
                                  CMTime presentationDuration)
{
    if (mDiscardDecodedFrames == true)
    {
        return;
    }

    if (status != noErr || imageBuffer == nullptr)
    {
        Platform::log("Decoding failed with code " + std::to_string(status));
        return;
    }
    if (infoFlags & kVTDecodeInfo_FrameDropped)
    {
        Platform::log("Native video decoder dropped frame");
        return;
    }

    if (CVPixelBufferLockBaseAddress(imageBuffer, kCVPixelBufferLock_ReadOnly) != noErr)
    {
        Platform::log("Failed to lock native video frame");
        return;
    }

    uint64_t timestamp = static_cast<uint64_t>(CMTimeGetSeconds(presentationTimeStamp) * USEC_PER_SEC);
    CGSize cgSize = CVImageBufferGetDisplaySize(imageBuffer);

    assert(CVPixelBufferIsPlanar(imageBuffer));
    assert(CVPixelBufferGetPlaneCount(imageBuffer) == 2);
    assert(CVPixelBufferGetPixelFormatType(imageBuffer) == kCVPixelFormatType_420YpCbCr8BiPlanarVideoRange);

    int height = static_cast<int>(cgSize.height);
    uint8_t* yPlane = static_cast<uint8_t*>(CVPixelBufferGetBaseAddressOfPlane(imageBuffer, 0));
    uint8_t* uvPlane = static_cast<uint8_t*>(CVPixelBufferGetBaseAddressOfPlane(imageBuffer, 1));
    uint32_t yStride = static_cast<uint32_t>(CVPixelBufferGetBytesPerRowOfPlane(imageBuffer, 0));
    uint32_t uvStride = static_cast<uint32_t>(CVPixelBufferGetBytesPerRowOfPlane(imageBuffer, 1));

    uint32_t ySize = yStride * height;
    uint32_t uvSize = uvStride * (height / 2);

    assert(yStride == uvStride);

    // Check if the buffer layout is compatible with the expected output format.
    // If there is padding between the planes, the frame is copied to a temporary buffer first.
    if (yPlane + ySize == uvPlane)
    {
        mOutputCallback(yPlane, ySize + uvSize, yStride, timestamp);
    }
    else
    {
        uint32_t bufferSize = ySize + uvSize;
        if (mOutputFrameBuffer.size() < bufferSize)
        {
            mOutputFrameBuffer.resize(bufferSize);
        }

        memcpy(mOutputFrameBuffer.data(), yPlane, ySize);
        memcpy(mOutputFrameBuffer.data() + ySize, uvPlane, uvSize);
        mOutputCallback(mOutputFrameBuffer.data(), bufferSize, yStride, timestamp);
    }

    if (CVPixelBufferUnlockBaseAddress(imageBuffer, kCVPixelBufferLock_ReadOnly) != noErr)
    {
        Platform::log("Failed to unlock native video frame");
    }
}


void
AppleVideoDecoder::stop()
{
    if (mSession == nullptr)
    {
        return;
    }

    {
        // Signal end of stream
        std::unique_lock lock(mSampleQueueMutex);
        mEndOfStream = true;

        // Wait until queue was processed completely
        if (!mSampleQueue.empty())
        {
            mSampleQueueCv.wait(lock, [&]() { return mSampleQueue.empty(); });
        }
    }

    reset();
}


bool
AppleVideoDecoder::flush()
{
    if (mSession == nullptr)
    {
        Platform::log("Decoder not running");
        return false;
    }

    std::unique_lock lock(mSampleQueueMutex);

    // Ask the worker thread to flush
    mPendingFlush = true;
    mSampleQueueCv.notify_all();
    mSampleQueueCv.wait(lock, [&] { return !mPendingFlush; });
    return true;
}


void
AppleVideoDecoder::reset()
{
    assert(mSession != nullptr);

    mRunDecoderThread = false;
    mSampleQueueCv.notify_all();
    if (mDecoderThread.joinable())
    {
        mDecoderThread.join();
    }

    for (auto& sample : mSampleQueue)
    {
        CFRelease(sample);
    }

    VTDecompressionSessionInvalidate(mSession);
    CFRelease(mSession);
    mSession = nullptr;

    CMMemoryPoolInvalidate(mSampleBufferPool);
    CFRelease(mSampleBufferPool);
    mSampleBufferPool = nullptr;

    CFRelease(mVideoFormatDescription);
    mOutputCallback = {};

    mDiscardDecodedFrames = false;
}
