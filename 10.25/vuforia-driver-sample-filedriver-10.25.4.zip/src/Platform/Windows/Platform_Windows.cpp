/*===============================================================================
Copyright (c) 2021 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/
#include "FileDriverUserData.h"
#include "Platform/Platform.h"

#define WIN32_LEAN_AND_MEAN
#include <Windows.h>

#include <cassert>
#include <memory>
#include <vector>

namespace
{

std::string
toString(const wchar_t* utf16String)
{
    assert(utf16String != nullptr);

    int utf16Length = static_cast<int>(std::wcslen(utf16String));
    if (utf16Length == 0)
    {
        return {};
    }

    int utf8Length = ::WideCharToMultiByte(CP_UTF8, 0, utf16String, utf16Length, nullptr, 0, nullptr, nullptr);
    if (utf8Length == 0)
    {
        return {};
    }

    std::string utf8String(utf8Length, '?');
    ::WideCharToMultiByte(CP_UTF8, 0, utf16String, utf16Length, utf8String.data(), utf8Length, nullptr, nullptr);
    return utf8String;
}


std::wstring
toWString(const std::string& utf8String)
{
    if (utf8String.length() == 0)
    {
        return {};
    }

    int utf16Length = ::MultiByteToWideChar(CP_UTF8, 0, utf8String.c_str(), static_cast<int>(utf8String.length()), nullptr, 0);
    if (utf16Length == 0)
    {
        return {};
    }

    std::wstring utf16String(utf16Length, L'?');
    ::MultiByteToWideChar(CP_UTF8, 0, utf8String.c_str(), static_cast<int>(utf8String.length()), utf16String.data(), utf16Length);
    return utf16String;
}

}

namespace Platform
{

void
log(const std::string& message)
{
    std::string messageWithTag = "[Vuforia-FileDriver] ";
    messageWithTag += message;
    messageWithTag += "\n";
    OutputDebugStringA(messageWithTag.c_str());
}


std::optional<std::string>
normalizePath(const std::string& path)
{
    auto wstr = toWString(path);
    auto length = GetFullPathNameW(wstr.c_str(), 0, nullptr, nullptr);
    if (length == 0)
    {
        return {};
    }

    std::vector<wchar_t> buffer(length + 1);
    if (GetFullPathNameW(wstr.c_str(), length, buffer.data(), nullptr) == 0)
    {
        return {};
    }
    buffer[length] = 0;
    return toString(buffer.data());
}


AssetManager::AssetManager(VuforiaDriver::PlatformData*) { }


AssetManager::~AssetManager() { }


std::optional<std::string>
AssetManager::getAssetDirectory()
{
#if defined(WINAPI_FAMILY) && (WINAPI_FAMILY == WINAPI_FAMILY_PC_APP) // UWP
    return toString(Windows::ApplicationModel::Package::Current->InstalledLocation->Path->Data()) + "\\";
#else
    return {};
#endif
}


void*
AssetManager::getAssetManager()
{
    return nullptr;
}

} // Platform
