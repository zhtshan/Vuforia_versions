/*===============================================================================
Copyright (c) 2021 PTC Inc., Its Subsidiary Companies, and /or its Partners.
All Rights Reserved.

Confidential and Proprietary - Protected under copyright and other laws.
Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

#include "Platform/Windows/SampleProviderMediaSource.h"

#include "Platform/Platform.h"
#include "Platform/Windows/SampleProviderStreamSource.h"
#include "Platform/Windows/ScopedComPtr.h"

#include <cassert>

using namespace Platform::Windows;


SampleProviderMediaSource::SampleProviderMediaSource(IMFMediaType* inputFormat, size_t maxSampleQueueSize) : mInputFormat(inputFormat)
{
    assert(inputFormat != nullptr);

    if (FAILED(initializeStream(maxSampleQueueSize)))
    {
        Platform::log("Failed to setup stream source");
    }
}


SampleProviderMediaSource::~SampleProviderMediaSource()
{
    assert(mRefCount == 0);
}


STDMETHODIMP_(ULONG)
SampleProviderMediaSource::AddRef()
{
    return ++mRefCount;
}


STDMETHODIMP_(ULONG)
SampleProviderMediaSource::Release()
{
    ULONG count = --mRefCount;
    if (count == 0)
    {
        delete this;
    }
    return count;
}


STDMETHODIMP
SampleProviderMediaSource::QueryInterface(REFIID iid, void** ppv)
{
    if (ppv == nullptr)
    {
        return E_POINTER;
    }

    if (iid == IID_IUnknown)
    {
        *ppv = static_cast<IUnknown*>(static_cast<IMFMediaSource*>(this));
    }
    else if (iid == __uuidof(IMFMediaSource))
    {
        *ppv = static_cast<IMFMediaSource*>(this);
    }
    else if (iid == __uuidof(IMFMediaEventGenerator))
    {
        *ppv = static_cast<IMFMediaEventGenerator*>(this);
    }
    else
    {
        *ppv = nullptr;
        return E_NOINTERFACE;
    }

    AddRef();
    return S_OK;
}


STDMETHODIMP
SampleProviderMediaSource::CreatePresentationDescriptor(IMFPresentationDescriptor** ppPresentationDescriptor)
{
    std::scoped_lock lock(mInstanceMutex);

    if (isShutDown())
    {
        return MF_E_SHUTDOWN;
    }

    if (mPresentationDescriptor == nullptr)
    {
        return E_FAIL;
    }

    return mPresentationDescriptor->Clone(ppPresentationDescriptor);
}


STDMETHODIMP
SampleProviderMediaSource::GetCharacteristics(DWORD* pdwCharacteristics)
{
    std::scoped_lock lock(mInstanceMutex);
    if (isShutDown())
    {
        return MF_E_SHUTDOWN;
    }

    *pdwCharacteristics = MFMEDIASOURCE_DOES_NOT_USE_NETWORK;
    return S_OK;
}


STDMETHODIMP
SampleProviderMediaSource::Pause()
{
    std::scoped_lock lock(mInstanceMutex);
    if (isShutDown())
    {
        return MF_E_SHUTDOWN;
    }

    // Pause is not supported
    return MF_E_INVALID_STATE_TRANSITION;
}


STDMETHODIMP
SampleProviderMediaSource::Start(IMFPresentationDescriptor* /*pPresentationDescriptor*/, const GUID* pguidTimeFormat,
                                 const PROPVARIANT* pvarStartPosition)
{
    std::scoped_lock lock(mInstanceMutex);
    if (isShutDown())
    {
        return MF_E_SHUTDOWN;
    }

    if (*pguidTimeFormat != GUID_NULL)
    {
        return MF_E_UNSUPPORTED_TIME_FORMAT;
    }

    if (mStream == nullptr)
    {
        return E_FAIL;
    }

    HRESULT hr = QueueEventWithIUnknownArg(MENewStream, GUID_NULL, S_OK, mStream);
    if (FAILED(hr))
    {
        return hr;
    }

    hr = QueueEvent(MESourceStarted, GUID_NULL, S_OK, pvarStartPosition);
    if (FAILED(hr))
    {
        return hr;
    }

    hr = mStream->QueueEvent(MEStreamStarted, GUID_NULL, S_OK, pvarStartPosition);
    if (FAILED(hr))
    {
        return hr;
    }

    mIsStarted = true;
    return S_OK;
}


STDMETHODIMP
SampleProviderMediaSource::Stop()
{
    std::scoped_lock lock(mInstanceMutex);
    if (isShutDown())
    {
        return MF_E_SHUTDOWN;
    }

    HRESULT hr = QueueEvent(MESourceStopped, GUID_NULL, S_OK, nullptr);
    if (FAILED(hr))
    {
        return hr;
    }

    if (mStream != nullptr)
    {
        hr = mStream->QueueEvent(MEStreamStopped, GUID_NULL, S_OK, nullptr);
        if (FAILED(hr))
        {
            return hr;
        }
    }

    mIsStarted = false;

    return S_OK;
}


STDMETHODIMP
SampleProviderMediaSource::Shutdown()
{
    std::scoped_lock lock(mInstanceMutex);
    if (isShutDown())
    {
        return MF_E_SHUTDOWN;
    }

    mIsStarted = false;

    shutdownEventQueue();

    if (mStream != nullptr)
    {
        mStream->shutdownEventQueue();
    }

    return S_OK;
}


SampleProviderStreamSource*
SampleProviderMediaSource::getStreamSource()
{
    std::scoped_lock lock(mInstanceMutex);
    return mStream;
}


HRESULT
SampleProviderMediaSource::initializeStream(size_t maxSampleQueueSize)
{
    ScopedComPtr<IMFStreamDescriptor> streamDescriptor;
    HRESULT hr = MFCreateStreamDescriptor(STREAM_ID, 1, &mInputFormat.get(), &streamDescriptor.get());
    if (FAILED(hr))
    {
        return hr;
    }

    ScopedComPtr<IMFMediaTypeHandler> typeHandler;
    hr = streamDescriptor->GetMediaTypeHandler(&typeHandler.get());
    if (FAILED(hr))
    {
        return hr;
    }

    hr = typeHandler->SetCurrentMediaType(mInputFormat);
    if (FAILED(hr))
    {
        return hr;
    }

    hr = MFCreatePresentationDescriptor(1, &streamDescriptor.get(), &mPresentationDescriptor.get());
    if (FAILED(hr))
    {
        return hr;
    }

    hr = mPresentationDescriptor->SelectStream(0); // index, not stream ID
    if (FAILED(hr))
    {
        return hr;
    }

    mStream = new SampleProviderStreamSource(this, streamDescriptor, maxSampleQueueSize);
    return S_OK;
}
