/*===============================================================================
Copyright (c) 2021 PTC Inc., Its Subsidiary Companies, and /or its Partners.
All Rights Reserved.

Confidential and Proprietary - Protected under copyright and other laws.
Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

#include "Platform/Windows/WindowsVideoDecoder.h"
#include "Platform/Platform.h"

#include "Platform/Windows/SampleProviderMediaSource.h"
#include "Platform/Windows/SampleProviderStreamSource.h"
#include "Platform/Windows/SourceReaderCallback.h"

#include <cassert>
#include <roapi.h>

using namespace Platform::Windows;

// Media Foundation seems to process samples in batches.
// The input queue needs to be big enough to ensure that the decoder
// always has data available to continue decoding.
// (the minimum size seems to be around 10)
constexpr size_t SAMPLE_QUEUE_SIZE = 32;


std::unique_ptr<Platform::VideoDecoder>
Platform::VideoDecoder::create(VideoCodec codecType, VuforiaDriver::PlatformData* /*platformData*/)
{
    switch (codecType)
    {
        case VideoCodec::H264_AVCC:
            return std::make_unique<WindowsVideoDecoder>();
        default:
            // Invalid type
            assert(false);
            return nullptr;
    }
}


WindowsVideoDecoder::~WindowsVideoDecoder()
{
    reset();
}


std::optional<VuforiaDriver::PixelFormat>
WindowsVideoDecoder::start(uint16_t width, uint16_t height, const VideoCodecConfigurationData& codecConfigurationData,
                           OutputCallback outputCallback)
{
    if (mSourceReader != nullptr)
    {
        Platform::log("Decoder already started");
        return {};
    }

    if (codecConfigurationData.find(VideoCodecConfigurationDataType::H264_SPS) == codecConfigurationData.end() ||
        codecConfigurationData.find(VideoCodecConfigurationDataType::H264_PPS) == codecConfigurationData.end())
    {
        Platform::log("Missing required codec configuration data");
        return {};
    }

    if (!isSupportedResolution(width, height))
    {
        Platform::log("Unsupported resolution for decoding");
        return {};
    }

    auto callback = [&](HRESULT hrStatus, IMFSample* pSample, LONGLONG llTimestamp, DWORD dwStreamFlags) {
        onFrameDecoded(hrStatus, pSample, llTimestamp, dwStreamFlags);
    };

    mSourceCallback = new SourceReaderCallback(callback);

    bool ok = true;
    ScopedComPtr<IMFAttributes> attributes;
    ok = ok && SUCCEEDED(MFCreateAttributes(&attributes.get(), 3));
    ok = ok && SUCCEEDED(attributes->SetUINT32(MF_READWRITE_ENABLE_HARDWARE_TRANSFORMS, TRUE));
    ok = ok && SUCCEEDED(attributes->SetUINT32(MF_LOW_LATENCY, TRUE));
    ok = ok && SUCCEEDED(attributes->SetUnknown(MF_SOURCE_READER_ASYNC_CALLBACK, mSourceCallback));
    if (!ok)
    {
        Platform::log("Failed to prepare decoder attributes.");
        return {};
    }

    ScopedComPtr<IMFMediaType> outputType;
    ok = ok && SUCCEEDED(MFCreateMediaType(&outputType.get()));
    ok = ok && SUCCEEDED(outputType->SetGUID(MF_MT_MAJOR_TYPE, MFMediaType_Video));
    ok = ok && SUCCEEDED(outputType->SetGUID(MF_MT_SUBTYPE, MFVideoFormat_NV12));

    if (!ok)
    {
        Platform::log("Failed to prepare output media type.");
        return {};
    }

    // Setup a buffer containing SPS and PPS. These need to be submitted with every I-Frame
    auto configData = convertCodecConfigDataToAnnexB(codecConfigurationData);
    uint8_t* sequenceHeader = nullptr;

    ok = ok && SUCCEEDED(MFCreateMemoryBuffer(static_cast<DWORD>(configData.size()), &mSequenceHeaderBuffer.get()));
    ok = ok && SUCCEEDED(mSequenceHeaderBuffer->Lock(&sequenceHeader, nullptr, nullptr));

    if (!ok)
    {
        Platform::log("Failed to create sequence header buffer.");
        return {};
    }

    memcpy(sequenceHeader, configData.data(), configData.size());

    mSequenceHeaderBuffer->Unlock();
    mSequenceHeaderBuffer->SetCurrentLength(static_cast<DWORD>(configData.size()));

    ScopedComPtr<IMFMediaType> inputType;
    ok = ok && SUCCEEDED(MFCreateMediaType(&inputType.get()));
    ok = ok && SUCCEEDED(inputType->SetGUID(MF_MT_MAJOR_TYPE, MFMediaType_Video));
    ok = ok && SUCCEEDED(inputType->SetGUID(MF_MT_SUBTYPE, MFVideoFormat_H264));
    ok = ok && SUCCEEDED(MFSetAttributeSize(inputType, MF_MT_FRAME_SIZE, width, height));
    if (!ok)
    {
        Platform::log("Failed to prepare output media type.");
        return {};
    }

    mSource = new SampleProviderMediaSource(inputType, SAMPLE_QUEUE_SIZE);
    mStreamSource = mSource->getStreamSource();

    ScopedComPtr<IMFMediaSource> sourceInterface;
    HRESULT hr = mSource->QueryInterface(IID_PPV_ARGS(&sourceInterface.get()));
    assert(SUCCEEDED(hr));

    hr = MFCreateSourceReaderFromMediaSource(sourceInterface, attributes, &mSourceReader.get());
    if (FAILED(hr))
    {
        Platform::log("Failed to create media source reader.");
        return {};
    }

    hr = mSourceReader->SetCurrentMediaType(SampleProviderMediaSource::STREAM_ID, nullptr, outputType);
    if (FAILED(hr))
    {
        Platform::log("Failed to configure output image format on source reader.");
        return {};
    }

    // Get output type to retrieve image stride
    ScopedComPtr<IMFMediaType> finalOutputType;
    hr = mSourceReader->GetCurrentMediaType(SampleProviderMediaSource::STREAM_ID, &finalOutputType.get());
    if (FAILED(hr))
    {
        Platform::log("Failed to get output image format from source reader.");
        return {};
    }

    // MSDN: "The attribute value is stored as a UINT32, but should be cast to a 32-bit
    //        signed integer value. Stride can be negative."
    int32_t stride = 0;
    hr = finalOutputType->GetUINT32(MF_MT_DEFAULT_STRIDE, reinterpret_cast<uint32_t*>(&stride));
    if (SUCCEEDED(hr) && stride > 0)
    {
        mOutputStride = stride;
    }
    else
    {
        mOutputStride = width;
    }

    // Trigger an asynchronous request for a decoded frame. It will be fulfilled when the first sample is submitted for decoding
    hr = mSourceReader->ReadSample(SampleProviderMediaSource::STREAM_ID, 0, nullptr, nullptr, nullptr, nullptr);
    if (FAILED(hr))
    {
        Platform::log("Failed to trigger decoding of sample.");
        return {};
    }

    mOutputWidth = width;
    mOutputHeight = height;
    mOutputCallback = outputCallback;
    mCodecConfigurationData = codecConfigurationData;
    return VuforiaDriver::PixelFormat::NV12;
}


bool
WindowsVideoDecoder::decodeSample(const std::vector<uint8_t>& sample, uint64_t presentationTimestampUs, bool endOfStream, int32_t timeoutUs)
{
    if (mSourceReader == nullptr)
    {
        Platform::log("Decoder not started");
        return false;
    }

    assert(mSource != nullptr);

    ScopedComPtr<IMFMediaBuffer> buffer;
    HRESULT hr = MFCreateMemoryBuffer(static_cast<DWORD>(sample.size()), &buffer.get());
    if (FAILED(hr))
    {
        Platform::log("Failed to create sample buffer.");
        return false;
    }

    uint8_t* data = nullptr;
    hr = buffer->Lock(&data, nullptr, nullptr);
    if (FAILED(hr))
    {
        Platform::log("Failed to lock sample buffer.");
        return false;
    }

    memcpy(data, sample.data(), sample.size());

    bool sampleContainsIFrame = containsIFrame(data, sample.size());

    if (!convertAvccToAnnexB(data, sample.size()))
    {
        Platform::log("Failed to convert the sample to Annex B.");
        buffer->Unlock();
        return false;
    }

    buffer->Unlock();

    bool ok = true;
    ok = ok && SUCCEEDED(buffer->SetCurrentLength(static_cast<DWORD>(sample.size())));

    ScopedComPtr<IMFSample> mediaSample;
    ok = ok && SUCCEEDED(MFCreateSample(&mediaSample.get()));
    if (sampleContainsIFrame)
    {
        ok = ok && SUCCEEDED(mediaSample->AddBuffer(mSequenceHeaderBuffer));
    }
    ok = ok && SUCCEEDED(mediaSample->AddBuffer(buffer));
    ok = ok && SUCCEEDED(mediaSample->SetSampleTime(presentationTimestampUs * 10));
    ok = ok && SUCCEEDED(mediaSample->SetSampleDuration(0));
    if (!ok)
    {
        Platform::log("Failed to create sample.");
        return false;
    }

    if (!mStreamSource->enqueueSample(mediaSample, timeoutUs))
    {
        Platform::log("Timeout reached while enqueueing sample for decoding.");
        return false;
    }

    mFramesInQueue++;

    if (endOfStream)
    {
        mStreamSource->notifyEndOfStream();
    }

    // Trigger asynchronous processing of the sample
    hr = mSourceReader->ReadSample(SampleProviderMediaSource::STREAM_ID, 0, nullptr, nullptr, nullptr, nullptr);
    if (FAILED(hr))
    {
        Platform::log("Failed to trigger decoding of sample.");
        return false;
    }

    return true;
}


bool
WindowsVideoDecoder::canAcceptNewSample()
{
    if (mSourceReader == nullptr)
    {
        return false;
    }
    assert(mStreamSource != nullptr);
    return mFramesInQueue < SAMPLE_QUEUE_SIZE && mStreamSource->canEnqueueWithoutWait();
}


void
WindowsVideoDecoder::stop()
{
    if (mSourceReader == nullptr)
    {
        return;
    }

    mStreamSource->waitForEmptySampleQueue();
    mStreamSource->notifyEndOfStream();

    HRESULT hr = mSourceReader->ReadSample(SampleProviderMediaSource::STREAM_ID, MF_SOURCE_READER_CONTROLF_DRAIN, nullptr, nullptr, nullptr,
                                           nullptr);
    if (SUCCEEDED(hr))
    {
        std::unique_lock lock(mReaderFinishedDrainingMtx);
        mReaderFinishedDrainingCv.wait(lock, [&]() { return mReaderFinishedDraining; });
    }
    else
    {
        Platform::log("Failed to drain source reader.");
    }

    reset();
}


void
WindowsVideoDecoder::onFrameDecoded(HRESULT hrStatus, IMFSample* pSample, LONGLONG llTimestamp, DWORD /*dwStreamFlags*/)
{
    if (FAILED(hrStatus))
    {
        Platform::log("Failed to decode sample");
        return;
    }

    if (pSample == nullptr)
    {
        // When MF_SOURCE_READER_CONTROLF_DRAIN is submitted during stop(),
        // onFrameDecoded() will receive a NULL sample when all frames finished decoding.
        // At this point stop() is notified we are finished.
        std::scoped_lock lock(mReaderFinishedDrainingMtx);
        mReaderFinishedDraining = true;
        mReaderFinishedDrainingCv.notify_all();
        return;
    }

    if (mDiscardDecodedFrames == true)
    {
        mFramesInQueue--;
        return;
    }

    ScopedComPtr<IMFMediaBuffer> buffer;
    HRESULT hr = pSample->GetBufferByIndex(0, &buffer.get());
    if (FAILED(hr))
    {
        Platform::log("Failed to get decoded frame buffer");
        mFramesInQueue--;
        return;
    }

    BYTE* data = nullptr;
    DWORD dataSize = 0;
    hr = buffer->Lock(&data, nullptr, &dataSize);
    if (FAILED(hr))
    {
        Platform::log("Failed to lock decoded frame buffer");
        mFramesInQueue--;
        return;
    }

    auto verticalStride = guessVerticalStride(mOutputWidth, mOutputHeight, dataSize);
    dataSize = static_cast<DWORD>(
        trimVerticalStride(data, dataSize, mOutputWidth, verticalStride, mOutputHeight, VuforiaDriver::PixelFormat::NV12));

    if (dataSize > 0)
    {
        mOutputCallback(data, dataSize, mOutputWidth, llTimestamp / 10);
    }
    else
    {
        Platform::log("Failed to remove vertical stride from decoded frame");
    }
    buffer->Unlock();
    mFramesInQueue--;
}


bool
WindowsVideoDecoder::flush()
{
    if (mSourceReader == nullptr)
    {
        return false;
    }

    // TODO FOCUSSDK-73606: The proper solution here would
    // be to use IMFSourceReader::Flush() to clean the decoder pipeline
    // as doing a full stop and restart incurs quite a bit more overhead.
    //
    // However, when IMFSourceReader::Flush() is used the decoder stops working
    // randomly on UWP devices that use a hardware decoder.
    //
    // For now a full restart is done here to work around this.
    mDiscardDecodedFrames = true;
    stop();
    mDiscardDecodedFrames = false;
    return start(static_cast<uint16_t>(mOutputWidth), static_cast<uint16_t>(mOutputHeight), mCodecConfigurationData, mOutputCallback)
        .has_value();
}


void
WindowsVideoDecoder::reset()
{
    if (mSourceReader == nullptr)
    {
        return;
    }

    mSourceReader.release();

    mSourceCallback.release();
    mStreamSource.release();

    mSource->Shutdown();
    mSource.release();

    mSequenceHeaderBuffer.release();
    mReaderFinishedDraining = false;

    mFramesInQueue = 0;
}
