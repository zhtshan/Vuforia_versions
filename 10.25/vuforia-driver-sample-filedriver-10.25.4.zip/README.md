# FileDriver

Implements a Vuforia Driver compatible library for playing back recordings made with the Vuforia Session Recorder.

## Prerequisites
* A working development environment for your chosen platform. Depending on your preferred platform you will need:

|Platform|Tools|
|-|-|
|Android|Android NDK version r26+ and Android SDK Build Tools 30.0.3+|
|iOS|Xcode 15.0.1 or later|
|UWP|Visual Studio 2022 (17.8+) with the Universal Windows Platform workload and C++/WinRT Extension installed|

* Python 3.10+
* CMake 3.9+

## Building
1. Extract the File Driver package and the Vuforia SDK package.
2. Run the appropriate build command:

    Note: The `-vh`  or `-vf` command line options may be omitted if the driver is put in the SDK's samples directory
    (such that the directory is a sub-directory of "samples", that is: samples/FileDriver).

    * **Android**
        ```
        python build.py android -vh [path to Vuforia SDK]/build/include
        ```
    * **UWP**
        ```
        python build.py uwp -vh [path to Vuforia SDK]/build/include
        ```
    * **IOS**
        ```
        python build.py ios -vf [path to Vuforia SDK]/build
        ```
        Set the `-vf` option to the folder containing the VuforiaEngine.framework

3. Output files should be placed in the `build/bin` directory by default: 
    * `Android/Release/[architecture]/libFileDriver.so` for Android
    * `WindowsStore/Release/[architecture]/FileDriver.dll` for UWP
    * `Release-iphoneos/FileDriver.framework` for iOS


## Recording format

### MP4 format
The MP4 recording format combines all required data into one MP4 file with multiple tracks. The camera images are
stored as H.264 encoded video.

# Usage
## Android
1. Add `libFileDriver.so` for each required architecture from `build/bin` to your Android app project by modifying either Android.mk or CMakeLists.txt or build.gradle. Select the option that best fits your project (please note that you need to substitute `[path-in-your-filesystem]` with the correct path on your machine):

    * **Using Android.mk**:

        Add libFileDriver-prebuilt definition to your Android.mk:
        ```
        include $(CLEAR_VARS)
        LOCAL_MODULE := libFileDriver-prebuilt
        LOCAL_SRC_FILES = [path-in-your-filesystem]/FileDriver/build/bin/Android/$(TARGET_ARCH_ABI)/libFileDriver.so
        include $(PREBUILT_SHARED_LIBRARY)
        ```
        When defining your local module in the same Android.mk add libFileDriver-prebuilt as a dependency to your  `LOCAL_SHARED_LIBRARIES`:
        ```
        LOCAL_SHARED_LIBRARIES := Vuforia-prebuilt libFileDriver-prebuilt
        ```

    * **Using CMakeLists.txt**

        Add `libFileDriver` prebuilt definition to your `CMakeLists.txt` file:
        ```
        add_library(VUFORIA_FILEDRIVER_LIBRARY SHARED IMPORTED)
        set_property(TARGET VUFORIA_FILEDRIVER_LIBRARY PROPERTY IMPORTED_LOCATION
        [path-in-your-filesystem]/FileDriver/build/bin/Android/Release/${ANDROID_ABI}/libFileDriver.so)
        ```

        When linking libraries in CMake, link `libFileDriver` library in the same `CMakeLists.txt`:
        ```
        target_link_libraries(
            VuforiaSample
            ${ANDROID_LIBRARY}
            ${LOG_LIBRARY}
            ${GLES3_LIBRARY}
            VUFORIA_LIBRARY
            VUFORIA_FILEDRIVER_LIBRARY
        )
        ```

    * **Using Gradle**

        **NOTE:** Only required if you are using Android Plugin version 3.x and below.

        If using either `Android.mk` or `CMakeLists.txt` you will also need to update your `build.gradle` to include the library in the APK. Use the following code in your `app/build.gradle`:
        ```
        android {
            sourceSets.main {
                jniLibs.srcDirs += '[path-in-your-filesystem]/FileDriver/build/bin/Android/'
            }
        }
        ```

2. Add the sample recording from the `data` directory into your Android-app project. 

    Use the following code in your `app/build.gradle`:
    ```
    android {
        sourceSets.main {
            assets.srcDirs += '[path-in-your-filesystem]/FileDriver/data/stones'
        }
    }
    ```

3. Add your configuration for the driver before creating a new Engine instance with `vuEngineCreate()`:

    ```
    VuDriverConfig driverConfig = vuDriverConfigDefault();
    driverConfig.driverName = "libFileDriver.so";
    driverConfig.userData = nullptr;
    vuEngineConfigSetAddDriverConfig(configSet, &driverConfig);
    ```

## UWP
1. Add `FileDriver.dll` from `build/bin/uwp` into your Visual Studio UWP-app project.
    * Import the `FileDriver.dll` to the root of your project. Remember to use a dll that matches your architecture (x64/ARM64) and build type (Debug/Release) configurations.
    * Click `FileDriver.dll` from the project file list and set property **Content** to **True**.

2. Add a sample sequence from the data directory into your Visual Studio UWP app project. For example, to use the “stones” sequence:
    * Import `FileDriver/data/stones/FileDriverRecording.mp4` into your project.
    * Select the file and set the property **Content** to **True**.

3. Add the following call before calling vuEngineCreate();
   
    ```
    VuDriverConfig driverConfig = vuDriverConfigDefault();
    driverConfig.driverName = "FileDriver.dll";
    driverConfig.userData = nullptr;
    vuEngineConfigSetAddDriverConfig(configSet, &driverConfig);
    ```

## iOS
1. In your Xcode project, open the build target settings and select the **Build Phases** tab.
2. In **Embedded Frameworks**, click the **+** icon, and on the subsequent pop-up window click **Add Other...** to add a new item.
3. From the file selection menu, select your built iOS File Driver Framework found in `bin/Release-iphoneos/FileDriver.framework`
4. In the new pop-up window, leave the options at their default values, and click **Finish**.
5. Copy the **FileDriverRecording.mp4** file from `Data/Stones` folder by dragging the file into the Assets folder.
6. In the pop-up window, select your project target in the **Add to targets** menu.
7. Configure your App code to use the driver by adding the following code before calling `vuEngineCreate()`:
   
    ```
    VuDriverConfig driverConfig = vuDriverConfigDefault();
    driverConfig.driverName = "FileDriver.framework";
    driverConfig.userData = nullptr;
    vuEngineConfigSetAddDriverConfig(configSet, &driverConfig);
    ```

# Playback Controls
FileDriver exposes a playback control API that can be used to configure its playback behavior.

Supported controls:
* Playback start time
* Playback end time
* Looping playback
* Changing playback mode

For details, see [FileDriverPlaybackController.h](include/FileDriverPlaybackController.h)

## Usage
After successfully creating the engine with FileDriver, a native platform handle to the loaded library can be retrieved by using `vuPlatformControllerGetDriverLibraryHandle()`.
This handle can be used to load the FileDriver playback controller functions using the native symbol loading mechanism of the current platform (`GetProcAddress()` on Windows/UWP, `dlsym()` on POSIX systems)
The retrieved function pointers can then be used to configure playback at any time until the engine is destroyed and thus the library unloaded. Note that some playback control functions require that the engine is stopped and restarted to apply the change.

# Copyright

```
Copyright (c) 2024 PTC Inc. and/or Its Subsidiary Companies.
All Rights Reserved.

Copyright for PTC software products is with PTC Inc. and its subsidiary
companies (collectively "PTC"), and their respective licensors. This software
is provided under written license or other agreement, contains valuable trade
secrets and proprietary information, and is protected by the copyright laws of
the United States and other countries. It may not be copied or distributed in
any form or medium, disclosed to third parties, or used in any manner not
provided for in the applicable agreement except with written prior approval
from PTC. More information regarding third party copyrights and trademarks and
a list of PTC's registered copyrights, trademarks, and patents can be viewed
here: www.ptc.com/support/go/copyright-and-trademarks 
```
