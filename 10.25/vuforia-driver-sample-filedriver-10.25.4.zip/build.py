# ==============================================================================
# Copyright (c) 2023 PTC Inc. and/or Its Subsidiary Companies.
# All Rights Reserved.
#
# Confidential and Proprietary - Protected under copyright and other laws.
# Vuforia is a trademark of PTC Inc., registered in the United States and other
# countries.
# ==============================================================================
import argparse
import os
import sys
import shutil
import subprocess
import pathlib
import configparser
from distutils.spawn import find_executable

CURRENT_DIR = os.path.abspath(pathlib.Path(__file__).parent.absolute())

PLATFORM_ANDROID = "android"
PLATFORM_UWP = "uwp"
PLATFORM_IOS = "ios"
PLATFORM_IOS_SIMULATOR = "iossimulator"
PLATFORM_MACOS = "macos"
PLATFORM_WINDOWS = "windows"

VALID_ARCHS = {
    PLATFORM_ANDROID: ["armeabi-v7a", "arm64-v8a"],
    PLATFORM_UWP: ["x64", "ARM64"],
    PLATFORM_IOS: ["arm64"],
    PLATFORM_IOS_SIMULATOR: ["universal"],
    PLATFORM_MACOS: ["universal"],
    PLATFORM_WINDOWS: ["x64"],
}


def parse_args():
    """argument parser method

    Returns
    -------
    parser.parse_args
        the parsed arguments
    """

    parser = argparse.ArgumentParser()

    parser.add_argument(
        "platform",
        help="Platform: {0}, {1}, {2}, {3}, {4} or {5}".format(
            PLATFORM_ANDROID,
            PLATFORM_UWP,
            PLATFORM_IOS,
            PLATFORM_IOS_SIMULATOR,
            PLATFORM_MACOS,
            PLATFORM_WINDOWS,
        ),
        choices=[
            PLATFORM_ANDROID,
            PLATFORM_UWP,
            PLATFORM_IOS,
            PLATFORM_IOS_SIMULATOR,
            PLATFORM_MACOS,
            PLATFORM_WINDOWS,
        ],
    )

    parser.add_argument(
        "-a",
        "--arch",
        help="Architectures. Space separated list values. Values for Android: armeabi-v7a, arm64-v8a."
        " Values for UWP: x64, ARM64. Values for iOS: arm64. Values for iOS Simulator and MacOS: universal."
        " Values for windows: x64",
        nargs="+",
    )

    parser.add_argument("-i", "--install", help="Install directory.", default=os.path.join("build"))

    parser.add_argument(
        "-o",
        "--output",
        help="Location of generated build files.",
        default=os.path.join("build"),
    )

    parser.add_argument(
        "-bt",
        "--build-type",
        help="Build type. Release or Debug",
        choices=["Release", "Debug", "RelWithDebInfo", "MinSizeRel"],
        default="Release",
    )

    parser.add_argument(
        "-vh",
        "--vuforia-header-dir",
        help="Directory that contains VuforiaEngine/Driver/Driver.h.",
        default=None,
    )

    parser.add_argument(
        "-vf",
        "--vuforia-framework-dir",
        help="Directory that contains Vuforia.framework (iOS only).",
        default=os.path.join("..", "..", "build", "lib", "arm64"),
    )

    parser.add_argument(
        "-c",
        "--clean",
        help="Delete all generated and built outputs and exit.",
        action="store_true",
    )

    parser.add_argument(
        "--cmake",
        help="The cmake executable to use for the build.",
        default=find_executable("cmake"),
    )

    args = parser.parse_args()

    return args


def build_file_driver(
    platform,
    architectures,
    build_type,
    output_dir,
    install_dir,
    vuforia_header_dir,
    vuforia_framework_dir,
    clean,
    cmake_executable_path,
):
    """Method for building the file driver

    Parameters
    ----------
    platform : str
        platform name
    architecture : list
        list of the architectures
    build_type : str
        build type. Release or Debug
    output_dir : str
        path of the output directory
    install_dir : str
        path of the install directory
    vuforia_header_dir : str
        path which contains the vuforia headers
    vuforia_framework_dir : [type]
        path which contains the vuforia framework
    clean : bool
        cleans up the output directory before the build
    cmake_executable_path : str
        path to the the cmake executable
    """

    if architectures is None:
        architectures = VALID_ARCHS[platform]
        print("No architectures selected. using defaults: {0}".format(str(architectures)))

    for arch in architectures:
        if arch not in VALID_ARCHS[platform]:
            print("error: Invalid architecture: {0}".format(arch))
            exit(1)

    cwd = CURRENT_DIR
    output_rootdir = os.path.abspath(output_dir)
    install_rootdir = os.path.abspath(install_dir)
    build_type = build_type
    toolchain_dir = os.path.join(cwd, "cmake")

    # For iOS, use the framework path unless the header path was explicitly specified.
    # For other platforms, use the header path.
    if platform == PLATFORM_IOS or platform == PLATFORM_IOS_SIMULATOR:
        if vuforia_header_dir:
            vuforia_header_dir = os.path.abspath(vuforia_header_dir)
            vuforia_framework_dir = None
        else:
            vuforia_header_dir = None
            vuforia_framework_dir = os.path.abspath(vuforia_framework_dir)
    else:
        vuforia_framework_dir = None
        # Construct the default header dir if it was unspecified
        if vuforia_header_dir:
            vuforia_header_dir = os.path.abspath(vuforia_header_dir)
        else:
            vuforia_header_dir = os.path.abspath(os.path.join(os.pardir, os.pardir, "build", "include"))

    # If we're on windows fix up paths to remove backslashes that break cmake install
    if os.name == "nt":
        install_rootdir = install_rootdir.replace("\\", "/")
        vuforia_header_dir = vuforia_header_dir.replace("\\", "/")

    if clean:
        if os.path.exists(output_rootdir):
            print("Cleaning outputs...")
            output_bin_dir = os.path.join(output_rootdir, "bin")

            if platform == PLATFORM_ANDROID:
                shutil.rmtree(os.path.join(output_rootdir, "android"), ignore_errors=True)
                shutil.rmtree(os.path.join(output_bin_dir, "android"), ignore_errors=True)
            elif platform == PLATFORM_UWP:
                shutil.rmtree(os.path.join(output_rootdir, "uwp"), ignore_errors=True)
                shutil.rmtree(os.path.join(output_bin_dir, "WindowsStore"), ignore_errors=True)
            elif platform == PLATFORM_IOS:
                shutil.rmtree(os.path.join(output_rootdir, "ios"), ignore_errors=True)
                shutil.rmtree(os.path.join(output_bin_dir, "Debug-iphoneos"), ignore_errors=True)
                shutil.rmtree(os.path.join(output_bin_dir, "Release-iphoneos"), ignore_errors=True)
            elif platform == PLATFORM_IOS_SIMULATOR:
                shutil.rmtree(os.path.join(output_rootdir, "iossimulator"), ignore_errors=True)
                shutil.rmtree(os.path.join(output_bin_dir, "Debug-iphonesimulator"), ignore_errors=True)
                shutil.rmtree(os.path.join(output_bin_dir, "Release-iphonesimulator"), ignore_errors=True)
            elif platform == PLATFORM_MACOS:
                shutil.rmtree(os.path.join(output_rootdir, "macos"), ignore_errors=True)
                shutil.rmtree(os.path.join(output_bin_dir, "Darwin"), ignore_errors=True)
            elif platform == PLATFORM_WINDOWS:
                shutil.rmtree(os.path.join(output_rootdir, "windows"), ignore_errors=True)
                shutil.rmtree(os.path.join(output_bin_dir, "windows"), ignore_errors=True)
            # Remove bin directory if empty
            if os.path.isdir(output_bin_dir) and not os.listdir(output_bin_dir):
                os.rmdir(output_bin_dir)
            # Remove output directory if empty
            if os.path.isdir(output_rootdir) and not os.listdir(output_rootdir):
                os.rmdir(output_rootdir)
            print("done.")
        else:
            print("Already clean.")
        exit(0)

    if not os.path.exists(output_rootdir):
        os.makedirs(output_rootdir)

    # On iOS we need a full path for XCode generator.
    # If we have not found it (which can happen), then we just use the full path.
    # On Windows and Android we throw an error, if cmake is not installed.
    if (
        platform == PLATFORM_MACOS or platform == PLATFORM_IOS or platform == PLATFORM_IOS_SIMULATOR
    ) and not cmake_executable_path:
        cmake_executable_path = "/Applications/CMake.app/Contents/bin/cmake"
    if not cmake_executable_path:
        print(
            "error: Please install cmake and either make sure that it is set in the PATH"
            " or pass it via the --cmake command line flag"
        )
    else:
        print("Using cmake: {0}".format(cmake_executable_path))

    # Check that ninja is installed for Android build.
    if platform == PLATFORM_ANDROID:
        ninja_path = find_executable("ninja")
        if not ninja_path:
            print("error: Please install Ninja (https://ninja-build.org/) and make sure that it is set in the PATH")
        else:
            print("Using ninja: {0}".format(ninja_path))

    for arch in architectures:
        print("Generating arch: {0}".format(arch))

        if platform == PLATFORM_ANDROID:
            toolchain_file = os.path.join(toolchain_dir, "android.toolchain.{0}.cmake".format(arch))
            generator = "Ninja"
            generator_platform = None
        elif platform == PLATFORM_UWP:
            toolchain_file = os.path.join(toolchain_dir, "uwp.toolchain.{0}.cmake".format(arch))
            if arch == "x64":
                generator = "Visual Studio 17 2022"
                generator_platform = "x64"
            elif arch == "ARM64":
                generator = "Visual Studio 17 2022"
                generator_platform = "ARM64"
        elif platform == PLATFORM_WINDOWS:
            toolchain_file = os.path.join(toolchain_dir, "windows.toolchain.{0}.cmake".format(arch))
            if arch == "x64":
                generator = "Visual Studio 17 2022"
                generator_platform = "x64"
        elif platform == PLATFORM_IOS:
            toolchain_file = os.path.join(toolchain_dir, "ios.toolchain.{0}.cmake".format(arch))
            generator = "Xcode"
            generator_platform = None
        elif platform == PLATFORM_IOS_SIMULATOR:
            toolchain_file = os.path.join(toolchain_dir, "ios.toolchain.{0}.iphonesimulator.cmake".format(arch))
            generator = "Xcode"
            generator_platform = None
        elif platform == PLATFORM_MACOS:
            toolchain_file = os.path.join(toolchain_dir, "macos.toolchain.{0}.cmake".format(arch))
            generator = "Xcode"
            generator_platform = None

        output_dir = os.path.join(output_rootdir, platform, arch)
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)

        # In case this script is being invoked as a build step in an Xcode project, we need to
        # clear out some inherited environment variables that confuse cmake
        if generator == "Xcode":
            for _key, _value in os.environ.items():
                if "SEARCH_PATH" in _key:
                    del os.environ[_key]

        cmake_command = [cmake_executable_path]
        cmake_command.extend(["-G", generator])
        if generator_platform:
            cmake_command.append("-A")
            cmake_command.append(generator_platform)
        if vuforia_header_dir:
            cmake_command.extend(["-DVUFORIA_HEADER_DIR='{0}'".format(vuforia_header_dir)])
        elif vuforia_framework_dir:
            cmake_command.extend(["-DVUFORIA_FRAMEWORK_DIR='{0}'".format(vuforia_framework_dir)])
        cmake_command.extend(
            [
                "-DCMAKE_INSTALL_PREFIX='{0}'".format(install_rootdir),
                "-DCMAKE_TOOLCHAIN_FILE='{0}'".format(toolchain_file),
                "-DCMAKE_BUILD_TYPE={0}".format(build_type),
                cwd,
            ]
        )

        ret = subprocess.call(cmake_command, cwd=output_dir)

        if ret != 0:
            print("error: Project generation with cmake failed.")
            sys.exit(1)

        print("Building arch: {0}".format(arch))

        ret = subprocess.call(
            [cmake_executable_path, "--build", ".", "--target", "install", "--config", build_type],
            cwd=output_dir,
        )

        if ret != 0:
            print("error: Project generation with cmake failed.")
            sys.exit(1)

    print("Project generation and compilation succeeeded.")


def setup_environment(platform):
    """Optionally, a configuration file named environment.ini may be present to configure
    environment variables needed by the build.
    Example content:

    [ios]
    VARNAME1=VALUE1
    [macos]
    VARNAME1=VALUE2
    VARNAME2=VALUE3
    """
    env_file = os.path.join(CURRENT_DIR, "environment.ini")
    if os.path.exists(env_file):
        cfg = configparser.ConfigParser()
        cfg.optionxform = lambda option: option  # retain case of keys
        cfg.read(env_file)
        if cfg.has_section(platform):
            for key, value in cfg.items(platform):
                os.environ[key] = value
                print("Set environment variable '{0}' to '{1}".format(key, value))


def main():
    """The build.py file's main method"""

    parsed_args = parse_args()
    setup_environment(parsed_args.platform)

    build_file_driver(
        parsed_args.platform,
        parsed_args.arch,
        parsed_args.build_type,
        parsed_args.output,
        parsed_args.install,
        parsed_args.vuforia_header_dir,
        parsed_args.vuforia_framework_dir,
        parsed_args.clean,
        parsed_args.cmake,
    )


if __name__ == "__main__":
    main()
