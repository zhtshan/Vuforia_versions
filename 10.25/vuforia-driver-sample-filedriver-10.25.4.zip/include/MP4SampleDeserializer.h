/*===============================================================================
Copyright (c) 2021 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

#ifndef _MP4SAMPLEDESERIALIZER_H_
#define _MP4SAMPLEDESERIALIZER_H_

#include <VuforiaEngine/Driver/Driver.h>

#include <optional>
#include <vector>

namespace Platform
{

struct FrameMetadata
{
    int64_t mTimestamp{ 0 };
    int64_t mPresentationTimestamp{ 0 };
    int64_t mPublishTimestamp{ 0 };
    int64_t mExposureTime{ 0 };
    float mIsoValue{ 0.f };
    VuforiaDriver::CameraIntrinsics mIntrinsics;
};

/// Functions that deserialize recorded data from raw MP4 sample buffers
namespace MP4SampleDeserializer
{

/// Reads a camera intrinsics object from a byte buffer.
/**
 * \returns an empty optional if the provided buffer has an invalid size.
 */
std::optional<VuforiaDriver::CameraIntrinsics> readIntrinsics(const std::vector<uint8_t>& buffer);

/// Reads a frame metadata object from a byte buffer.
/**
 * \returns an empty optional if the provided buffer has an invalid size.
 */
std::optional<FrameMetadata> readFrameMetadata(const std::vector<uint8_t>& buffer);

/// Reads a device pose object from a byte buffer.
/**
 * \param buffer the byte buffer containing pose data
 * \param version the expected version of the device pose data in the buffer
 *
 * \returns an empty optional if the provided buffer is invalid.
 */
std::optional<VuforiaDriver::Pose> readDevicePose(const std::vector<uint8_t>& buffer, int version);

}

}

#endif // _MP4SAMPLEDESERIALIZER_H_
