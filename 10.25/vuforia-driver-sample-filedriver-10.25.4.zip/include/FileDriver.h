
/*===============================================================================
Copyright (c) 2021 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/
#ifndef _FILEDRIVER_H_
#define _FILEDRIVER_H_

#include "FileCamera.h"
#include "FileDriverPlaybackController.h"
#include "FileDriverUserData.h"
#include "FilePositionalDeviceTracker.h"
#include "Player.h"

#include <VuforiaEngine/Driver/Driver.h>

#include <memory>
#include <string>

/// FileDriver that implements the VuforiaDriver base class.
/**
 * This class is used for constructing and destroying the FileDriver specific data source objects.
 *
 * The documentation of the public methods can be found in VuforiaEngine/Driver/Driver.h header.
 */
class FileDriver final : public VuforiaDriver::Driver
{
public:
    FileDriver(VuforiaDriver::PlatformData* platformData, FileDriverUserData* userdata);
    virtual ~FileDriver();

    VuforiaDriver::ExternalCamera* VUFORIA_DRIVER_CALLING_CONVENTION createExternalCamera() override;

    void VUFORIA_DRIVER_CALLING_CONVENTION destroyExternalCamera(VuforiaDriver::ExternalCamera* instance) override;

    VuforiaDriver::ExternalPositionalDeviceTracker* VUFORIA_DRIVER_CALLING_CONVENTION createExternalPositionalDeviceTracker() override;

    void VUFORIA_DRIVER_CALLING_CONVENTION
    destroyExternalPositionalDeviceTracker(VuforiaDriver::ExternalPositionalDeviceTracker* instance) override;

    uint32_t VUFORIA_DRIVER_CALLING_CONVENTION getCapabilities() override;

    uint32_t VUFORIA_DRIVER_CALLING_CONVENTION getCameraOrientation(uint32_t deviceOrientationInDegrees) override;

    bool setPlaybackStartTime(uint64_t timestamp);

    bool setPlaybackEndTime(uint64_t timestamp);

    bool setPlaybackLoop(uint32_t loopCount);

    bool setPlaybackMode(FileDriverPlaybackMode mode);

    uint64_t getSequenceDuration();

    uint64_t getPlaybackPosition();

private:
    void initializePlayer(VuforiaDriver::PlatformData* platformData, FileDriverUserData* userData);

    std::unique_ptr<Player> mPlayer;
    std::unique_ptr<FileCamera> mExternalCamera;
    std::unique_ptr<FilePositionalDeviceTracker> mExternalPDT;
};

#endif // _FILEDRIVER_H_
