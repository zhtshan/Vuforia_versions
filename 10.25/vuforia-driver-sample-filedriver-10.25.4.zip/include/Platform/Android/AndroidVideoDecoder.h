/*===============================================================================
Copyright (c) 2021 PTC Inc., Its Subsidiary Companies, and /or its Partners.
All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

#ifndef __ANDROIDVIDEODECODER__
#define __ANDROIDVIDEODECODER__

#include "Platform/VideoDecoder.h"

#include <atomic>
#include <mutex>
#include <thread>

struct AMediaCodec;
struct AMediaCodecBufferInfo;
struct AMediaFormat;

namespace Platform
{

class AndroidVideoDecoder : public VideoDecoder
{
public:
    explicit AndroidVideoDecoder(VuforiaDriver::PlatformData* platformData);

    ~AndroidVideoDecoder();

    std::optional<VuforiaDriver::PixelFormat> start(uint16_t width, uint16_t height,
                                                    const VideoCodecConfigurationData& codecConfigurationData,
                                                    OutputCallback outputCallback) override;

    bool decodeSample(const std::vector<uint8_t>& sample, uint64_t presentationTimestampUs, bool endOfStream, int32_t timeoutUs) override;

    bool canAcceptNewSample() override;

    void stop() override;

    bool flush() override;

private:
    void reset();

    void consumeOutputBuffers();

    ssize_t getNextInputBuffer(int32_t timeoutUs);

    VuforiaDriver::PlatformData* mPlatformData{ nullptr };
    AMediaCodec* mCodec{ nullptr };

    int32_t mOutputWidth{};
    int32_t mOutputHeight{};
    VuforiaDriver::PixelFormat mNativeColorOutputFormat{ VuforiaDriver::PixelFormat::UNKNOWN };

    OutputCallback mOutputCallback;
    VideoCodecConfigurationData mCodecConfigurationData;

    std::atomic<bool> mRunWorkerThread;
    std::thread mOutputWorker;

    std::atomic<bool> mPendingFlush{ false };
    std::mutex mFlushMutex;
    std::condition_variable mFlushCv;
    bool mFlushResult{ false };

    ssize_t mNextInputBuffer{ -1 };
    bool mEndOfStreamWasSubmitted{ false };
};

} // namespace Platform

#endif // __ANDROIDVIDEODECODER__
