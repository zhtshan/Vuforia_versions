/*===============================================================================
Copyright (c) 2021 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/
#ifndef _PLATFORM_H_
#define _PLATFORM_H_

#include <VuforiaEngine/Driver/Driver.h>

#include <memory>
#include <optional>
#include <string>

/// Platform specific functionality.
namespace Platform
{

/// Output a log message.
/**
 * \param message message.
 */
void log(const std::string& message);

/// Resolves the provided path to a full, absolute path
/**
 * \param path a filesystem path, relative or absolute
 * \returns the resolved absolute path which corresponds to the input argument
 */
std::optional<std::string> normalizePath(const std::string& path);

/// Manages access to the platform specific asset manager
/**
 * \note Depending on the platform, this class will either provide
 * the path to the asset directory or an AssetManager instance.
 */
class AssetManager
{
public:
    struct AssetManagerImplData
    {
        virtual ~AssetManagerImplData() = default;
    };

    AssetManager(VuforiaDriver::PlatformData* platformData);
    ~AssetManager();

    /// Returns the default application asset storage location
    /**
     * \return the absolute path to the asset directory or an empty
     *         optional for platforms that don't implement this.
     */
    std::optional<std::string> getAssetDirectory();

    /// Returns a native asset manager instance.
    /**
     * \return the instance or nullptr for platforms that don't implement this.
     */
    void* getAssetManager();

private:
    VuforiaDriver::PlatformData* mPlatformData{ nullptr };
    std::unique_ptr<AssetManagerImplData> mImpl{ nullptr };
};


} // namespace Platform

#endif // _PLATFORM_H_
