/*===============================================================================
Copyright (c) 2021 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

#ifndef __SCOPED_COM_PTR__
#define __SCOPED_COM_PTR__

namespace Platform::Windows
{

/// RAII wrapper for COM pointers
/**
 * For COM APIs that require an Interface** as output argument, use this pattern:
 * ScopedComPtr<ISomeInterface> scopedPtr;
 * object->QueryInterface(IID_PPV_ARGS(&scopedPtr.get()));
 *
 * ScopedComPtr will not call AddRef for this direct assignment. COM APIs
 * that produce new interface pointers in this way will already call AddRef internally.
 *
 * However, when copying a raw COM pointer into the ScopedComPtr via constructor/assignment
 * the ScopedComPtr will call AddRef internally.
 */
template <class T>
class ScopedComPtr
{
public:
    ScopedComPtr(T* ptr = nullptr) : mPtr(ptr)
    {
        if (mPtr != nullptr)
        {
            mPtr->AddRef();
        }
    }

    ScopedComPtr(const ScopedComPtr& other)
    {
        if (other.mPtr != nullptr)
        {
            mPtr = other.mPtr;
            mPtr->AddRef();
        }
    }

    ScopedComPtr(ScopedComPtr&& other)
    {
        mPtr = other.mPtr;
        other.mPtr = nullptr;
    }

    ScopedComPtr& operator=(const ScopedComPtr& other)
    {
        if (this != &other)
        {
            release();
            mPtr = other.mPtr;
            if (mPtr != nullptr)
            {
                mPtr->AddRef();
            }
        }
        return *this;
    }

    ScopedComPtr& operator=(ScopedComPtr&& other)
    {
        if (this != &other)
        {
            release();
            mPtr = other.mPtr;
            other.mPtr = nullptr;
        }
        return *this;
    }

    ~ScopedComPtr() { release(); }

    void release()
    {
        if (mPtr != nullptr)
        {
            mPtr->Release();
            mPtr = nullptr;
        }
    }

    const T* const& get() const { return mPtr; }
    T*& get() { return mPtr; }

    const T* operator->() const { return mPtr; }
    T* operator->() { return mPtr; }

    const T& operator*() const { return *mPtr; }
    T& operator*() { return *mPtr; }

    operator const T*() const { return mPtr; }
    operator T*() { return mPtr; }

    explicit operator bool() const { return mPtr != nullptr; }

    friend bool operator==(const ScopedComPtr& a, const ScopedComPtr& b) { return a.mPtr == b.mPtr; }

    friend bool operator==(const ScopedComPtr& a, std::nullptr_t) { return a.mPtr == nullptr; }

private:
    T* mPtr{ nullptr };
};


} // namespace Platform::Windows

#endif // __SCOPED_COM_PTR__