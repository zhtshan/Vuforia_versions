/*===============================================================================
Copyright (c) 2021 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

#ifndef __WINDOWS_VIDEO_DECODER__
#define __WINDOWS_VIDEO_DECODER__

#include "Platform/VideoDecoder.h"

#include "Platform/Windows/MediaFoundationInitializer.h"
#include "ScopedComPtr.h"

#include <atomic>
#include <condition_variable>
#include <memory>
#include <mfapi.h>
#include <mfidl.h>
#include <mfreadwrite.h>
#include <mutex>


namespace Platform::Windows
{

class SampleProviderMediaSource;
class SampleProviderStreamSource;
class SourceReaderCallback;

class WindowsVideoDecoder : public VideoDecoder
{
public:
    ~WindowsVideoDecoder();

    std::optional<VuforiaDriver::PixelFormat> start(uint16_t width, uint16_t height,
                                                    const VideoCodecConfigurationData& codecConfigurationData,
                                                    OutputCallback outputCallback) override;

    bool decodeSample(const std::vector<uint8_t>& sample, uint64_t presentationTimestampUs, bool endOfStream, int32_t timeoutUs) override;

    bool canAcceptNewSample() override;

    void stop() override;

    bool flush() override;

private:
    void onFrameDecoded(HRESULT hrStatus, IMFSample* pSample, LONGLONG llTimestamp, DWORD dwStreamFlags);

    void reset();

    MediaFoundationInitializer mMediaFoundationInitializer;

    ScopedComPtr<IMFSourceReader> mSourceReader;
    ScopedComPtr<SampleProviderMediaSource> mSource;
    ScopedComPtr<SampleProviderStreamSource> mStreamSource;
    ScopedComPtr<SourceReaderCallback> mSourceCallback;
    ScopedComPtr<IMFMediaBuffer> mSequenceHeaderBuffer;

    int32_t mOutputWidth{};
    int32_t mOutputHeight{};
    uint32_t mOutputStride{ 0 };

    OutputCallback mOutputCallback;

    std::mutex mReaderFinishedDrainingMtx;
    std::condition_variable mReaderFinishedDrainingCv;
    bool mReaderFinishedDraining{ false };

    std::atomic<uint32_t> mFramesInQueue{ 0 };
    std::atomic<bool> mDiscardDecodedFrames{ false };
    VideoCodecConfigurationData mCodecConfigurationData{};
};

} // namespace Platform::Windows

#endif // __WINDOWS_VIDEO_DECODER__
