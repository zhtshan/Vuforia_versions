/*===============================================================================
Copyright (c) 2021 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

#ifndef __MEDIA_EVENT_GENERATOR__
#define __MEDIA_EVENT_GENERATOR__

#include "ScopedComPtr.h"

#include <atomic>
#include <cassert>
#include <mfapi.h>
#include <mferror.h>
#include <mutex>

namespace Platform::Windows
{

/// Provides a generic implementation of IMFMediaEventGenerator
/// for any interface that requires it.
template <typename T>
class MediaEventGenerator : public T
{
public:
    MediaEventGenerator()
    {
        HRESULT hr = MFCreateEventQueue(&mEventQueue.get());
        (void)hr; // to fix warning in release builds which is treated as error
        assert(SUCCEEDED(hr));
    }

    virtual ~MediaEventGenerator() = default;

    STDMETHODIMP
    BeginGetEvent(IMFAsyncCallback* pCallback, IUnknown* punkState) override
    {
        std::scoped_lock lock(mQueueMutex);

        if (mIsShutdown)
        {
            return MF_E_SHUTDOWN;
        }

        return mEventQueue->BeginGetEvent(pCallback, punkState);
    }

    STDMETHODIMP
    EndGetEvent(IMFAsyncResult* pResult, IMFMediaEvent** ppEvent) override
    {
        std::scoped_lock lock(mQueueMutex);

        if (mIsShutdown)
        {
            return MF_E_SHUTDOWN;
        }

        return mEventQueue->EndGetEvent(pResult, ppEvent);
    }

    STDMETHODIMP
    GetEvent(DWORD dwFlags, IMFMediaEvent** ppEvent) override
    {
        // NOTE: GetEvent can block indefinitely, so we don't hold the lock.
        // This requires some juggling with the event queue pointer.
        ScopedComPtr<IMFMediaEventQueue> pQueue;

        {
            std::scoped_lock lock(mQueueMutex);

            if (mIsShutdown)
            {
                return MF_E_SHUTDOWN;
            }

            // Get the pointer to the event queue.
            pQueue = mEventQueue;
        }

        // Now get the event.
        return mEventQueue->GetEvent(dwFlags, ppEvent);
    }

    STDMETHODIMP
    QueueEvent(MediaEventType met, REFGUID guidExtendedType, HRESULT hrStatus, const PROPVARIANT* pvValue) override
    {
        std::scoped_lock lock(mQueueMutex);

        if (mIsShutdown)
        {
            return MF_E_SHUTDOWN;
        }

        return mEventQueue->QueueEventParamVar(met, guidExtendedType, hrStatus, pvValue);
    }


    STDMETHODIMP
    QueueEventWithIUnknownArg(MediaEventType met, REFGUID guidExtendedType, HRESULT hrStatus, IUnknown* pUnk)
    {
        std::scoped_lock lock(mQueueMutex);

        if (mIsShutdown)
        {
            return MF_E_SHUTDOWN;
        }

        return mEventQueue->QueueEventParamUnk(met, guidExtendedType, hrStatus, pUnk);
    }

    void shutdownEventQueue()
    {
        std::scoped_lock lock(mQueueMutex);
        mIsShutdown = true;
        if (mEventQueue)
        {
            mEventQueue->Shutdown();
        }
    }

    bool isShutDown() const { return mIsShutdown; }

private:
    std::atomic<bool> mIsShutdown{ false };
    std::mutex mQueueMutex;
    ScopedComPtr<IMFMediaEventQueue> mEventQueue;
};

} // namespace Platform::Windows

#endif // __MEDIA_EVENT_GENERATOR__
