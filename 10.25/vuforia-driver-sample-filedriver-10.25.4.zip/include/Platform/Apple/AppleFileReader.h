/*===============================================================================
Copyright (c) 2021 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/
#ifndef _APPLE_FILEREADER_H_
#define _APPLE_FILEREADER_H_

#include "Platform/FileReader.h"

#include <VuforiaEngine/Driver/Driver.h>

#import <Foundation/Foundation.h>

#include <string>
#include <vector>

namespace Platform
{
namespace Apple
{
/// Apple specific implementation of FileReader.
class AppleFileReader : public FileReader
{
public:
    ~AppleFileReader() override;
    bool init(VuforiaDriver::PlatformData* platformData, FileDriverUserData* userData) override;
    bool deInit() override;
    bool readImage(const std::string& fileName, VuforiaDriver::CameraMode cameraMode, std::vector<uint8_t>& outBytes,
                   uint32_t& outStride) override;
    XMLFileReader::ElementInfo readRecording(const std::string& filename) override;
    void setCapability(VuforiaDriver::Capability) override;

    std::string getAppAssetDirectory() const override;

private:
    NSString* mAbsolutePath = nil;
    VuforiaDriver::PlatformData* mPlatformData = nullptr;
    uint32_t mCapability{ 0 };
};

} // Apple
} // Platform

#endif // _APPLE_FILEREADER_H_
