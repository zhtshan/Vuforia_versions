/*===============================================================================
Copyright (c) 2021 PTC Inc., Its Subsidiary Companies, and /or its Partners.
All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

#ifndef __APPLEVIDEODECODER__
#define __APPLEVIDEODECODER__

#include "Platform/VideoDecoder.h"

#include <CoreMedia/CoreMedia.h>
#include <VideoToolbox/VideoToolbox.h>

#include <atomic>
#include <condition_variable>
#include <list>
#include <mutex>
#include <thread>

namespace Platform
{

class AppleVideoDecoder : public VideoDecoder
{
public:
    ~AppleVideoDecoder();

    std::optional<VuforiaDriver::PixelFormat> start(uint16_t width, uint16_t height,
                                                    const VideoCodecConfigurationData& codecConfigurationData,
                                                    OutputCallback outputCallback) override;

    bool decodeSample(const std::vector<uint8_t>& sample, uint64_t presentationTimestampUs, bool endOfStream, int32_t timeoutUs) override;

    bool canAcceptNewSample() override;

    void stop() override;

    bool flush() override;

private:
    void reset();

    void decoderThread();

    void onFrameDecoded(OSStatus status, VTDecodeInfoFlags infoFlags, CVImageBufferRef imageBuffer, CMTime presentationTimeStamp,
                        CMTime presentationDuration);

    VTDecompressionSessionRef mSession{};
    CMFormatDescriptionRef mVideoFormatDescription{};
    CMMemoryPoolRef mSampleBufferPool{};

    OutputCallback mOutputCallback;
    std::vector<uint8_t> mOutputFrameBuffer;

    std::list<CMSampleBufferRef> mSampleQueue;
    std::mutex mSampleQueueMutex;
    std::condition_variable mSampleQueueCv;
    bool mPendingFlush{ false };

    std::atomic<bool> mRunDecoderThread;
    std::thread mDecoderThread;

    std::atomic<bool> mEndOfStream{ false };
    std::atomic<bool> mDiscardDecodedFrames{ false };
};

} // namespace Platform

#endif // __APPLEVIDEODECODER__
