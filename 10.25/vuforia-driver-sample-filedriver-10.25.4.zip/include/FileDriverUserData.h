/*===============================================================================
Copyright (c) 2021 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/
#ifndef _FILEDRIVER_USERDATA_H_
#define _FILEDRIVER_USERDATA_H_

/// FileDriver specific user data structure.
/**
 * This is an optional parameter that can be passed as the 'void* userData'
 * parameter of Vuforia::setDriverLibrary() call.
 *
 * If this struct is passed during the Vuforia::setDriverLibrary() call the path
 * specified by the sequenceDirectoryAbsolutePath-parameter will be used
 * as a base path for all file reading operations.
 *
 * If this struct is NOT passed during the Vuforia::setDriverLibrary() call the
 * application bundle default asset path will be used for reading operations.
 */
struct FileDriverUserData
{
    /// Absolute path to a directory containing the sequence.
    const char* sequenceDirectoryAbsolutePath;
};

#endif // _FILEDRIVER_USERDATA_H_
